
library("methods")
library("EpiModelHPC")
library("mardham2")

args <- commandArgs(trailingOnly = TRUE)
simno <- args[1]
jobno <- args[2]
fsimno <- paste(simno, jobno, sep = ".")
print(fsimno)

load("est/nwstats.rda")

param <- param.adol(nwstats = st, ai.scale = 5,
                    heat.multiplier = 10)

init <- init.adol(nwstats = st)
control <- control.adol(simno = fsimno, nsteps = 52 * 25,
                        nsims = 16, ncores = 16, resim.int = 4,
                        save.int = 100, verbose.int = 10,
                        save.network = FALSE, save.other = NULL)

netsim_hpc("est/fit.rda", param, init, control, compress = "gzip")
