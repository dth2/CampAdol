#!/bin/bash


qsub -t 1  -v SIMNO=10_10 runsim.sh
qsub -t 1  -v SIMNO=9_6 runsim.sh
qsub -t 1  -v SIMNO=8_6 runsim.sh
qsub -t 1  -v SIMNO=4_10 runsim.sh
qsub -t 1  -v SIMNO=3_4 runsim.sh
qsub -t 1  -v SIMNO=2_6 runsim.sh
qsub -t 1  -v SIMNO=1_5 runsim.sh