#!/bin/bash

qsub -t 1  -v SIMNO=1_1 runsim.sh
qsub -t 1  -v SIMNO=1_2 runsim.sh
qsub -t 1  -v SIMNO=1_3 runsim.sh
qsub -t 1  -v SIMNO=1_4 runsim.sh
qsub -t 1  -v SIMNO=1_5 runsim.sh
qsub -t 1  -v SIMNO=1_6 runsim.sh
qsub -t 1  -v SIMNO=1_7 runsim.sh
qsub -t 1  -v SIMNO=1_8 runsim.sh
qsub -t 1  -v SIMNO=1_9 runsim.sh
qsub -t 1  -v SIMNO=1_10 runsim.sh

qsub -t 1  -v SIMNO=2_1 runsim.sh
qsub -t 1  -v SIMNO=2_2 runsim.sh
qsub -t 1  -v SIMNO=2_3 runsim.sh
qsub -t 1  -v SIMNO=2_4 runsim.sh
qsub -t 1  -v SIMNO=2_5 runsim.sh
qsub -t 1  -v SIMNO=2_6 runsim.sh
qsub -t 1  -v SIMNO=2_7 runsim.sh
qsub -t 1  -v SIMNO=2_8 runsim.sh
qsub -t 1  -v SIMNO=2_9 runsim.sh
qsub -t 1  -v SIMNO=2_10 runsim.sh

qsub -t 1  -v SIMNO=3_1 runsim.sh
qsub -t 1  -v SIMNO=3_2 runsim.sh
qsub -t 1  -v SIMNO=3_3 runsim.sh
qsub -t 1  -v SIMNO=3_4 runsim.sh
qsub -t 1  -v SIMNO=3_5 runsim.sh
qsub -t 1  -v SIMNO=3_6 runsim.sh
qsub -q bf -t 1  -v SIMNO=3_7 runsim.sh
qsub -q bf -t 1  -v SIMNO=3_8 runsim.sh
qsub -q bf -t 1  -v SIMNO=3_9 runsim.sh
qsub -q bf -t 1  -v SIMNO=3_10 runsim.sh

qsub -q bf -t 1  -v SIMNO=4_1 runsim.sh
qsub -q bf -t 1  -v SIMNO=4_2 runsim.sh
qsub -q bf -t 1  -v SIMNO=4_3 runsim.sh
qsub -q bf -t 1  -v SIMNO=4_4 runsim.sh
qsub -q bf -t 1  -v SIMNO=4_5 runsim.sh
qsub -q bf -t 1  -v SIMNO=4_6 runsim.sh
qsub -q bf -t 1  -v SIMNO=4_7 runsim.sh
qsub -q bf -t 1  -v SIMNO=4_8 runsim.sh
qsub -q bf -t 1  -v SIMNO=4_9 runsim.sh
qsub -q bf -t 1  -v SIMNO=4_10 runsim.sh

qsub -q bf -t 1  -v SIMNO=5_1 runsim.sh
qsub -q bf -t 1  -v SIMNO=5_2 runsim.sh
qsub -q bf -t 1  -v SIMNO=5_3 runsim.sh
qsub -q bf -t 1  -v SIMNO=5_4 runsim.sh
qsub -q bf -t 1  -v SIMNO=5_5 runsim.sh
qsub -q bf -t 1  -v SIMNO=5_6 runsim.sh
qsub -q bf -t 1  -v SIMNO=5_7 runsim.sh
qsub -q bf -t 1  -v SIMNO=5_8 runsim.sh
qsub -q bf -t 1  -v SIMNO=5_9 runsim.sh
qsub -q bf -t 1  -v SIMNO=5_10 runsim.sh

qsub -q bf -t 1  -v SIMNO=6_1 runsim.sh
qsub -q bf -t 1  -v SIMNO=6_2 runsim.sh
qsub -q bf -t 1  -v SIMNO=6_3 runsim.sh
qsub -q bf -t 1  -v SIMNO=6_4 runsim.sh
qsub -q bf -t 1  -v SIMNO=6_5 runsim.sh
qsub -q bf -t 1  -v SIMNO=6_6 runsim.sh
qsub -q bf -t 1  -v SIMNO=6_7 runsim.sh
qsub -q bf -t 1  -v SIMNO=6_8 runsim.sh
qsub -q bf -t 1  -v SIMNO=6_9 runsim.sh
qsub -q bf -t 1  -v SIMNO=6_10 runsim.sh

qsub -q bf -t 1  -v SIMNO=7_1 runsim.sh
qsub -q bf -t 1  -v SIMNO=7_2 runsim.sh
qsub -q bf -t 1  -v SIMNO=7_3 runsim.sh
qsub -q bf -t 1  -v SIMNO=7_4 runsim.sh
qsub -q bf -t 1  -v SIMNO=7_5 runsim.sh
qsub -q bf -t 1  -v SIMNO=7_6 runsim.sh
qsub -q bf -t 1  -v SIMNO=7_7 runsim.sh
qsub -q bf -t 1  -v SIMNO=7_8 runsim.sh
qsub -q bf -t 1  -v SIMNO=7_9 runsim.sh
qsub -q bf -t 1  -v SIMNO=7_10 runsim.sh

qsub -q bf -t 1  -v SIMNO=8_1 runsim.sh
qsub -q bf -t 1  -v SIMNO=8_2 runsim.sh
qsub -q bf -t 1  -v SIMNO=8_3 runsim.sh
qsub -q bf -t 1  -v SIMNO=8_4 runsim.sh
qsub -q bf -t 1  -v SIMNO=8_5 runsim.sh
qsub -q bf -t 1  -v SIMNO=8_6 runsim.sh
qsub -q bf -t 1  -v SIMNO=8_7 runsim.sh
qsub -q bf -t 1  -v SIMNO=8_8 runsim.sh
qsub -q bf -t 1  -v SIMNO=8_9 runsim.sh
qsub -q bf -t 1  -v SIMNO=8_10 runsim.sh

qsub -q bf -t 1  -v SIMNO=9_1 runsim.sh
qsub -q bf -t 1  -v SIMNO=9_2 runsim.sh
qsub -q bf -t 1  -v SIMNO=9_3 runsim.sh
qsub -q bf -t 1  -v SIMNO=9_4 runsim.sh
qsub -q bf -t 1  -v SIMNO=9_5 runsim.sh
qsub -q bf -t 1  -v SIMNO=9_6 runsim.sh
qsub -q bf -t 1  -v SIMNO=9_7 runsim.sh
qsub -q bf -t 1  -v SIMNO=9_8 runsim.sh
qsub -q bf -t 1  -v SIMNO=9_9 runsim.sh
qsub -q bf -t 1  -v SIMNO=9_10 runsim.sh

qsub -q bf -t 1  -v SIMNO=10_1 runsim.sh
qsub -q bf -t 1  -v SIMNO=10_2 runsim.sh
qsub -q bf -t 1  -v SIMNO=10_3 runsim.sh
qsub -q bf -t 1  -v SIMNO=10_4 runsim.sh
qsub -q bf -t 1  -v SIMNO=10_5 runsim.sh
qsub -q bf -t 1  -v SIMNO=10_6 runsim.sh
qsub -q bf -t 1  -v SIMNO=10_7 runsim.sh
qsub -q bf -t 1  -v SIMNO=10_8 runsim.sh
qsub -q bf -t 1  -v SIMNO=10_9 runsim.sh
qsub -q bf -t 1  -v SIMNO=10_10 runsim.sh

