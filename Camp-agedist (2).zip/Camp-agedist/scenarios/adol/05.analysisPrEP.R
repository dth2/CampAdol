
## whamp analysis file

library(mardham2)
library(EpiModelHPC)

list.files("scenarios/adol/data/1 to 99")
list.files("scenarios/adol/data/100 plus")

s1 <- merge_simfiles(1, indir = "scenarios/adol/data/1to 99/")
s2 <- merge_simfiles(2, indir = "scenarios/adol/data/1to 99/")
s3 <- merge_simfiles(3, indir = "scenarios/adol/data/1to 99/")
s4 <- merge_simfiles(4, indir = "scenarios/adol/data/1to 99/")
s5 <- merge_simfiles(5, indir = "scenarios/adol/data/1to 99/")
s6 <- merge_simfiles(6, indir = "scenarios/adol/data/1to 99/")
s7 <- merge_simfiles(7, indir = "scenarios/adol/data/1to 99/")
s8 <- merge_simfiles(8, indir = "scenarios/adol/data/1to 99/")
s9 <- merge_simfiles(9, indir = "scenarios/adol/data/1to 99/")
s10 <- merge_simfiles(10, indir = "scenarios/adol/data/1to 99/")
s11 <- merge_simfiles(11, indir = "scenarios/adol/data/1to 99/")
s12 <- merge_simfiles(12, indir = "scenarios/adol/data/1to 99/")
s13 <- merge_simfiles(13, indir = "scenarios/adol/data/1to 99/")
s14 <- merge_simfiles(14, indir = "scenarios/adol/data/1to 99/")
s15 <- merge_simfiles(15, indir = "scenarios/adol/data/1to 99/")
s16 <- merge_simfiles(16, indir = "scenarios/adol/data/1to 99/")
s17 <- merge_simfiles(17, indir = "scenarios/adol/data/1to 99/")
s18 <- merge_simfiles(18, indir = "scenarios/adol/data/1to 99/")
s19 <- merge_simfiles(19, indir = "scenarios/adol/data/1to 99/")
s20 <- merge_simfiles(20, indir = "scenarios/adol/data/1to 99/")
s21 <- merge_simfiles(21, indir = "scenarios/adol/data/1to 99/")
s22 <- merge_simfiles(22, indir = "scenarios/adol/data/1to 99/")
s23 <- merge_simfiles(23, indir = "scenarios/adol/data/1to 99/")
s24 <- merge_simfiles(24, indir = "scenarios/adol/data/1to 99/")
s25 <- merge_simfiles(25, indir = "scenarios/adol/data/1to 99/")
s26 <- merge_simfiles(26, indir = "scenarios/adol/data/1to 99/")
s27 <- merge_simfiles(27, indir = "scenarios/adol/data/1to 99/")
s28 <- merge_simfiles(28, indir = "scenarios/adol/data/1to 99/")
s29 <- merge_simfiles(29, indir = "scenarios/adol/data/1to 99/")
s30 <- merge_simfiles(30, indir = "scenarios/adol/data/1to 99/")
s31 <- merge_simfiles(31, indir = "scenarios/adol/data/1to 99/")
s32 <- merge_simfiles(32, indir = "scenarios/adol/data/1to 99/")
s33 <- merge_simfiles(33, indir = "scenarios/adol/data/1to 99/")
s34 <- merge_simfiles(34, indir = "scenarios/adol/data/1to 99/")
s35 <- merge_simfiles(35, indir = "scenarios/adol/data/1to 99/")
s36 <- merge_simfiles(36, indir = "scenarios/adol/data/1to 99/")
s37 <- merge_simfiles(37, indir = "scenarios/adol/data/1to 99/")
s38 <- merge_simfiles(38, indir = "scenarios/adol/data/1to 99/")
s39 <- merge_simfiles(39, indir = "scenarios/adol/data/1to 99/")
s40 <- merge_simfiles(40, indir = "scenarios/adol/data/1to 99/")
s41 <- merge_simfiles(41, indir = "scenarios/adol/data/1to 99/")
s42 <- merge_simfiles(42, indir = "scenarios/adol/data/1to 99/")
s43 <- merge_simfiles(43, indir = "scenarios/adol/data/1to 99/")
s44 <- merge_simfiles(44, indir = "scenarios/adol/data/1to 99/")
s45 <- merge_simfiles(45, indir = "scenarios/adol/data/1to 99/")
s46 <- merge_simfiles(46, indir = "scenarios/adol/data/1to 99/")
s47 <- merge_simfiles(47, indir = "scenarios/adol/data/1to 99/")
s48 <- merge_simfiles(48, indir = "scenarios/adol/data/1to 99/")
s49 <- merge_simfiles(49, indir = "scenarios/adol/data/1to 99/")
s50 <- merge_simfiles(50, indir = "scenarios/adol/data/1to 99/")
s51 <- merge_simfiles(51, indir = "scenarios/adol/data/1to 99/")
s52 <- merge_simfiles(52, indir = "scenarios/adol/data/1to 99/")
s53 <- merge_simfiles(53, indir = "scenarios/adol/data/1to 99/")
s54 <- merge_simfiles(54, indir = "scenarios/adol/data/1to 99/")
s55 <- merge_simfiles(55, indir = "scenarios/adol/data/1to 99/")
s56 <- merge_simfiles(56, indir = "scenarios/adol/data/1to 99/")
s57 <- merge_simfiles(57, indir = "scenarios/adol/data/1to 99/")
s58 <- merge_simfiles(58, indir = "scenarios/adol/data/1to 99/")
s59 <- merge_simfiles(59, indir = "scenarios/adol/data/1to 99/")
s60 <- merge_simfiles(60, indir = "scenarios/adol/data/1to 99/")
s61 <- merge_simfiles(61, indir = "scenarios/adol/data/1to 99/")
s62 <- merge_simfiles(62, indir = "scenarios/adol/data/1to 99/")
s63 <- merge_simfiles(63, indir = "scenarios/adol/data/1to 99/")
s64 <- merge_simfiles(64, indir = "scenarios/adol/data/1to 99/")
s65 <- merge_simfiles(65, indir = "scenarios/adol/data/1to 99/")
s66 <- merge_simfiles(66, indir = "scenarios/adol/data/1to 99/")
s67 <- merge_simfiles(67, indir = "scenarios/adol/data/1to 99/")
s68 <- merge_simfiles(68, indir = "scenarios/adol/data/1to 99/")
s69 <- merge_simfiles(69, indir = "scenarios/adol/data/1to 99/")
s70 <- merge_simfiles(70, indir = "scenarios/adol/data/1to 99/")
s71 <- merge_simfiles(71, indir = "scenarios/adol/data/1to 99/")
s72 <- merge_simfiles(72, indir = "scenarios/adol/data/1to 99/")
s73 <- merge_simfiles(73, indir = "scenarios/adol/data/1to 99/")
s74 <- merge_simfiles(74, indir = "scenarios/adol/data/1to 99/")
s75 <- merge_simfiles(75, indir = "scenarios/adol/data/1to 99/")
s76 <- merge_simfiles(76, indir = "scenarios/adol/data/1to 99/")
s77 <- merge_simfiles(77, indir = "scenarios/adol/data/1to 99/")
s78 <- merge_simfiles(78, indir = "scenarios/adol/data/1to 99/")
s79 <- merge_simfiles(79, indir = "scenarios/adol/data/1to 99/")
s80 <- merge_simfiles(80, indir = "scenarios/adol/data/1to 99/")
s81 <- merge_simfiles(81, indir = "scenarios/adol/data/1to 99/")
s82 <- merge_simfiles(82, indir = "scenarios/adol/data/1to 99/")
s83 <- merge_simfiles(83, indir = "scenarios/adol/data/1to 99/")
s84 <- merge_simfiles(84, indir = "scenarios/adol/data/1to 99/")
s85 <- merge_simfiles(85, indir = "scenarios/adol/data/1to 99/")
s86 <- merge_simfiles(86, indir = "scenarios/adol/data/1to 99/")
s87 <- merge_simfiles(87, indir = "scenarios/adol/data/1to 99/")
s88 <- merge_simfiles(88, indir = "scenarios/adol/data/1to 99/")
s89 <- merge_simfiles(89, indir = "scenarios/adol/data/1to 99/")
s90 <- merge_simfiles(90, indir = "scenarios/adol/data/1to 99/")
s91 <- merge_simfiles(91, indir = "scenarios/adol/data/1to 99/")
s92 <- merge_simfiles(92, indir = "scenarios/adol/data/1to 99/")
s93 <- merge_simfiles(93, indir = "scenarios/adol/data/1to 99/")
s94 <- merge_simfiles(94, indir = "scenarios/adol/data/1to 99/")
s95 <- merge_simfiles(95, indir = "scenarios/adol/data/1to 99/")
s96 <- merge_simfiles(96, indir = "scenarios/adol/data/1to 99/")
s97 <- merge_simfiles(97, indir = "scenarios/adol/data/1to 99/")
s98 <- merge_simfiles(98, indir = "scenarios/adol/data/1to 99/")
s99 <- merge_simfiles(99, indir = "scenarios/adol/data/1to 99/")
s100 <- merge_simfiles(100, indir = "scenarios/adol/data/100 plus/")
s101 <- merge_simfiles(101, indir = "scenarios/adol/data/100 plus/")
s102 <- merge_simfiles(102, indir = "scenarios/adol/data/100 plus/")
s103 <- merge_simfiles(103, indir = "scenarios/adol/data/100 plus/")
s104 <- merge_simfiles(104, indir = "scenarios/adol/data/100 plus/")
s105 <- merge_simfiles(105, indir = "scenarios/adol/data/100 plus/")
s106 <- merge_simfiles(106, indir = "scenarios/adol/data/100 plus/")
s107 <- merge_simfiles(107, indir = "scenarios/adol/data/100 plus/")
s108 <- merge_simfiles(108, indir = "scenarios/adol/data/100 plus/")
s109 <- merge_simfiles(109, indir = "scenarios/adol/data/100 plus/")
s110 <- merge_simfiles(110, indir = "scenarios/adol/data/100 plus/")
s111 <- merge_simfiles(111, indir = "scenarios/adol/data/100 plus/")
s112 <- merge_simfiles(112, indir = "scenarios/adol/data/100 plus/")
s113 <- merge_simfiles(113, indir = "scenarios/adol/data/100 plus/")
s114 <- merge_simfiles(114, indir = "scenarios/adol/data/100 plus/")
s115 <- merge_simfiles(115, indir = "scenarios/adol/data/100 plus/")
s116 <- merge_simfiles(116, indir = "scenarios/adol/data/100 plus/")
s117 <- merge_simfiles(117, indir = "scenarios/adol/data/100 plus/")
s118 <- merge_simfiles(118, indir = "scenarios/adol/data/100 plus/")
s119 <- merge_simfiles(119, indir = "scenarios/adol/data/100 plus/")
s120 <- merge_simfiles(120, indir = "scenarios/adol/data/100 plus/")
s121 <- merge_simfiles(121, indir = "scenarios/adol/data/100 plus/")
s122 <- merge_simfiles(122, indir = "scenarios/adol/data/100 plus/")
s123 <- merge_simfiles(123, indir = "scenarios/adol/data/100 plus/")
s124 <- merge_simfiles(124, indir = "scenarios/adol/data/100 plus/")
s125 <- merge_simfiles(125, indir = "scenarios/adol/data/100 plus/")
s126 <- merge_simfiles(126, indir = "scenarios/adol/data/100 plus/")
s127 <- merge_simfiles(127, indir = "scenarios/adol/data/100 plus/")
s128 <- merge_simfiles(128, indir = "scenarios/adol/data/100 plus/")
s129 <- merge_simfiles(129, indir = "scenarios/adol/data/100 plus/")
s130 <- merge_simfiles(130, indir = "scenarios/adol/data/100 plus/")
s131 <- merge_simfiles(131, indir = "scenarios/adol/data/100 plus/")
s132 <- merge_simfiles(132, indir = "scenarios/adol/data/100 plus/")
s133 <- merge_simfiles(133, indir = "scenarios/adol/data/100 plus/")
s134 <- merge_simfiles(134, indir = "scenarios/adol/data/100 plus/")
s135 <- merge_simfiles(135, indir = "scenarios/adol/data/100 plus/")
s136 <- merge_simfiles(136, indir = "scenarios/adol/data/100 plus/")
s137 <- merge_simfiles(137, indir = "scenarios/adol/data/100 plus/")
s138 <- merge_simfiles(138, indir = "scenarios/adol/data/100 plus/")
s139 <- merge_simfiles(139, indir = "scenarios/adol/data/100 plus/")
s140 <- merge_simfiles(140, indir = "scenarios/adol/data/100 plus/")
s141 <- merge_simfiles(141, indir = "scenarios/adol/data/100 plus/")
s142 <- merge_simfiles(142, indir = "scenarios/adol/data/100 plus/")
s143 <- merge_simfiles(143, indir = "scenarios/adol/data/100 plus/")
s144 <- merge_simfiles(144, indir = "scenarios/adol/data/100 plus/")
s145 <- merge_simfiles(145, indir = "scenarios/adol/data/100 plus/")
s146 <- merge_simfiles(146, indir = "scenarios/adol/data/100 plus/")
s147 <- merge_simfiles(147, indir = "scenarios/adol/data/100 plus/")
s148 <- merge_simfiles(148, indir = "scenarios/adol/data/100 plus/")
s149 <- merge_simfiles(149, indir = "scenarios/adol/data/100 plus/")
s150 <- merge_simfiles(150, indir = "scenarios/adol/data/100 plus/")
s151 <- merge_simfiles(151, indir = "scenarios/adol/data/100 plus/")
s152 <- merge_simfiles(152, indir = "scenarios/adol/data/100 plus/")
s153 <- merge_simfiles(153, indir = "scenarios/adol/data/100 plus/")
s154 <- merge_simfiles(154, indir = "scenarios/adol/data/100 plus/")
s155 <- merge_simfiles(155, indir = "scenarios/adol/data/100 plus/")
s156 <- merge_simfiles(156, indir = "scenarios/adol/data/100 plus/")
s157 <- merge_simfiles(157, indir = "scenarios/adol/data/100 plus/")
s158 <- merge_simfiles(158, indir = "scenarios/adol/data/100 plus/")
s159 <- merge_simfiles(159, indir = "scenarios/adol/data/100 plus/")
s160 <- merge_simfiles(160, indir = "scenarios/adol/data/100 plus/")
s161 <- merge_simfiles(161, indir = "scenarios/adol/data/100 plus/")
s162 <- merge_simfiles(162, indir = "scenarios/adol/data/100 plus/")
s163 <- merge_simfiles(163, indir = "scenarios/adol/data/100 plus/")
s164 <- merge_simfiles(164, indir = "scenarios/adol/data/100 plus/")
s165 <- merge_simfiles(165, indir = "scenarios/adol/data/100 plus/")
s166 <- merge_simfiles(166, indir = "scenarios/adol/data/100 plus/")
s167 <- merge_simfiles(167, indir = "scenarios/adol/data/100 plus/")
s168 <- merge_simfiles(168, indir = "scenarios/adol/data/100 plus/")
s169 <- merge_simfiles(169, indir = "scenarios/adol/data/100 plus/")

s171 <- merge_simfiles(171, indir = "scenarios/adol/data/100 plus/")
s172 <- merge_simfiles(172, indir = "scenarios/adol/data/100 plus/")
s173 <- merge_simfiles(173, indir = "scenarios/adol/data/100 plus/")
s174 <- merge_simfiles(174, indir = "scenarios/adol/data/100 plus/")
s175 <- merge_simfiles(175, indir = "scenarios/adol/data/100 plus/")
s176 <- merge_simfiles(176, indir = "scenarios/adol/data/100 plus/")
s177 <- merge_simfiles(177, indir = "scenarios/adol/data/100 plus/")
s178 <- merge_simfiles(178, indir = "scenarios/adol/data/100 plus/")
s179 <- merge_simfiles(179, indir = "scenarios/adol/data/100 plus/")
s180 <- merge_simfiles(180, indir = "scenarios/adol/data/100 plus/")
s181 <- merge_simfiles(181, indir = "scenarios/adol/data/100 plus/")
s182 <- merge_simfiles(182, indir = "scenarios/adol/data/100 plus/")
s183 <- merge_simfiles(183, indir = "scenarios/adol/data/100 plus/")
s184 <- merge_simfiles(184, indir = "scenarios/adol/data/100 plus/")
s185 <- merge_simfiles(185, indir = "scenarios/adol/data/100 plus/")
s186 <- merge_simfiles(186, indir = "scenarios/adol/data/100 plus/")
s187 <- merge_simfiles(187, indir = "scenarios/adol/data/100 plus/")
s188 <- merge_simfiles(188, indir = "scenarios/adol/data/100 plus/")
s189 <- merge_simfiles(189, indir = "scenarios/adol/data/100 plus/")
s190 <- merge_simfiles(190, indir = "scenarios/adol/data/100 plus/")
s191 <- merge_simfiles(191, indir = "scenarios/adol/data/100 plus/")
s192 <- merge_simfiles(192, indir = "scenarios/adol/data/100 plus/")
s193 <- merge_simfiles(193, indir = "scenarios/adol/data/100 plus/")
s194 <- merge_simfiles(194, indir = "scenarios/adol/data/100 plus/")
s195 <- merge_simfiles(195, indir = "scenarios/adol/data/100 plus/")
s196 <- merge_simfiles(196, indir = "scenarios/adol/data/100 plus/")
s197 <- merge_simfiles(197, indir = "scenarios/adol/data/100 plus/")
s198 <- merge_simfiles(198, indir = "scenarios/adol/data/100 plus/")
s199 <- merge_simfiles(199, indir = "scenarios/adol/data/100 plus/")
s200 <- merge_simfiles(200, indir = "scenarios/adol/data/200 plus/")
s201 <- merge_simfiles(201, indir = "scenarios/adol/data/200 plus/")
s202 <- merge_simfiles(202, indir = "scenarios/adol/data/200 plus/")
s203 <- merge_simfiles(203, indir = "scenarios/adol/data/200 plus/")
s204 <- merge_simfiles(204, indir = "scenarios/adol/data/200 plus/")
s205 <- merge_simfiles(205, indir = "scenarios/adol/data/200 plus/")
s206 <- merge_simfiles(206, indir = "scenarios/adol/data/200 plus/")
s207 <- merge_simfiles(207, indir = "scenarios/adol/data/200 plus/")
s208 <- merge_simfiles(208, indir = "scenarios/adol/data/200 plus/")
s209 <- merge_simfiles(209, indir = "scenarios/adol/data/200 plus/")

s215 <- merge_simfiles(215, indir = "scenarios/adol/data/200 plus/")
s216 <- merge_simfiles(216, indir = "scenarios/adol/data/200 plus/")


data<-c("s1","s2","s3","s4","s5","s6","s7","s8","s9","s10",
        "s11","s12","s13","s14","s15","s16","s17","s18","s19",
        "s20","s21","s22","s23","s24","s25","s26","s27","s28","s29",
        "s30","s31","s32","s33","s34","s35","s36","s37","s38","s39",
        "s40","s41","s42","s43","s44","s45","s46","s47","s48","s49",
        "s50","s51","s52","s53","s54","s55","s56","s57","s58","s59",
        "s60","s61","s62","s63","s64","s65","s66","s67","s68","s69",
        "s70","s71","s72","s73","s74","s75","s76","s77","s78","s79",
        "s80","s81","s82","s83","s84","s85","s86","s87","s88","s89",
        "s90","s91","s92","s93","s94","s95","s96","s97","s98","s99",
        "s100","s101","s102","s103","s104","s105","s106","s107","s108","s109",
        "s110","s111","s112","s113","s114","s115","s116","s117","s118","s119",
        "s120","s121","s122","s123","s124","s125","s126","s127","s128","s129",
        "s130","s131","s132","s133","s134","s135","s136","s137","s138","s139",
        "s140","s141","s142","s143","s144","s145","s146","s147","s148","s149",
        "s150","s151","s152","s153","s154","s155","s156","s157","s158","s159",
        "s160","s161","s162","s163","s164","s165","s166","s167","s168","s169",
        "s171","s172","s173","s174","s175","s176","s177","s178","s179",
        "s180","s181","s182","s183","s184","s185","s186","s187","s188","s189",
        "s190","s191","s192","s193","s194","s195","s196","s197","s198","s199",
        "s200","s201","s202","s203","s204","s205","s206","s207","s208","s209",
        "s215", "s216") 

coverage<-rep(NA,length(data))
adherence<-rep(NA,length(data))
incid.total<-rep(NA,length(data))
incid.rate<-rep(NA,length(data))
incid.total.up95<-rep(NA,length(data))
incid.total.low95<-rep(NA,length(data))
incid.total.ly<-rep(NA,length(data))
incid.total.ly.up95<-rep(NA,length(data))
incid.total.ly.low95<-rep(NA,length(data))

prep.pt<-rep(NA,length(data))
prep.pt.up95<-rep(NA,length(data))
prep.pt.low95<-rep(NA,length(data))

person.time<-rep(NA,length(data))
person.time.deb<-rep(NA,length(data))

person.time.ly<-rep(NA,length(data))
person.time.ly.deb<-rep(NA,length(data))

prev.pop<-rep(NA,length(data))
prev.pop.up95<-rep(NA,length(data))
prev.pop.low95<-rep(NA,length(data))
prev.age18<-rep(NA,length(data))
prev.age18.up95<-rep(NA,length(data))
prev.age18.low95<-rep(NA,length(data))

for (i in 1:length(data)){

  incid.total.temp<-rep(NA,100)
  incid.total.up95.temp<-rep(NA,100)
  incid.total.low95.temp<-rep(NA,100)
  incid.total.ly.temp<-rep(NA,100)
  incid.total.ly.up95.temp<-rep(NA,100)
  incid.total.ly.low95.temp<-rep(NA,100)
  prep.pt.temp<-rep(NA,100)
  prep.pt.up95.temp<-rep(NA,100)
  prep.pt.low95.temp<-rep(NA,100)
  person.time.temp<-rep(NA,100)
  person.time.deb.temp<-rep(NA,100)
  person.time.ly.temp<-rep(NA,100)
  person.time.ly.deb.temp<-rep(NA,100)
  coverage<-rep(NA,100)
  adherence<-rep(NA,100)
  
  prev.pop.temp<-rep(NA,100)
  prev.age18.temp<-rep(NA,100)
  
  
    for (j in 1:100){  
      incid.total.temp[j]<-sum(get(data[i])$epi$incid[1041:2080,j])
      incid.total.ly.temp[j]<-sum(get(data[i])$epi$incid[2028:2080,j])
      prep.pt.temp[j]<-sum(get(data[i])$epi$prepCurr[1041:2080,j])
      person.time.temp[j]<-sum(get(data[i])$epi$num[1041:2080,j])
      person.time.deb.temp[j]<-sum(get(data[i])$epi$debuted[1041:2080,j])
      person.time.ly.temp[j]<-sum(get(data[i])$epi$num[2028:2080,j])
      person.time.ly.deb.temp[j]<-sum(get(data[i])$epi$debuted[2028:2080,j])
      prev.pop.temp[j]<-get(data[i])$epi$i.prev[2080,j]
      prev.age18.temp[j]<-get(data[i])$epi$i.prev.age6[2080,j]
    }
  
  coverage<-get(data[i])$param$prep.coverage
  adherence<-get(data[i])$param$prep.class.prob
  incid.total[i]<-mean(incid.total.temp)
  incid.rate[i]<-mean(incid.total.temp)/1040
  incid.total.temp.ordered<-sort(incid.total.temp)
  incid.total.up95[i]<-incid.total.temp.ordered[length(incid.total.temp.ordered)*.975]
  incid.total.low95[i]<-incid.total.temp.ordered[length(incid.total.temp.ordered)*.025]
  
  incid.total.ly[i]<-mean(incid.total.ly.temp)
  incid.total.ly.temp.ordered<-sort(incid.total..ly.temp)
  incid.total.ly.up95[i]<-incid.total.ly.temp.ordered[length(incid.total.ly.temp.ordered)*.975]
  incid.total.ly.low95[i]<-incid.total.ly.temp.ordered[length(incid.total.ly.temp.ordered)*.025]
  
  prep.pt[i]<-mean(prep.pt.temp)
  prep.pt.temp.ordered<-sort(prep.pt.temp)
  prep.pt.up95[i]<-prep.pt.temp.ordered[length(prep.pt.temp.ordered)*.975]
  prep.pt.low95[i]<-prep.pt.temp.ordered[length(prep.pt.temp.ordered)*.025]
  
  prev.pop[i]<-mean(prev.pop.temp)
  prev.pop.temp.ordered<-sort(prev.pop.temp)
  prev.pop.up95[i]<-prev.pop.temp.ordered[length(prev.pop.temp.ordered)*.975]
  prev.pop.low95[i]<-prev.pop.temp.ordered[length(prev.pop.temp.ordered)*.025]
  
  prev.age18[i]<-mean(prev.age18.temp)
  prev.age18.temp.ordered<-sort(prev.age18.temp)
  prev.age18.up95[i]<-prev.age18.temp.ordered[length(prev.age18.temp.ordered)*.975]
  prev.age18.low95[i]<-prev.age18.temp.ordered[length(prev.age18.temp.ordered)*.025]
  
  
  person.time[i]<-person.time.temp
  person.time.deb[i]<-person.time.deb.temp
  
  person.time.ly[i]<-person.time.ly.temp
  person.time.ly.deb[i]<-person.time.ly.deb.temp
  
      
 
}



##Make the output dataframe.

prep.out.matrix<-cbind(coverage, prev.pop,prev.pop.up95,prev.pop.low95,prev.age18,prev.age18.up95,prev.age18.low95,
                       incid.total,incid.total.low95,incid.total.up95,incid.total.ly,incid.total.ly.low95,incid.total.ly.up95,
                       prep.pt,prep.pt.low95,prep.pt.up95,person.time,person.time.deb)
prep.out<-as.data.frame(prep.out.matrix)

#calulate incidence per 100 year at risk.
prep.out$incid.total.100pt.all<-NULL
prep.out$incid.total.low95.100pt.all<-NULL
prep.out$incid.total.up95.100pt.all<-NULL

prep.out$incid.total.100pt.deb<-NULL
prep.out$incid.total.low95.100pt.deb<-NULL
prep.out$incid.total.up95.100pt.deb<-NULL

prep.out$incid.total.ly.100pt.all<-NULL
prep.out$incid.total.ly.low95.100pt.all<-NULL
prep.out$incid.total.ly.up95.100pt.all<-NULL

prep.out$incid.total.ly.100pt.deb<-NULL
prep.out$incid.total.ly.low95.100pt.deb<-NULL
prep.out$incid.total.ly.up95.100pt.deb<-NULL


  prep.out$incid.total.100pt.all<-prep.out$incid.total/prep.out$person.time*52*100
  prep.out$incid.total.low95.100pt.all<-prep.out$incid.total.low95/prep.out$person.time*52*100
  prep.out$incid.total.up95.100pt.all<-prep.out$incid.total.up95/prep.out$person.time*52*100
  
  prep.out$incid.total.100pt.deb<-prep.out$incid.total/prep.out$person.time.deb*52*100
  prep.out$incid.total.low95.100pt.deb<-prep.out$incid.total.low95/prep.out$person.time.deb*52*100
  prep.out$incid.total.up95.100pt.deb<-prep.out$incid.total.up95/prep.out$person.time.deb*52*100
  
  prep.out$incid.total.ly.100pt.all<-prep.out$incid.total.ly/prep.out$person.time.ly*52*100
  prep.out$incid.total.ly.low95.100pt.all<-prep.out$incid.total.ly.low95/prep.out$person.time.ly*52*100
  prep.out$incid.total.ly.up95.100pt.all<-prep.out$incid.total.ly.up95/prep.out$person.time.ly*52*100
  
  prep.out$incid.total.ly.100pt.deb<-prep.out$incid.total.ly/prep.out$person.time.ly.deb*52*100
  prep.out$incid.total.ly.low95.100pt.deb<-prep.out$incid.total.ly.low95/prep.out$person.time.ly.deb*52*100
  prep.out$incid.total.ly.up95.100pt.deb<-prep.out$incid.total.ly.up95/prep.out$person.time.ly.deb*52*100

  
#Number of infections averted per 100K person years at risk  (define at risk).
#Percent of infection averted.
#NNt persontime on prep / (1/NIA)
prep.out$NIA.all.pt<-rep(0,length(data))
prep.out$NIA.deb.pt<-rep(0,length(data))
prep.out$PIA<-rep(0,length(data))
prep.out$NNT.all<-rep(0,length(data))
prep.out$NNT.deb<-rep(0,length(data))


#Number of infections averted per 100K person years at risk (in population and in the sexual marketplace).
for (i in 2:(length(prep.out$incid.total))){
    prep.out$NIA.all.pt[i]<-((prep.out$incid.total[1]-prep.out$incid.total[i])/prep.out$person.time[i])*52*100000
    prep.out$NIA.deb.pt[i]<-((prep.out$incid.total[1]-prep.out$incid.total[i])/prep.out$person.time.deb[i])*52*100000
}

#Percent of infection averted.

for (i in 2:(length(prep.out$incid.total))){
  prep.out$PIA[i]<-(prep.out$incid.total[1]-prep.out$incid.total[i])/prep.out$incid.total[1]
}


#NNT prep.pt/(NIA).

prep.out$NNT.all<-prep.out$prep.pt/prep.out$NIA.all
prep.out$NNT.deb<-prep.out$prep.pt/prep.out$NIA.deb
prep.out$incid.total
prep.out$sim<-data
head(prep.out)

save(prep.out, file = "scenarios/adol/out/sim.summary.output.rda")


