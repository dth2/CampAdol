
## Camp analysis file

library(mardham2)
library(EpiModelHPC)

list.files("scenarios/adol/data/")



adult.AI.count<-rep(NA,30)
ysmm.AI.count<-rep(NA,30)

adult.AI.count[1]<-mean(sim.counts$epi$AI.adult.count.13.1$sim1, na.rm = TRUE)
mean(sim.counts$epi$AI.adult.count.13.1$sim1, na.rm = TRUE)
adult.AI.count[2]<-mean(sim.counts$epi$AI.adult.count.13.2$sim1,na.rm = TRUE)
mean(sim.counts$epi$AI.adult.count.13.2$sim1,na.rm = TRUE)
adult.AI.count[3]<-mean(sim.counts$epi$AI.adult.count.13.3$sim1,na.rm = TRUE)
mean(sim.counts$epi$AI.adult.count.13.3$sim1,na.rm = TRUE)
adult.AI.count[4]<-mean(sim.counts$epi$AI.adult.count.13.4$sim1,na.rm = TRUE)
mean(sim.counts$epi$AI.adult.count.13.4$sim1,na.rm = TRUE)
adult.AI.count[5]<-mean(sim.counts$epi$AI.adult.count.13.5$sim1,na.rm = TRUE)
mean(sim.counts$epi$AI.adult.count.13.5$sim1,na.rm = TRUE)
adult.AI.count[6]<-mean(sim.counts$epi$AI.adult.count.14.1$sim1,na.rm = TRUE)
adult.AI.count[7]<-mean(sim.counts$epi$AI.adult.count.14.2$sim1,na.rm = TRUE)
adult.AI.count[8]<-mean(sim.counts$epi$AI.adult.count.14.3$sim1,na.rm = TRUE)
adult.AI.count[9]<-mean(sim.counts$epi$AI.adult.count.14.4$sim1,na.rm = TRUE)
adult.AI.count[10]<-mean(sim.counts$epi$AI.adult.count.14.5$sim1,na.rm = TRUE)
adult.AI.count[11]<-mean(sim.counts$epi$AI.adult.count.15.1$sim1,na.rm = TRUE)
adult.AI.count[12]<-mean(sim.counts$epi$AI.adult.count.15.2$sim1,na.rm = TRUE)
adult.AI.count[13]<-mean(sim.counts$epi$AI.adult.count.15.3$sim1,na.rm = TRUE)
adult.AI.count[14]<-mean(sim.counts$epi$AI.adult.count.15.4$sim1,na.rm = TRUE)
adult.AI.count[15]<-mean(sim.counts$epi$AI.adult.count.15.5$sim1,na.rm = TRUE)
adult.AI.count[16]<-mean(sim.counts$epi$AI.adult.count.16.1$sim1,na.rm = TRUE)
adult.AI.count[17]<-mean(sim.counts$epi$AI.adult.count.16.2$sim1,na.rm = TRUE)
adult.AI.count[18]<-mean(sim.counts$epi$AI.adult.count.16.3$sim1,na.rm = TRUE)
adult.AI.count[19]<-mean(sim.counts$epi$AI.adult.count.16.4$sim1,na.rm = TRUE)
adult.AI.count[20]<-mean(sim.counts$epi$AI.adult.count.16.5$sim1,na.rm = TRUE)
adult.AI.count[21]<-mean(sim.counts$epi$AI.adult.count.17.1$sim1,na.rm = TRUE)
adult.AI.count[22]<-mean(sim.counts$epi$AI.adult.count.17.2$sim1,na.rm = TRUE)
adult.AI.count[23]<-mean(sim.counts$epi$AI.adult.count.17.3$sim1,na.rm = TRUE)
adult.AI.count[24]<-mean(sim.counts$epi$AI.adult.count.17.4$sim1,na.rm = TRUE)
adult.AI.count[25]<-mean(sim.counts$epi$AI.adult.count.17.5$sim1,na.rm = TRUE)
adult.AI.count[26]<-mean(sim.counts$epi$AI.adult.count.18.1$sim1,na.rm = TRUE)
adult.AI.count[27]<-mean(sim.counts$epi$AI.adult.count.18.2$sim1,na.rm = TRUE)
adult.AI.count[28]<-mean(sim.counts$epi$AI.adult.count.18.3$sim1,na.rm = TRUE)
adult.AI.count[29]<-mean(sim.counts$epi$AI.adult.count.18.4$sim1,na.rm = TRUE)
adult.AI.count[30]<-mean(sim.counts$epi$AI.adult.count.18.5$sim1,na.rm = TRUE)

ysmm.AI.count[1]<-mean(sim.counts$epi$AI.ysmm.count.13.1$sim1,na.rm = TRUE)
ysmm.AI.count[2]<-mean(sim.counts$epi$AI.ysmm.count.13.2$sim1,na.rm = TRUE)
ysmm.AI.count[3]<-mean(sim.counts$epi$AI.ysmm.count.13.3$sim1,na.rm = TRUE)
ysmm.AI.count[4]<-mean(sim.counts$epi$AI.ysmm.count.13.4$sim1,na.rm = TRUE)
ysmm.AI.count[5]<-mean(sim.counts$epi$AI.ysmm.count.13.5$sim1,na.rm = TRUE)
ysmm.AI.count[6]<-mean(sim.counts$epi$AI.ysmm.count.14.1$sim1,na.rm = TRUE)
ysmm.AI.count[7]<-mean(sim.counts$epi$AI.ysmm.count.14.2$sim1,na.rm = TRUE)
ysmm.AI.count[8]<-mean(sim.counts$epi$AI.ysmm.count.14.3$sim1,na.rm = TRUE)
ysmm.AI.count[9]<-mean(sim.counts$epi$AI.ysmm.count.14.4$sim1,na.rm = TRUE)
ysmm.AI.count[10]<-mean(sim.counts$epi$AI.ysmm.count.14.5$sim1,na.rm = TRUE)
ysmm.AI.count[11]<-mean(sim.counts$epi$AI.ysmm.count.15.1$sim1,na.rm = TRUE)
ysmm.AI.count[12]<-mean(sim.counts$epi$AI.ysmm.count.15.2$sim1,na.rm = TRUE)
ysmm.AI.count[13]<-mean(sim.counts$epi$AI.ysmm.count.15.3$sim1,na.rm = TRUE)
ysmm.AI.count[14]<-mean(sim.counts$epi$AI.ysmm.count.15.4$sim1,na.rm = TRUE)
ysmm.AI.count[15]<-mean(sim.counts$epi$AI.ysmm.count.15.5$sim1,na.rm = TRUE)
ysmm.AI.count[16]<-mean(sim.counts$epi$AI.ysmm.count.16.1$sim1,na.rm = TRUE)
ysmm.AI.count[17]<-mean(sim.counts$epi$AI.ysmm.count.16.2$sim1,na.rm = TRUE)
ysmm.AI.count[18]<-mean(sim.counts$epi$AI.ysmm.count.16.3$sim1,na.rm = TRUE)
ysmm.AI.count[19]<-mean(sim.counts$epi$AI.ysmm.count.16.4$sim1,na.rm = TRUE)
ysmm.AI.count[20]<-mean(sim.counts$epi$AI.ysmm.count.16.5$sim1,na.rm = TRUE)
ysmm.AI.count[21]<-mean(sim.counts$epi$AI.ysmm.count.17.1$sim1,na.rm = TRUE)
ysmm.AI.count[22]<-mean(sim.counts$epi$AI.ysmm.count.17.2$sim1,na.rm = TRUE)
ysmm.AI.count[23]<-mean(sim.counts$epi$AI.ysmm.count.17.3$sim1,na.rm = TRUE)
ysmm.AI.count[24]<-mean(sim.counts$epi$AI.ysmm.count.17.4$sim1,na.rm = TRUE)
ysmm.AI.count[25]<-mean(sim.counts$epi$AI.ysmm.count.17.5$sim1,na.rm = TRUE)
ysmm.AI.count[26]<-mean(sim.counts$epi$AI.ysmm.count.18.1$sim1,na.rm = TRUE)
ysmm.AI.count[27]<-mean(sim.counts$epi$AI.ysmm.count.18.2$sim1,na.rm = TRUE)
ysmm.AI.count[28]<-mean(sim.counts$epi$AI.ysmm.count.18.3$sim1,na.rm = TRUE)
ysmm.AI.count[29]<-mean(sim.counts$epi$AI.ysmm.count.18.4$sim1,na.rm = TRUE)
ysmm.AI.count[30]<-mean(sim.counts$epi$AI.ysmm.count.18.5$sim1,na.rm = TRUE)


adult.AI.count<-matrix(adult.AI.count,ncol=6,nrow=5, byrow=FALSE)
ysmm.AI.count<-matrix(ysmm.AI.count,nrow=5, byrow=FALSE)

adult.AI.count
ysmm.AI.count


library(xlsx) #load the package
write.xlsx(x = ysmm.AI.count, file = "AICountoutput_1.xlsx",
           sheetName = "YSMM counts", row.names = FALSE)
write.xlsx(x = adult.AI.count, file = "AICountoutput_1.xlsx",
           sheetName = "Adult counts", row.names = FALSE)


