
## whamp analysis file

library(mardham2)
library(EpiModelHPC)


load("~/Camp/scenarios/adol/out/sim.summary.output_t3.rda")




##Table 3.
sims<-c("s133","s145", "s157", "s169", "s215", "s182", "s202", "s174", "s178", "s182", "s186", "s190", "s194", "s198", "s202", "s206", "s210")

table3<-subset(prep.out, data=="s133" | data=="s145" | data=="s157" | data=="s169" | data=="s215"
               | data=="s182" | data=="s202" | data=="s174" | data=="s178" | data=="s182" | data=="s186" | data=="s190"
               | data=="s194" | data=="s198" | data=="s202" | data=="s206" | data=="s210")

table3.out<-cbind(table3$coverage, table3$prev.age18, table3$prev.age18.low95, table3$prev.age18.up95,
                        table3$prev.pop, table3$prev.pop.low95, table3$prev.pop.up95,
                        table3$incid.total.100pt, table3$incid.total.up95.100pt, table3$incid.total.low95.100pt,
                        table3$incid.total.100pt.deb, table3$incid.total.up95.100pt.deb, table3$incid.total.low95.100pt.deb,
                        table3$NIA.all.pt, table3$NIA.deb.pt, table3$PIA, table3$NNT.all, table3$NNT.deb,table3$sim)    


library(xlsx) #load the package
write.xlsx(x = table3.out, file = "scenarios/adol/out/table3.xlsx",
           sheetName = "PrEP sims", row.names = FALSE)