
## whamp analysis file

library(mardham2)
library(EpiModelHPC)




load("~/Camp/scenarios/adol/out/sim.summary.output_t2.rda")

##Table 2.


sims<-c("s1", "s157","s151", "s154", "s148", "s147", "s211", "s212", "s213", "s214")
table2<-subset(prep.out, data=="s1" | data=="s157" | data=="s151" | data=="s154" | data=="s148" | data=="s147" | 
                 data=="s211" | data=="s212" | data=="s213" | data=="s214")

table2.out<-cbind(table2$data, table2$prev.age18, table2$prev.age18.low95, table2$prev.age18.up95,
                  table2$prev.pop, table2$prev.pop.low95, table2$prev.pop.up95,
                  table2$incid.total.100pt, table2$incid.total.up95.100pt, table2$incid.total.low95.100pt,
                  table2$incid.total.100pt.deb, table2$incid.total.up95.100pt.deb, table2$incid.total.low95.100pt.deb,
                  table2$NIA.all.pt, table2$NIA.deb.pt, table2$PIA, table2$NNT.all, table2$NNT.deb)       

library(xlsx) #load the package
write.xlsx(x = table1.out, file = "scenarios/adol/out/table2.xlsx",
           sheetName = "PrEP sims", row.names = FALSE)

