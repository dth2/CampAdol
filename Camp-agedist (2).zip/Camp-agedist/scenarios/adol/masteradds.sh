#!/bin/bash

qsub -t 1-10  -v SIMNO=1 runsim.sh
qsub -t 1-10  -v SIMNO=157 runsim.sh
qsub -t 1-10  -v SIMNO=151 runsim.sh
qsub -t 1-10  -v SIMNO=154 runsim.sh
qsub -t 1-10  -v SIMNO=148 runsim.sh
qsub -t 1-10  -v SIMNO=147 runsim.sh
qsub -t 1-10  -v SIMNO=211 runsim.sh
qsub -t 1-10  -v SIMNO=212 runsim.sh
qsub -t 1-10  -v SIMNO=213 runsim.sh
qsub -t 1-10  -v SIMNO=214 runsim.sh

qsub -q bf -t 1-10  -v SIMNO=133 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=145 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=169 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=215 runsim.sh

qsub -q bf -t 1-10  -v SIMNO=182 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=202 runsim.sh

qsub -q bf -t 1-10  -v SIMNO=174 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=178 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=182 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=186 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=190 runsim.sh

qsub -q bf -t 1-10  -v SIMNO=194 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=198 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=202 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=206 runsim.sh
qsub -q bf -t 1-10  -v SIMNO=210 runsim.sh


