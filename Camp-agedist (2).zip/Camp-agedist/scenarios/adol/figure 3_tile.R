
## whamp analysis file

library(mardham2)
library(EpiModelHPC)


load("~/Camp/scenarios/adol/out/sim.summary.output.rda")

load("~/Camp/scenarios/adol/out/sim.summary.output_temp.rda")

df<-subset(prep.out, data=="s174" | data=="s178" | data=="s182" | data=="s186" | data=="s190"
               | data=="s133" | data=="s145" | data=="s157" | data=="s169" | data=="s215"
               | data=="s194" | data=="s198" | data=="s202" | data=="s206" | data=="s210")
#temp.
df<-subset(prep.out, data=="s174" | data=="s178" | data=="s182" | data=="s186" | data=="s190"
           | data=="s133" | data=="s145" | data=="s157" | data=="s169"
           | data=="s194" | data=="s198" | data=="s202" | data=="s206")

# For paper


library(ggplot2)
library(reshape2)

tt<-data.frame(Adherence.1=c(c1.10,c1.20,c1.30,c1.40,c1.50,c1.60),Adherence.2=c(c2.10,c2.20,c2.30,c2.40,c2.50,c2.60), 
               Adherence.3=c(c3.10,c3.20,c3.30,c3.40,c3.50,c3.60))
tt$Coverage <- paste(c("10%", "20%", "30%", "40%", "50%", "60%"))
tt_melt <- melt(tt)

plot.left <-ggplot(data=tt_melt,
       aes(x=Adherence, y=Coverage, fill=value)) + geom_tile() + 
  geom_text(aes(label=PIA), color='white') + theme_bw()


tt<-data.frame(a1=c(c1.10,c1.20,c1.30,c1.40,c1.50,c1.60),a2=c(c2.10,c2.20,c2.30,c2.40,c2.50,c2.60), 
               a3=c(c3.10,c3.20,c3.30,c3.40,c3.50,c3.60))
tt$row <- paste(c("10%", "20%", "30%", "40%", "50%", "60%"))
tt_melt <- melt(tt)

plot.right <-ggplot(data=tt_melt,
                   aes(x=Adherence, y=Coverage, fill=value)) + geom_tile() + 
  geom_text(aes(label=NNT), color='white') + theme_bw()


tiff(filename = "papers/prepguidelines/analysis/Fig3.tiff", height = 5, width = 9, units = "in", res = 250)
grid.arrange(plot.left, plot.right, ncol = 2)
dev.off()

