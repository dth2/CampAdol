
library("EpiModelHPC")
library("mardham2")

rm(list = ls())
load("scenarios/rdiffhet/est/nwstats.small.rda")
load("scenarios/rdiffhet/est/fit.small.rda")

param <- param.mard(nwstats = st)
init <- init.mard(nwstats = st)
control <- control.mard(nsteps = 100, nsims = 1, ncores = 1,
                        save.other = NULL, save.network = FALSE,
                        verbose = TRUE, verbose.int = 1)

sim <- netsim_par(est, param, init, control)
# save(sim, file = "scenarios/rdiffhet/est/sim.rda")
summary(sim$epi$incid.acte)

sim$epi$i.prev.rg1
sim$epi$i.prev.rg5
