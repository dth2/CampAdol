
## whamp analysis file

library(mardham2)
library(EpiModelHPC)

list.files("scenarios/adol/data/")

s1 <- merge_simfiles(99, indir = "scenarios/adol/data/")






par(mfrow = c(1, 1), mar = c(3,3,1,1), mgp = c(2,1,0))
plot(s1, y = c("i.prev.age6"), ylim = c(0, 0.5), qnts = FALSE, mean.col = 1)
abline(h = seq(0.06, 0.08, 0.01), col = "grey50", lty = 2)

s1$epi$i.prev.age6[1,]<-0
plot(s1, y = c("i.prev.age6"), main = "HIV Prev among AI experienced 18 yr: PrEP=None",ylim = c(0, .2))


prev.18.list<-c( s1$epi$i.prev.age6$sim1[1040],   s1$epi$i.prev.age6$sim2[1040],   s1$epi$i.prev.age6$sim3[1040],   s1$epi$i.prev.age6$sim4[1040],   
          s1$epi$i.prev.age6$sim5[1040],   s1$epi$i.prev.age6$sim6[1040],   s1$epi$i.prev.age6$sim7[1040],   s1$epi$i.prev.age6$sim8[1040],   
          s1$epi$i.prev.age6$sim9[1040],   s1$epi$i.prev.age6$sim10[1040],  s1$epi$i.prev.age6$sim11[1040],  s1$epi$i.prev.age6$sim12[1040],  
          s1$epi$i.prev.age6$sim13[1040],  s1$epi$i.prev.age6$sim14[1040],  s1$epi$i.prev.age6$sim15[1040],  s1$epi$i.prev.age6$sim16[1040],  
          s1$epi$i.prev.age6$sim17[1040],  s1$epi$i.prev.age6$sim18[1040],  s1$epi$i.prev.age6$sim19[1040],  s1$epi$i.prev.age6$sim20[1040],  
          s1$epi$i.prev.age6$sim21[1040],  s1$epi$i.prev.age6$sim22[1040],  s1$epi$i.prev.age6$sim23[1040],  s1$epi$i.prev.age6$sim24[1040],  
          s1$epi$i.prev.age6$sim25[1040],  s1$epi$i.prev.age6$sim26[1040],  s1$epi$i.prev.age6$sim27[1040],  s1$epi$i.prev.age6$sim28[1040],  
          s1$epi$i.prev.age6$sim29[1040],  s1$epi$i.prev.age6$sim30[1040],  s1$epi$i.prev.age6$sim31[1040],  s1$epi$i.prev.age6$sim32[1040],  
          s1$epi$i.prev.age6$sim33[1040],  s1$epi$i.prev.age6$sim34[1040],  s1$epi$i.prev.age6$sim35[1040],  s1$epi$i.prev.age6$sim36[1040],
          s1$epi$i.prev.age6$sim37[1040],  s1$epi$i.prev.age6$sim38[1040],  s1$epi$i.prev.age6$sim39[1040],  s1$epi$i.prev.age6$sim40[1040],  
          s1$epi$i.prev.age6$sim41[1040],  s1$epi$i.prev.age6$sim42[1040],  s1$epi$i.prev.age6$sim43[1040],  s1$epi$i.prev.age6$sim44[1040],  
          s1$epi$i.prev.age6$sim45[1040],  s1$epi$i.prev.age6$sim46[1040],  s1$epi$i.prev.age6$sim47[1040],  s1$epi$i.prev.age6$sim48[1040],  
          s1$epi$i.prev.age6$sim49[1040],  s1$epi$i.prev.age6$sim50[1040],  s1$epi$i.prev.age6$sim51[1040],  s1$epi$i.prev.age6$sim52[1040],  
          s1$epi$i.prev.age6$sim53[1040],  s1$epi$i.prev.age6$sim54[1040],  s1$epi$i.prev.age6$sim55[1040],  s1$epi$i.prev.age6$sim56[1040],  
          s1$epi$i.prev.age6$sim57[1040],  s1$epi$i.prev.age6$sim58[1040],  s1$epi$i.prev.age6$sim59[1040],  s1$epi$i.prev.age6$sim60[1040],  
          s1$epi$i.prev.age6$sim61[1040],  s1$epi$i.prev.age6$sim62[1040],  s1$epi$i.prev.age6$sim63[1040],  s1$epi$i.prev.age6$sim64[1040],  
          s1$epi$i.prev.age6$sim65[1040],  s1$epi$i.prev.age6$sim66[1040],  s1$epi$i.prev.age6$sim67[1040],  s1$epi$i.prev.age6$sim68[1040], 
          s1$epi$i.prev.age6$sim69[1040],  s1$epi$i.prev.age6$sim70[1040],  s1$epi$i.prev.age6$sim71[1040],  s1$epi$i.prev.age6$sim72[1040],
          s1$epi$i.prev.age6$sim73[1040],  s1$epi$i.prev.age6$sim74[1040],  s1$epi$i.prev.age6$sim75[1040],  s1$epi$i.prev.age6$sim76[1040],  
          s1$epi$i.prev.age6$sim77[1040],  s1$epi$i.prev.age6$sim78[1040],  s1$epi$i.prev.age6$sim79[1040],  s1$epi$i.prev.age6$sim80[1040],  
          s1$epi$i.prev.age6$sim81[1040],  s1$epi$i.prev.age6$sim82[1040],  s1$epi$i.prev.age6$sim83[1040],  s1$epi$i.prev.age6$sim84[1040],  
          s1$epi$i.prev.age6$sim85[1040],  s1$epi$i.prev.age6$sim86[1040],  s1$epi$i.prev.age6$sim87[1040],  s1$epi$i.prev.age6$sim88[1040],  
          s1$epi$i.prev.age6$sim89[1040],  s1$epi$i.prev.age6$sim90[1040],  s1$epi$i.prev.age6$sim91[1040],  s1$epi$i.prev.age6$sim92[1040],  
          s1$epi$i.prev.age6$sim93[1040],  s1$epi$i.prev.age6$sim94[1040],  s1$epi$i.prev.age6$sim95[1040],  s1$epi$i.prev.age6$sim96[1040],  
          s1$epi$i.prev.age6$sim97[1040],  s1$epi$i.prev.age6$sim98[1040],  s1$epi$i.prev.age6$sim99[1040],  s1$epi$i.prev.age6$sim100[1040], 
          s1$epi$i.prev.age6$sim101[1040], s1$epi$i.prev.age6$sim102[1040], s1$epi$i.prev.age6$sim103[1040], s1$epi$i.prev.age6$sim104[1040], 
          s1$epi$i.prev.age6$sim105[1040], s1$epi$i.prev.age6$sim106[1040], s1$epi$i.prev.age6$sim107[1040], s1$epi$i.prev.age6$sim108[1040],
          s1$epi$i.prev.age6$sim109[1040], s1$epi$i.prev.age6$sim110[1040], s1$epi$i.prev.age6$sim111[1040], s1$epi$i.prev.age6$sim112[1040], 
          s1$epi$i.prev.age6$sim113[1040], s1$epi$i.prev.age6$sim114[1040], s1$epi$i.prev.age6$sim115[1040], s1$epi$i.prev.age6$sim116[1040], 
          s1$epi$i.prev.age6$sim117[1040], s1$epi$i.prev.age6$sim118[1040], s1$epi$i.prev.age6$sim119[1040], s1$epi$i.prev.age6$sim120[1040], 
          s1$epi$i.prev.age6$sim121[1040], s1$epi$i.prev.age6$sim122[1040], s1$epi$i.prev.age6$sim123[1040], s1$epi$i.prev.age6$sim124[1040], 
          s1$epi$i.prev.age6$sim125[1040], s1$epi$i.prev.age6$sim126[1040], s1$epi$i.prev.age6$sim127[1040], s1$epi$i.prev.age6$sim128[1040], 
          s1$epi$i.prev.age6$sim129[1040], s1$epi$i.prev.age6$sim130[1040], s1$epi$i.prev.age6$sim131[1040], s1$epi$i.prev.age6$sim132[1040], 
          s1$epi$i.prev.age6$sim133[1040], s1$epi$i.prev.age6$sim134[1040], s1$epi$i.prev.age6$sim135[1040], s1$epi$i.prev.age6$sim136[1040], 
          s1$epi$i.prev.age6$sim137[1040], s1$epi$i.prev.age6$sim138[1040], s1$epi$i.prev.age6$sim139[1040], s1$epi$i.prev.age6$sim140[1040], 
          s1$epi$i.prev.age6$sim141[1040], s1$epi$i.prev.age6$sim142[1040], s1$epi$i.prev.age6$sim143[1040], s1$epi$i.prev.age6$sim144[1040],
          s1$epi$i.prev.age6$sim145[1040], s1$epi$i.prev.age6$sim146[1040], s1$epi$i.prev.age6$sim147[1040], s1$epi$i.prev.age6$sim148[1040], 
          s1$epi$i.prev.age6$sim149[1040], s1$epi$i.prev.age6$sim150[1040], s1$epi$i.prev.age6$sim151[1040], s1$epi$i.prev.age6$sim152[1040], 
          s1$epi$i.prev.age6$sim153[1040], s1$epi$i.prev.age6$sim154[1040], s1$epi$i.prev.age6$sim155[1040], s1$epi$i.prev.age6$sim156[1040], 
          s1$epi$i.prev.age6$sim157[1040], s1$epi$i.prev.age6$sim158[1040], s1$epi$i.prev.age6$sim159[1040], s1$epi$i.prev.age6$sim160)


mean(prev.18.list)
