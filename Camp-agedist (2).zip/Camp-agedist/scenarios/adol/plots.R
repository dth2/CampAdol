
suppressPackageStartupMessages(library(mardham2))
rm(list = ls())

load("scenarios/adol/est/sim.rda")

x<-1:1000
#Plot debut.
plot(x,sim$epi$debut[,1],main="sexually debuted", xlab="weeks",ylab="YSMM count")

#Plot HIV Prevalence.
plot(x,sim$epi$i.prev[,1],main="HIV Prevalence", xlab="weeks",ylab="YSMM count")

#Plot HIV Incidence.
plot(x,sim$epi$incid[,1],main="HIV Incidence", xlab="weeks",ylab="YSMM count")

#Plot HIV Incidence.
plot(x,heat,main="HIV Incidence by source", xlab="weeks",ylab="YSMM count", col='red')
points(x,sim$epi$incid.acte[,1], col='green')
points(x,sim$epi$incid.chrn[,1], col="blue")
points(x,sim$epi$incid.aids[,1], col="black")

#Plot HIV Diagnosis.
plot(x,sim$epi$diag[,1],main="HIV Diagnosis", xlab="weeks",ylab="YSMM count")

x<-cbind(sim$epi$diag[,1],sim$epi$undiag[,1])

table(sim$attr[[1]]$has.debuted)
table(sim$attr[[1]]$evertested)
table(sim$attr[[1]]$riskg)
table(floor(sim$attr[[1]]$age))
table(sim$attr[[1]]$stage)


