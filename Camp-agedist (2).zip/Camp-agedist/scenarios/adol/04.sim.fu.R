
library("EpiModelHPC")
library("mardham2")

rm(list = ls())
load("scenarios/adol/est/sim.rda")


# Parameterization --------------------------------------------------------

param <- sim$param
init <- sim$init
control <- control.adol(nsteps = 2600, nsims = 16, par.type = "mpi", ncores=16,
                        initialize.FUN = reinit.mard)


# Simulation --------------------------------------------------------------

resim <- netsim_par(sim, param, init, control)
save(resim, file = "scenarios/adol/est/sim.restart.rda")
