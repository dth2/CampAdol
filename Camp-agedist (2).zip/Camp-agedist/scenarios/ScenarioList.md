# CAMP Scenario List

This is a description of the scenario folders for the CAMP project.

* **a2a:** Apples to apples comparison with mardham1 software.
* **rdiff:** Original racial differences in parameters models.
* **rdiffrev:** Updates the rdiff scenario to use revised (lower) one-off AI rates.
* **rdiffhet:** Adds quantile risk groups to the rdiffrev scenario.
* **requal:** Original averaged parameters over race model (code out of date).
* **p1:** The race-homogenous model to be used for Year 1 paper 1
