
## Analysis for Apples2Apples

library(EpiModel)
rm(list = ls())
setwd("scenarios/a2a/")

# Compare ERGMs
list.files("apples/")
load("apples/fit.main.rda")
load("apples/fit.pers.rda")
load("apples/fit.inst.rda")

load("est/fit.rda")
ls()

names(mardham.model.main.apples2apples)
summary(mardham.model.main.apples2apples$fit)
summary(est[[1]]$fit)

round(cbind(coef(mardham.model.main.apples2apples$fit),
      coef(est[[1]]$fit)), 3)
round(cbind(coef(mardham.model.pers.apples2apples$fit),
      coef(est[[2]]$fit)), 3)
round(cbind(coef(mardham.model.inst.apples2apples),
      coef(est[[3]]$fit)), 3)

rm(list = ls())


# mardham1 ----------------------------------------------------------------

# Compare simulations
load("apples/sim.rda")
m1 <- mardham.sim.apples2apples.A
rm("mardham.sim.apples2apples.A")
names(m1)
str(m1, max.level = 1)
names(m1[[1]])
sapply(m1[[1]], object.size)/1000000
for (i in 1:length(m1)) {
  m1[[i]]$deg.dists <- NULL
  m1[[i]]$nD.main <- NULL
  m1[[i]]$nD.pers <- NULL
  m1[[i]]$nD.inst <- NULL
  m1[[i]]$atts.curr <- NULL
  m1[[i]]$disc.ai <- NULL
}
names(m1[[1]]$summ)

i.num <- data.frame(m1[[1]]$summ$p)
i.num.B <- data.frame(m1[[1]]$summ$p.B)
i.num.W <- data.frame(m1[[1]]$summ$p.W)
for (i in 2:10) {
  i.num[, i] <- m1[[i]]$summ$p
  i.num.B[, i] <- m1[[i]]$summ$p.B
  i.num.W[, i] <- m1[[i]]$summ$p.W
}
head(i.num)
head(i.num.B)
head(i.num.W)

num <- data.frame(m1[[1]]$summ$n)
num.B <- data.frame(m1[[1]]$summ$n.B)
num.W <- data.frame(m1[[1]]$summ$n.W)
for (i in 2:10) {
  num[, i] <- m1[[i]]$summ$n
  num.B[, i] <- m1[[i]]$summ$n.B
  num.W[, i] <- m1[[i]]$summ$n.W
}
head(num)
head(num.B)

plot(rowMeans(num), type = "l", lwd = 2, ylim = c(8000, 12000))

head(num.W)

prev <- i.num/num
prev.B <- i.num.B/num.B
prev.W <- i.num.W/num.W
head(prev)
head(prev.B)
head(prev.W)

rowMeans(prev)[2100]
plot(rowMeans(prev), ylim = c(0.2, 0.3))

lprev <- as.numeric(tail(prev, 1))
lprev.B <- as.numeric(tail(prev.B, 1))
lprev.W <- as.numeric(tail(prev.W, 1))
summary(lprev)
summary(lprev.B)
summary(lprev.W)

mean(as.numeric(tail(num, 1)))
mean(as.numeric(tail(num.B, 1)))
mean(as.numeric(tail(num.W, 1)))

comb_dat <- function(x, var) {
  df <- data.frame(x[[1]]$summ[[var]])
  for (i in 2:10) {
    df[, i] <- x[[i]]$sum[[var]]
  }
  names(df) <- paste0("sim", 1:10)
  return(df)
}
num <- comb_dat(m1, "n")
head(num)

i.num <- comb_dat(m1, "p")
num <- comb_dat(m1, "n")
prev <- i.num/num
mprev <- rowMeans(prev)

par(mar = c(3,3,1,1), mgp = c(2,1,0))
plot(mprev, type = "l", lwd = 2, ylim = c(0.2, .4))
lines(df$i.prev, col = "red", lwd = 3)

plot(rowMeans(comb_dat(m1, "n")), type = "l", lwd = 2, ylim = c(8000, 12000))
lines(df$num, col = "red", lwd = 3)

plot(lowess(rowMeans(comb_dat(m1, "dgp"))), type = "l", lwd = 2, ylim = c(0, 10))
lines(lowess(df$dth.dis[-1]), col = "red", lwd = 2)

# > summary(lprev)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
# 0.2562  0.2603  0.2641  0.2648  0.2697  0.2764
# > summary(lprev.B)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
# 0.2218  0.2309  0.2382  0.2360  0.2419  0.2431
# > summary(lprev.W)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
# 0.2836  0.2881  0.2904  0.2934  0.2987  0.3078


# mardham2 ----------------------------------------------------------------

list.files("scenarios/a2a/data/")
load("data/mardham2.a2a.rda")
load("scenarios/a2a/data/sim.n5000.rda")
ls()

df <- as.data.frame(sim)
df$i.prev
df$i.prev.B
df$i.prev.W

tail(df$i.prev)

df$num
df$num.B
df$num.W

par(mar = c(3,3,1,1), mgp = c(2,1,0))
plot(sim, y = c("i.prev", "i.prev.B", "i.prev.W"), leg = TRUE, ylim = c(0.2, 0.4))

plot(sim, y = "num")


sim <- netdx(est[[3]], nsims = 10, nsteps = 100, dynamic = TRUE)
sim

pdf(file = "edges.pdf", h = 8, w = 12)
par(mar = c(3,3,1,1), mgp = c(2,1,0), mfrow = c(1,3))
plot(simsm, type = "formation", stats = "edges", network = 1)
plot(simsm, type = "formation", stats = "edges", network = 2)
plot(simsm, type = "formation", stats = "edges", network = 3)
dev.off()

md.main <- md.casl <- md.inst <- matrix(NA, nrow = 2599, ncol = 25)
for (i in 1:25) {
  n <- simsm$epi$num[2:2600, i]

  ed.main <- simsm$stats$nwstats[[i]]$m$edges
  ed.casl <- simsm$stats$nwstats[[i]]$p$edges
  ed.inst <- simsm$stats$nwstats[[i]]$i$edges

  md.main[, i] <- ed.main/(n/2)
  md.casl[, i] <- ed.casl/(n/2)
  md.inst[, i] <- ed.inst/(n/2)
}

rm.md.main <- rowMeans(md.main)
rm.md.casl <- rowMeans(md.casl)
rm.md.inst <- rowMeans(md.inst)

mean(tail(rm.md.main), 1000)
mean(tail(rm.md.casl), 1000)
mean(tail(rm.md.inst), 1000)


pdf(file = "meandegree.pdf", h = 8, w = 12)
target.md <- c(1440/5000, 2023/5000, 722/5000)
plot(rm.md.main, ylim = c(0, 0.6), type = "l", lwd = 2, col = "black")
abline(h = target.md[1], col = "black", lty = 2, lwd = 2)
lines(rm.md.casl, lwd = 2, col = "red")
abline(h = target.md[2], col = "red", lty = 2, lwd = 2)
lines(rm.md.inst, lwd = 2, col = "blue")
abline(h = target.md[3], col = "blue", lwd = 2, lty = 2)
legend("topright", legend = c("main", "casl", "inst"), lty = 1, col = c(1,2,4), lwd = 3, bty = "n")
dev.off()

target.md
names(simsm$stats$nwstats$sim5)

dput(as.data.frame(simsm)$incid)


plot(sim, y = "tx.naive")
naive.prev <- df$tx.naive/df$i.num
plot(naive.prev, ylim = c(0, 1), type = "l")

plot(sim, y = "num")

names(df)
plot(rowMeans(sim$epi$dth.gen))
plot(rowMeans(sim$epi$dth.dis))
plot(sim, y = "dth.gen", sim.lines = TRUE, sims = 1)

simsm <- get_sims(sim, sims = 1:10)
head(simsm$epi$dth.gen, 25)
simsm$epi$dth.gen[1000:1250, ]
