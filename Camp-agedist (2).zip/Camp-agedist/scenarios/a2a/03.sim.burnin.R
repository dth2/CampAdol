
library("EpiModelHPC")
library("mardham2")

rm(list = ls())
load("scenarios/a2a/est/nwstats.rda")
load("scenarios/a2a/est/fit.rda")

param <- param.mard(nwstats = st)
init <- init.mard(nwstats = st)
control <- control.mard(nsteps = 5, nsims = 1,
                        save.other = c("attr", "temp"),
                        save.network = TRUE,
                        verbose = TRUE,
                        verbose.int = 1)

sim <- netsim(est, param, init, control)
# save(sim, file = "scenarios/a2a/est/sim.rda")
