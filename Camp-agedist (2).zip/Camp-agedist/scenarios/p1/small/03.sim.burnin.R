
## Paper 1 simulation test file -- 2k

library("mardham2")

rm(list = ls())
load("scenarios/p1/est/nwstats.2k.rda")
load("scenarios/p1/est/fit.2k.rda")

param <- param.mard(nwstats = st,
                    race.method = 1,
                    cond.pers.always.prob = 0.216, ## 0.38
                    cond.inst.always.prob = 0.326, ## 0.55
                    ai.scale = 1.28,
                    prep.elig.model = "cdc3",
                    prep.coverage = 0.5,
                    prep.start = 30,
                    prep.risk.int = 182)
init <- init.mard(nwstats = st, prev.B = 0.22, prev.W = 0.22)
control <- control.mard(nsteps = 30, nsims = 1, ncores = 1,
                        prevfull = TRUE,
                        save.other = c("attr", "temp", "riskh"),
                        save.network = TRUE,
                        verbose = TRUE, verbose.int = 1)

# sim <- netsim(est, param, init, control)
sim <- netsim(est, param, init, control)

df <- as.data.frame(sim)
mean(df$cprob.always.pers, na.rm = TRUE)
mean(df$cprob.always.inst, na.rm = TRUE)
