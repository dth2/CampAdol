
## Paper 1 simulation test file

library("mardham2")

rm(list = ls())
load("scenarios/p1/est/nwstats.rda")
load("scenarios/p1/est/fit.rda")

param <- param.mard(nwstats = st, race.method = 1, prep.elig.model = "uai.any",
                    prep.coverage = 0.5, prep.start = 30)
init <- init.mard(nwstats = st)
control <- control.mard(nsteps = 100, nsims = 1, prevfull = TRUE,
                        save.other = NULL, save.network = FALSE,
                        save.other = "attr", verbose = TRUE, verbose.int = 1)

sim <- netsim(est, param, init, control)
