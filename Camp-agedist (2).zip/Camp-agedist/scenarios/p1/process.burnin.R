
library(EpiModelHPC)

list.files("/net/proj/camp/data")

sim <- merge_simfiles(1300, ftype = "min", indir = "/net/proj/camp/data")
names(sim)

s1 <- get_sims(sim, sims = "mean", var = "i.prev")
tail(as.data.frame(s1)$i.prev)

sim <- s1
save(sim, file = "temp.rda")
