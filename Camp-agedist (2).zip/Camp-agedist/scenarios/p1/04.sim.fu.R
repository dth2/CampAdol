
library("EpiModelHPC")
library("mardham2")

rm(list = ls())
load("scenarios/rdiff/est/sim.rda")


# Parameterization --------------------------------------------------------

param <- sim$param
init <- sim$init
control <- control.mard(nsteps = 2605, start = 2601, nsims = 1,
                        initialize.FUN = reinit.mard)


# Simulation --------------------------------------------------------------

resim <- netsim(sim, param, init, control)
save(resim, file = "scenarios/rdiffhet/est/sim.restart.rda")
