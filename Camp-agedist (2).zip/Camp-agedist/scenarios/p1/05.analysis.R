
## rdiffhet analysis file

rm(list=ls())
library(mardham2)
library(EpiModelHPC)

cbind(list.files("/net/proj/camp/data/"))
par(mfrow = c(1, 1), mar = c(3,3,1,1), mgp = c(2,1,0))

fn <- list.files("/net/proj/camp/data", full.names = TRUE)[10]
sims <- list()
for (i in seq_along(fn)) {
  load(fn[i])
  sims[[i]] <- sim
}

df <- as.data.frame(sims[[2]])
tail(df$i.prev)
calc_eql(sims[[2]], nsteps = 200)

mean(tail(df$incid.acte, 100))/mean(tail(df$incid), 100)

pal <- brewer_ramp(length(sims), "Blues")
for (i in seq_along(sims)) {
  plot(sims[[i]], y = "i.num", ylim = c(0, 0.4),
       qnts = 0.5, mean.col = pal[i], add = i > 1)
}
abline(h = 0.25)

mod_fit("/net/proj/camp/data", job.nos = 1200:1210)

load("/net/proj/camp/data/sim.n1401.rda")
sfu <- truncate_sim(sim, 2550)
plot(sfu, y = "i.prev", ylim = c(0, 0.3), qnts = 1)
