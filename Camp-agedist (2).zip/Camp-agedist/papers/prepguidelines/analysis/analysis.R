
## p1 analysis file

rm(list = ls())
library(mardham2)
source("papers/prepguidelines/analysis/fx.R")

# Build analysis dataset --------------------------------------------------

# Run on hyak
get_epi(indir = "data/save/", outdir = "data/save/analysis",
        vars = c("num", "i.prev", "incid", "prepCov", "prepElig", "prepCurr"),
        suffix = "lim")


# Testing -----------------------------------------------------------------

cbind(list.files("papers/prepguidelines/data/"))
par(mfrow = c(1, 1), mar = c(3,3,1,1), mgp = c(2,1,0))

fn <- list.files("sim/data", full.names = TRUE)[c(9, 17, 21, 37)]
fn <- list.files("sim/data", full.names = TRUE)[34:37]
sims <- list()
for (i in seq_along(fn)) {
  load(fn[i])
  sim <- truncate_sim(sim, at = 2550)
  sims[[i]] <- sim
}

df <- as.data.frame(sims[[1]])
tail(df$i.prev)

# for harvard talk
pdf(file = "prep.pdf", height = 8, width = 8, pointsize = 16)
par(mfrow = c(1, 1), mar = c(3,3,1,1), mgp = c(2,1,0))
pal <- brewer_ramp(length(sims), "Set1")
for (i in seq_along(sims)) {
  plot(sims[[i]], y = "i.prev", ylim = c(0, 0.3),
       qnts = 0.5, mean.col = pal[i], qnts.col = pal[i], add = i > 1,
       ylab = "Prevalence", xlab = "Weeks From Intervention Start")
}
legend("bottomleft", legend = c("Coverage = 20%", "Coverage = 40%",
                                 "Coverage = 60%", "Coverage = 80%"),
       lwd = 2, col = pal, bty = "n")
dev.off()


# Table 2 -----------------------------------------------------------------

steps <- 52 *  25

## Base model: sim.n2000 ##
load("papers/prepguidelines/data/sim.n2000.lim.rda")
sim.base <- truncate_sim(sim, at = 2600)

mn <- as.data.frame(sim.base)
ql <- as.data.frame(sim.base, out = "qnt", qval = 0.25)
qu <- as.data.frame(sim.base, out = "qnt", qval = 0.75)

# prevalence
round(data.frame(mean = mn$i.prev[steps], ql = ql$i.prev[steps], qu = qu$i.prev[steps]), 3)

ir.base <- (sum(mn$incid)/sum((1 - mn$i.prev) * mn$num)) * 52 * 1e5
ir.base

incid.base <- sum(mn$incid)


## Condition CDC1: sim.n2125
load("papers/prepguidelines/data/sim.n2125.lim.rda")
t3.stats(sim, ir.base, incid.base)

## Condition CDC2: sim.n2129
load("papers/prepguidelines/data/sim.n2129.lim.rda")
t3.stats(sim, ir.base, incid.base)

## Condition CDC3: sim.n2133
load("papers/prepguidelines/data/sim.n2133.lim.rda")
t3.stats(sim, ir.base, incid.base)

## Condition CDC4: sim.n2137
load("papers/prepguidelines/data/sim.n2137.lim.rda")
t3.stats(sim, ir.base, incid.base)

## Condition 1a: sim.n2101
load("papers/prepguidelines/data/sim.n2101.lim.rda")
t3.stats(sim, ir.base, incid.base)

## Condition 1b: sim.n2105
load("papers/prepguidelines/data/sim.n2105.lim.rda")
t3.stats(sim, ir.base, incid.base)

## Condition 2a: sim.n2109
load("papers/prepguidelines/data/sim.n2109.lim.rda")
t3.stats(sim, ir.base, incid.base)

## Condition 2b: sim.n2113
load("papers/prepguidelines/data/sim.n2113.lim.rda")
t3.stats(sim, ir.base, incid.base)

## Condition 3a: sim.n2117
load("papers/prepguidelines/data/sim.n2117.lim.rda")
t3.stats(sim, ir.base, incid.base)

## Condition 3b: sim.n2121
load("papers/prepguidelines/data/sim.n2121.lim.rda")
t3.stats(sim, ir.base, incid.base)



# Table 3 ----------------------------------------------------------------------

rm(list = ls())
source("papers/prepguidelines/analysis/fx.R")

load("papers/prepguidelines/data/sim.n2000.lim.rda")
sim.base <- truncate_sim(sim, at = 2600)

mn <- as.data.frame(sim.base)
ir.base <- (sum(mn$incid)/sum((1 - mn$i.prev) * mn$num)) * 52 * 1e5
incid.base <- sum(mn$incid)


## Vary coverage ##

# CDC 3 scenarios
load("papers/prepguidelines/data/sim.n2132.lim.rda")
t3.stats(sim, ir.base, incid.base)

load("papers/prepguidelines/data/sim.n2133.lim.rda")
t3.stats(sim, ir.base, incid.base)

load("papers/prepguidelines/data/sim.n2134.lim.rda")
t3.stats(sim, ir.base, incid.base)

load("papers/prepguidelines/data/sim.n2135.lim.rda")
t3.stats(sim, ir.base, incid.base)


## Adherence ##

load("papers/prepguidelines/data/sim.n2400.lim.rda")
sim$param$prep.class.effect[1]
t3.stats(sim, ir.base, incid.base)

load("papers/prepguidelines/data/sim.n2401.lim.rda")
sim$param$prep.class.effect[1]
t3.stats(sim, ir.base, incid.base)

load("papers/prepguidelines/data/sim.n2402.lim.rda")
sim$param$prep.class.effect[1]
t3.stats(sim, ir.base, incid.base)

load("papers/prepguidelines/data/sim.n2403.lim.rda")
sim$param$prep.class.effect[1]
t3.stats(sim, ir.base, incid.base)

load("papers/prepguidelines/data/sim.n2404.lim.rda")
sim$param$prep.class.effect[1]
t3.stats(sim, ir.base, incid.base)


## Risk reassessment x Risk Interval ##

# Risk assess = No #

load("papers/prepguidelines/data/sim.n2201.lim.rda")
t3.stats(sim, ir.base, incid.base)

load("papers/prepguidelines/data/sim.n2205.lim.rda")
t3.stats(sim, ir.base, incid.base)


# Risk assess = Yes #

load("papers/prepguidelines/data/sim.n2210.lim.rda")
t3.stats(sim, ir.base, incid.base)

load("papers/prepguidelines/data/sim.n2301.lim.rda")
t3.stats(sim, ir.base, incid.base)

load("papers/prepguidelines/data/sim.n2209.lim.rda")
t3.stats(sim, ir.base, incid.base)



# Figure 1 ----------------------------------------------------------------

# Prevalence Curves by Coverage Level, CDC 1 versus CDC 3

# CDC 3 partitions
load("papers/prepguidelines/data/sim.n2105.lim.rda")
c1 <- truncate_sim(sim, at = 2600)

load("papers/prepguidelines/data/sim.n2113.lim.rda")
c2 <- truncate_sim(sim, at = 2600)

load("papers/prepguidelines/data/sim.n2117.lim.rda")
c3 <- truncate_sim(sim, at = 2600)

load("papers/prepguidelines/data/sim.n2133.lim.rda")
cdc3 <- truncate_sim(sim, at = 2600)

# CDC3 by coverage
load("papers/prepguidelines/data/sim.n2132.lim.rda")
c20.3 <- truncate_sim(sim, at = 2600)

load("papers/prepguidelines/data/sim.n2133.lim.rda")
c40.3 <- truncate_sim(sim, at = 2600)

load("papers/prepguidelines/data/sim.n2134.lim.rda")
c60.3 <- truncate_sim(sim, at = 2600)

load("papers/prepguidelines/data/sim.n2135.lim.rda")
c80.3 <- truncate_sim(sim, at = 2600)


pdf(file = "sim/analysis/P1Fig1.pdf", height = 6, width = 12, pointsize = 16)
par(mfrow = c(1, 2), mar = c(3,3,2.5,1), mgp = c(2,1,0))
pal <- RColorBrewer::brewer.pal(4, "Set1")
plot(1,1, type = "n", bty = "n", axes = FALSE,
     xlab = "Years Since Intervention Start",
     ylab = "Prevalence", ylim = c(0.16, 0.26), xlim = c(0, 1300),
     main = "CDC3 Model Decomposition")
plot(c1, y = "i.prev", ylim = c(0.16, 0.26),
     qnts = FALSE, mean.col = pal[1], qnts.col = pal[1], add = TRUE)
plot(c2, y = "i.prev", ylim = c(0, 0.3),
     qnts = FALSE, mean.col = pal[2], qnts.col = pal[2], add = TRUE)
plot(c3, y = "i.prev", ylim = c(0, 0.3),
     qnts = FALSE, mean.col = pal[3], qnts.col = pal[3], add = TRUE)
plot(cdc3, y = "i.prev", ylim = c(0, 0.3),
     qnts = FALSE, mean.col = pal[4], qnts.col = pal[4], add = TRUE)
axis(1, at = seq(0,25,5)*52, labels = seq(0,25,5))
axis(2, at = seq(0.16, 0.26, 0.02))
legend("topright", legend = c("1b", "2b", "3a", "Union"),
       lwd = 3, col = pal, bty = "n")

plot(1, 1, type = "n", bty = "n", axes = FALSE,
     xlab = "Years Since Intervention Start",
     ylab = "Prevalence", ylim = c(0, 0.3), xlim = c(0, 1300),
     main = "CDC3 Model by Coverage")
plot(c20.3, y = "i.prev", ylim = c(0, 0.3),
     qnts = 0.5, mean.col = pal[1], qnts.col = pal[1], add = TRUE,
     ylab = "Prevalence", xlab = "Weeks From Intervention Start",
     main = "CDC3 Model by Coverage")
plot(c40.3, y = "i.prev", ylim = c(0, 0.3),
     qnts = 0.5, mean.col = pal[2], qnts.col = pal[2], add = TRUE)
plot(c60.3, y = "i.prev", ylim = c(0, 0.3),
     qnts = 0.5, mean.col = pal[3], qnts.col = pal[3], add = TRUE)
plot(c80.3, y = "i.prev", ylim = c(0, 0.3),
     qnts = 0.5, mean.col = pal[4], qnts.col = pal[4], add = TRUE)
axis(1, at = seq(0,25,5)*52, labels = seq(0,25,5))
axis(2, at = seq(0, 0.3, 0.05))
legend("bottomleft", legend = c("20%", "40%", "60%", "80%"),
       lwd = 3, col = pal, bty = "n")
dev.off()



# Figure 2 ----------------------------------------------------------------

rm(list = ls())

# load data

load("papers/prepguidelines/data/sim.n2000.lim.rda")
sim.base <- truncate_sim(sim, at = 2600)

mn <- as.data.frame(sim.base)
ir.base <- (sum(mn$incid)/sum((1 - mn$i.prev) * mn$num)) * 52 * 1e5
incid.base <- sum(mn$incid)


load("papers/prepguidelines/data/sim.n2201.lim.rda") # Check once resimulation complete
riNm3 <- truncate_sim(sim, at = 2600)
riNm3.df <- as.data.frame(riNm3)

ir <- (colSums(riNm3$epi$incid)/
         sum((1 - riNm3.df$i.prev) * riNm3.df$num)) * 52 * 1e5
riNm3.nia <- round(ir.base - unname(ir), 1)

py.on.prep <- unname(colSums(riNm3$epi$prepCurr))/52
riNm3.nnt <- py.on.prep/(incid.base - unname(colSums(riNm3$epi$incid)))


load("papers/prepguidelines/data/sim.n2133.lim.rda")
riNm6 <- truncate_sim(sim, at = 2600)
riNm6.df <- as.data.frame(riNm6)

ir <- (colSums(riNm6$epi$incid)/
         sum((1 - riNm6.df$i.prev) * riNm6.df$num)) * 52 * 1e5
riNm6.nia <- round(ir.base - unname(ir), 1)

py.on.prep <- unname(colSums(riNm6$epi$prepCurr))/52
riNm6.nnt <- py.on.prep/(incid.base - unname(colSums(riNm6$epi$incid)))


load("papers/prepguidelines/data/sim.n2205.lim.rda")
riNm12 <- truncate_sim(sim, at = 2600)
riNm12.df <- as.data.frame(riNm12)

ir <- (colSums(riNm12$epi$incid)/
         sum((1 - riNm12.df$i.prev) * riNm12.df$num)) * 52 * 1e5
riNm12.nia <- round(ir.base - unname(ir), 1)

py.on.prep <- unname(colSums(riNm12$epi$prepCurr))/52
riNm12.nnt <- py.on.prep/(incid.base - unname(colSums(riNm12$epi$incid)))


load("papers/prepguidelines/data/sim.n2210.lim.rda")
riYm3 <- truncate_sim(sim, at = 2600)
riYm3.df <- as.data.frame(riYm3)

ir <- (colSums(riYm3$epi$incid)/
         sum((1 - riYm3.df$i.prev) * riYm3.df$num)) * 52 * 1e5
riYm3.nia <- round(ir.base - unname(ir), 1)

py.on.prep <- unname(colSums(riYm3$epi$prepCurr))/52
riYm3.nnt <- py.on.prep/(incid.base - unname(colSums(riYm3$epi$incid)))


load("papers/prepguidelines/data/sim.n2301.lim.rda")
riYm6 <- truncate_sim(sim, at = 2600)
riYm6.df <- as.data.frame(riYm6)

ir <- (colSums(riYm6$epi$incid)/
         sum((1 - riYm6.df$i.prev) * riYm6.df$num)) * 52 * 1e5
riYm6.nia <- round(ir.base - unname(ir), 1)

py.on.prep <- unname(colSums(riYm6$epi$prepCurr))/52
riYm6.nnt <- py.on.prep/(incid.base - unname(colSums(riYm6$epi$incid)))


load("papers/prepguidelines/data/sim.n2209.lim.rda")
riYm12 <- truncate_sim(sim, at = 2600)
riYm12.df <- as.data.frame(riYm12)

ir <- (colSums(riYm12$epi$incid)/
         sum((1 - riYm12.df$i.prev) * riYm12.df$num)) * 52 * 1e5
riYm12.nia <- round(ir.base - unname(ir), 1)

py.on.prep <- unname(colSums(riYm12$epi$prepCurr))/52
riYm12.nnt <- py.on.prep/(incid.base - unname(colSums(riYm12$epi$incid)))

# left panel = NIA
pal <- EpiModel::transco(RColorBrewer::brewer.pal(3, "Set1"), 0.8)

pdf(file = "papers/prepguidelines/analysis/P1Fig2.pdf", height = 6, width = 12, pointsize = 16)
par(mfrow = c(1, 2), mar = c(3,3,2.5,1), mgp = c(2,1,0))
df.nia <- data.frame(riNm3.nia, riNm6.nia, riNm12.nia, riYm3.nia, riYm6.nia, riYm12.nia)
boxplot(df.nia, col = pal[c(1,1,1,2,2,2)], outline = FALSE, axes = FALSE,
        main = "Number of Infections Averted", ylab = "NIA per 100k PY")
axis(1, at = 1:6, labels = paste0("Int=", c(3,6,12,3,6,12)))
axis(2, at = seq(900, 1600, 100))

# right panel = NNT
df.nnt <- data.frame(riNm3.nnt, riNm6.nnt, riNm12.nnt, riYm3.nnt, riYm6.nnt, riYm12.nnt)
boxplot(df.nnt, col = pal[c(1,1,1,2,2,2)], outline = FALSE, axes = FALSE,
        main = "Number Needed to Treat", ylab = "NNT for 1 PY")
axis(1, at = 1:6, labels = paste0("Int=", c(3,6,12,3,6,12)))
axis(2, at = seq(20, 50, 5))
legend("topright", legend = c("Reassess=No", "Reassess=Yes"),
       col = pal[1:2], lwd = 5, bty = "n",cex = 0.9)
dev.off()
