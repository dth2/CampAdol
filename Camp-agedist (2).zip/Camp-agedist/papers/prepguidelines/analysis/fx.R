
## P1 functions

t3.stats <- function(sim, ir.base, incid.base) {
  sim <- truncate_sim(sim, at = 2600)
  mn <- as.data.frame(sim)
  ql <- as.data.frame(sim, out = "qnt", qval = 0.25)
  qu <- as.data.frame(sim, out = "qnt", qval = 0.75)

  t25 <- 52 * 25

  cat("\nPrev:")
  print(round(data.frame(mean = mn$i.prev[t25], ql = ql$i.prev[t25], qu = qu$i.prev[t25]), 3))

  cat("Incid:")
  print(round(data.frame(
    mean = (mean(tail(mn$incid, 100)) /
              ((1 - mean(tail(mn$i.prev, 100))) * mean(tail(mn$num, 100)))) * 52 * 100,
    ql = (mean(tail(ql$incid, 100)) /
            ((1 - mean(tail(ql$i.prev, 100))) * mean(tail(ql$num, 100)))) * 52 * 100,
    qu = (mean(tail(qu$incid, 100)) /
            ((1 - mean(tail(qu$i.prev, 100))) * mean(tail(qu$num, 100)))) * 52 * 100), 2))

  cat("NIA:")
  ir <- (colSums(sim$epi$incid)/
           sum((1 - mn$i.prev) * mn$num)) * 52 * 1e5
  vec.nia <- round(ir.base - unname(ir), 1)
  print(round(data.frame(mean = mean(vec.nia),
                         ql = quantile(vec.nia, 0.25, names = FALSE),
                         qu = quantile(vec.nia, 0.75, names = FALSE)), 0))

  cat("PIA:")
  vec.pia <- vec.nia/ir.base
  print(round(data.frame(mean = mean(vec.pia),
                         ql = quantile(vec.pia, 0.25, names = FALSE),
                         qu = quantile(vec.pia, 0.75, names = FALSE)), 3))

  cat("NNT:")
  py.on.prep <- unname(colSums(sim$epi$prepCurr))/52
  vec.nnt <- py.on.prep/(incid.base - unname(colSums(sim$epi$incid)))
  print(round(data.frame(mean = mean(vec.nnt),
                         ql = quantile(vec.nnt, 0.25, names = FALSE),
                         qu = quantile(vec.nnt, 0.75, names = FALSE)), 0))

}
