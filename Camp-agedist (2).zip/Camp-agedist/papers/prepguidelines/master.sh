#!/bin/bash

# base model
qsub -q bf -t 1-7 -m n -v SIMNO=2000,COVR=0,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh

## Table 2 core models
qsub -q bf -t 1-7 -m n -v SIMNO=2100,COVR=0.4,MODEL=uai.mono2.nt.6mo,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2101,COVR=0.4,MODEL=uai.mono1.nt.6mo,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2102,COVR=0.4,MODEL=uai.nonmonog,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2103,COVR=0.4,MODEL=uai.nmain,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2104,COVR=0.4,MODEL=ai.sd.mc,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2105,COVR=0.4,MODEL=uai.sd.mc,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2106,COVR=0.4,MODEL=cdc1,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2107,COVR=0.4,MODEL=cdc2,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2108,COVR=0.4,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2109,COVR=0.4,MODEL=cdc4,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh


## Table 3 sensitivity analyses

# Coverage
qsub -q bf -t 1-7 -m n -v SIMNO=2200,COVR=0.2,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2201,COVR=0.4,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2202,COVR=0.6,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2203,COVR=0.8,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0 runsim.fu.sh

# Adherence
qsub -q bf -t 1-7 -m n -v SIMNO=2300,COVR=0.4,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0.1 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2301,COVR=0.4,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0.2 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2302,COVR=0.4,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0.3 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2303,COVR=0.4,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0.4 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2304,COVR=0.4,MODEL=cdc3,RISKR=FALSE,RISKINT=182,PCE=0.5 runsim.fu.sh

# Risk assessment x Risk interval
qsub -q bf -t 1-7 -m n -v SIMNO=2400,COVR=0.4,MODEL=cdc3,RISKR=FALSE,RISKINT=91,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2401,COVR=0.4,MODEL=cdc3,RISKR=FALSE,RISKINT=364,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2402,COVR=0.4,MODEL=cdc3,RISKR=TRUE,RISKINT=91,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2403,COVR=0.4,MODEL=cdc3,RISKR=TRUE,RISKINT=182,PCE=0 runsim.fu.sh
qsub -q bf -t 1-7 -m n -v SIMNO=2404,COVR=0.4,MODEL=cdc3,RISKR=TRUE,RISKINT=364,PCE=0 runsim.fu.sh
