
## Packages
library("methods")
suppressPackageStartupMessages(library("EpiModelHPC"))
library("mardham2")

## Environmental Arguments
args <- commandArgs(trailingOnly = TRUE)
simno <- args[1]
jobno <- args[2]
sprev <- as.numeric(args[3])


## Parameters
fsimno <- paste(simno, jobno, sep = ".")
load("est/nwstats.2k.rda")

param <- param.mard(nwstats = st, acute.rr = 6,
                    last.neg.test.B.int = (301+315)/2,
                    mean.test.B.int = (301+315)/2,
                    last.neg.test.W.int = (301+315)/2,
                    mean.test.W.int = (301+315)/2,
                    tt.traj.B.prob = (c(0.077, 0.000, 0.356, 0.567)+
                                      c(0.052, 0.000, 0.331, 0.617))/2,
                    tt.traj.W.prob = (c(0.077, 0.000, 0.356, 0.567)+
                                      c(0.052, 0.000, 0.331, 0.617))/2,
                    tx.init.B.prob = (0.092+0.127)/2,
                    tx.init.W.prob = (0.092+0.127)/2,
                    tx.halt.B.prob = (0.0102+0.0071)/2,
                    tx.halt.W.prob = (0.0102+0.0071)/2,
                    tx.reinit.B.prob = (0.00066+0.00291)/2,
                    tx.reinit.W.prob = (0.00066+0.00291)/2,
                    disc.outset.main.B.prob = (0.685+0.889)/2,
                    disc.outset.main.W.prob = (0.685+0.889)/2,
                    disc.outset.pers.B.prob = (0.527+0.828)/2,
                    disc.outset.pers.W.prob = (0.527+0.828)/2,
                    disc.inst.B.prob = (0.445+0.691)/2,
                    disc.inst.W.prob = (0.445+0.691)/2,
                    circ.B.prob = (0.874+0.918)/2,
                    circ.W.prob = (0.874+0.918)/2,
                    ccr5.B.prob = (c(0, 0.034) + c(0.021, 0.176))/2,
                    ccr5.W.prob = (c(0, 0.034) + c(0.021, 0.176))/2,
                    base.ai.main.BB.rate = (0.17+0.26+0.23)/3,
                    base.ai.main.BW.rate = (0.17+0.26+0.23)/3,
                    base.ai.main.WW.rate = (0.17+0.26+0.23)/3,
                    base.ai.pers.BB.rate = (0.11+0.16+0.14)/3,
                    base.ai.pers.BW.rate = (0.11+0.16+0.14)/3,
                    base.ai.pers.WW.rate = (0.11+0.16+0.14)/3,
                    cond.main.BB.prob = (0.38+0.10+0.15)/3,
                    cond.main.BW.prob = (0.38+0.10+0.15)/3,
                    cond.main.WW.prob = (0.38+0.10+0.15)/3,
                    cond.pers.BB.prob = (0.39+0.11+0.16)/3,
                    cond.pers.BW.prob = (0.39+0.11+0.16)/3,
                    cond.pers.WW.prob = (0.39+0.11+0.16)/3,
                    cond.inst.BB.prob = (0.49+0.15+0.22)/3,
                    cond.inst.BW.prob = (0.49+0.15+0.22)/3,
                    cond.inst.WW.prob = (0.49+0.15+0.22)/3,
                    vv.iev.BB.prob = (0.42+0.56+0.49)/3,
                    vv.iev.BW.prob = (0.42+0.56+0.49)/3,
                    vv.iev.WW.prob = (0.42+0.56+0.49)/3)
init <- init.mard(nwstats = st, prev.B = sprev, prev.W = sprev)
control <- control.mard(simno = fsimno, nsteps = 52 * 50,
                        nsims = 16, ncores = 16, save.int = 100,
                        verbose.int = 5, save.network = TRUE,
                        save.other = c("attr", "temp"))


## Simulation
netsim_hpc("est/fit.2k.rda", param, init, control, compress = "xz",
            save.min = TRUE, save.max = TRUE)

# vars <- list(SPREV = 0.21)
# qsub_master(simno.start = 1300, nsubjobs = 16, backfill = TRUE,
#             vars = vars, append = TRUE,
#             outfile = "/net/proj/camp/master.sh")
