
## Packages
library("methods")
suppressPackageStartupMessages(library("mardham2"))

## Environmental Arguments
args <- commandArgs(trailingOnly = TRUE)
simno <- args[1]
jobno <- args[2]


## Parameters
fsimno <- paste(simno, jobno, sep = ".")
load("est/nwstats.5k.rda")

param <- param.mard(nwstats = st, race.method = 1,
                    cond.pers.always.prob = 0.216, ## 0.38
                    cond.inst.always.prob = 0.326, ## 0.55
                    ai.scale = 1.28)
init <- init.mard(nwstats = st, prev.B = 0.258, prev.W = 0.258)
control <- control.mard(simno = fsimno, nsteps = 50 * 52,
                        nsims = 16, ncores = 16, save.int = 100,
                        verbose.int = 5, save.network = TRUE,
                        save.other = c("attr", "temp", "riskh"))


## Simulation
netsim_hpc("est/fit.5k.rda", param, init, control, compress = "xz",
            save.min = TRUE, save.max = TRUE)

# vars <- list(AIS = 1.28, SPREV = seq(0.251, 0.26, 0.001))
# qsub_master(simno.start = "auto", nsubjobs = 16, backfill = TRUE,
#             vars = vars, append = TRUE,
#             outfile = "/net/proj/camp/master.sh")

## Process burn-in

sim <- merge_simfiles(1000, ftype = "max")
sim <- get_sims(sim, sims = "mean", var = "i.prev")
tail(as.data.frame(sim)$i.prev)
save(sim, file = "est/p1.burnin.rda")
