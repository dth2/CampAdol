
## build master.sh script

# base non-prep model
# vars <- list(COVR = 0,
#              MODEL = "cdc3",
#              RISKR = FALSE,
#              RISKINT = 182,
#              PCE = 0)
# qsub_master(simno.start = 2000,
#             nsubjobs = 7, backfill = 1,
#             vars = vars, append = TRUE,
#             runsimfile = "runsim.fu.sh",
#             outfile = "sim/master.sh")


# Main counterfactual models
vars <- list(COVR = 0.4,
             MODEL = c("uai.mono2.nt.6mo", "uai.mono1.nt.6mo",
                       "uai.nonmonog", "uai.nmain", "ai.sd.mc", "uai.sd.mc",
                       "cdc1", "cdc2", "cdc3", "cdc4"),
             RISKR = FALSE, RISKINT = 182)
qsub_master(simno.start = 2100,
            nsubjobs = 7, backfill = TRUE,
            vars = vars, append = TRUE,
            runsimfile = "runsim.fu.sh",
            outfile = "sim/master.sh")


# Sensitivity analyses on coverage

vars <- list(COVR = seq(0.2, 0.8, 0.2),
             MODEL = "cdc3",
             RISKR = FALSE,
             RISKINT = 182,
             PCE = 0)
qsub_master(simno.start = 2200,
            nsubjobs = 7, backfill = TRUE,
            vars = vars, append = TRUE,
            runsimfile = "runsim.fu.sh",
            outfile = "sim/master.sh")

# Sensitivity analyses on adherence

vars <- list(COVR = 0.4,
             MODEL = "cdc3",
             RISKR = FALSE,
             RISKINT = 182,
             PCE = seq(0.1, 0.5, 0.1))
qsub_master(simno.start = 2400,
            nsubjobs = 7, backfill = 2,
            vars = vars, append = TRUE,
            runsimfile = "runsim.fu.sh",
            outfile = "sim/master.sh")



# Sensitivity analyses on risk reassessment

vars <- list(COVR = seq(0.2, 0.8, 0.2),
             MODEL = "cdc3",
             RISKR = TRUE, RISKINT = 182)
qsub_master(simno.start = 2300,
            nsubjobs = 7, backfill = TRUE,
            vars = vars, append = TRUE,
            runsimfile = "runsim.fu.sh",
            outfile = "sim/master.sh")



