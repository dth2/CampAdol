
## Packages
library("methods")
suppressPackageStartupMessages(library("mardham2"))


## Environmental Arguments
args <- commandArgs(trailingOnly = TRUE)
simno <- args[1]
jobno <- args[2]
model <- args[3]
covr <- as.numeric(args[4])
riskr <- as.logical(args[5])
riskint <- as.numeric(args[6])
pce <- as.numeric(args[7])


## Parameters
fsimno <- paste(simno, jobno, sep = ".")
load("est/nwstats.5k.rda")

param <- param.mard(nwstats = st,
                    race.method = 1,
                    cond.pers.always.prob = 0.216, ## 0.38
                    cond.inst.always.prob = 0.326, ## 0.55
                    ai.scale = 1.28,
                    prep.start = 2601,
                    prep.elig.model = model,
                    prep.coverage = covr,
                    prep.risk.reassess = riskr,
                    prep.risk.int = riskint,
                    prep.class.effect = c(pce, 0.75, 0.90))
init <- init.mard(nwstats = st)
control <- control.mard(simno = fsimno, start = 2601, nsteps = 52 * 75,
                        nsims = 16, ncores = 16, save.int = 100,
                        verbose.int = 5, save.network = FALSE, save.other = NULL,
                        initialize.FUN = reinit.mard)


## Simulation
netsim_hpc("est/p1.burnin.rda", param, init, control, compress = "xz",
            save.min = TRUE, save.max = FALSE)

