library(testthat)
library(mardham2)

test_check("mardham2")
