
#include "ergm_stubs.c"
