	
	*	What is tt.traj.freq.X and what is the treatment calculator?
tt.traj.X is the proportion of men who enter into one of four testing and treatment trajectories:
    - never tests
    - tests, never initiates tx
    - initiates tx, when on tx is partially suppressed
    - initiates tx, when on tx is fully suppressed

treatment calculator is a whole other set of analyses (some in excel, some in R) that allow me to back calculate through simulation what the tt.traj values need to be in order to get the right cross-sectional care cascade given different survival times for the different trajectories.

	*	Instant mean degree is multiplied by 7/100. Is that because the base unit is in 100 person-days and you are converting to per-person weeks?
yups

	*	Are exp.ai.main.XX coital frequency rates per week?
yups. all rates in the model should be per week, as currently parametrized
	
	*	Is base.prob.uaigai.XX the probability of unprotected AI given any AI? 
yes. it's really poorly named. should be prob.condom or similar. dont know what i was thinking
	
	*	What is vv.prob.iev.BB (I can't even gander what vv refers to!)?

VV means "versatile-versatile," obvs! ;-) This is the probability that two versatile men will engage in intra-event versatility ("flipping") given that they're having AI
	
*	Are your base ASMRs in yearly units?
yup

*	There is no serosorting in the network component of the model. Is that right?? 
yup, if serosorting is narrowly defined to mean initial partner selection

*	Why are you storing so many attributes on the NW that are not in the NW model (e.g., inst.ai.class, inf.status, diag.status, tx.status…)? Is the idea that your models would later include these attributes in network terms?
yup. although at this stage i doubt many of them ever will be used.
