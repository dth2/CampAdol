
# ins pos / rec neg
head(disc.ip)

sum(disc.ip$uai[race[disc.ip$r] == "W"] %in% 0:1)
sum(disc.ip$uai[race[disc.ip$r] == "B"] %in% 0:1)

mean(disc.ip$prob[race[disc.ip$r] == "W"])/
mean(disc.ip$prob[race[disc.ip$r] == "B"])


# ins neg / rec pos
head(disc.rp)

sum(disc.rp$uai[race[disc.rp$i] == "W"] %in% 0:1)
sum(disc.rp$uai[race[disc.rp$i] == "B"] %in% 0:1)

mean(disc.rp$prob[race[disc.rp$i] == "W"])/
mean(disc.rp$prob[race[disc.rp$i] == "B"])


(sum(disc.ip$uai[race[disc.ip$r] == "W"] %in% 0:1) + sum(disc.rp$uai[race[disc.rp$i] == "W"] %in% 0:1))/
(sum(disc.ip$uai[race[disc.ip$r] == "B"] %in% 0:1) + sum(disc.rp$uai[race[disc.rp$i] == "B"] %in% 0:1))

mean(c(disc.ip$prob[race[disc.ip$r] == "W"], disc.rp$prob[race[disc.rp$i] == "W"]))/
mean(c(disc.ip$prob[race[disc.ip$r] == "B"], disc.rp$prob[race[disc.rp$i] == "B"]))

mean(c(disc.ip$prob[race[disc.ip$r] == "B"], disc.rp$prob[race[disc.rp$i] == "B"]))/
mean(c(disc.ip$prob[race[disc.ip$r] == "W"], disc.rp$prob[race[disc.rp$i] == "W"]))

