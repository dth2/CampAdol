
# Act rate per year mean
ar.m <- 7

# Probability of UAI per act mean
puai.m <- 0.78

# Cumulative probability of UAI per year
1 - (1 - puai.m)^ar.m

cp.uai <- list()
l.props <- seq(0.1, 0.9, 0.1)
for (i in seq_along(l.props)) {
  # Three variables: low risk proportion, act rate in low, and uai prob in low
  l.prop <- l.props[i]
  h.prop <- 1 - l.prop
  ar.l <- seq(0, 2, 0.05)

  # Let's keep this fixed
  puai.l <- 0.78

  # Act rate and uai prob in high calculated
  ar.h <- (ar.m - (l.prop * ar.l)) / h.prop
  puai.h <- (puai.m - (l.prop * puai.l)) / h.prop

  # The group-specific cumulative probability of UAI
  1 - (1 - puai.h)^ar.h
  1 - (1 - puai.l)^ar.l

  # The overall cumulative probability of UAI
  cp.uai[[i]] <- ((1 - (1 - puai.l)^ar.l) * l.prop) + ((1 - (1 - puai.h)^ar.h) * h.prop)

  if (i == 1) {
    plot(ar.l, cp.uai[[i]], type = "l", lwd = 2, ylim = c(0.4, 0.8))
    abline(h = 0.57, lty = 2)
  } else {
    lines(ar.l, cp.uai[[i]], lwd = 2, col = i)
  }
}





