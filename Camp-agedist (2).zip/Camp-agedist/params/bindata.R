
## Bivariate correlated binomial distribution example with "bindata" package

library("bindata")

# Parameters of joint distribution
size <- 1e5
p1 <- 0.38
p2 <- 0.55
rho <- 0.5

# Create one pair of correlated binomial values
trials <- rmvbin(size, c(p1,p2), bincorr = (1 - rho) * diag(2) + rho)
colSums(trials)/nrow(trials)

cor(trials[, 1], trials[, 2])

# Distributions of p2
prop.table(table(trials[, 1], trials[, 2]), margin = 1)

# Distributions of p1
prop.table(table(trials[, 1], trials[, 2]), margin = 2)
