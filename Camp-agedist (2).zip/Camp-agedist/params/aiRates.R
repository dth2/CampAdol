
## Analysis of AI Rates for mardham2

d <- read.csv("params/aiRates.csv")
d <- d[!is.na(d$daily_prob), ]

black <- ifelse(d$RACE_INC == "Black/African American", 1, 0)
rate <- d$daily_prob
head(data.frame(black, rate))

mean(rate) * 360
mean(rate[black == 0]) * 360
mean(rate[black == 1]) * 360

par(mar = c(3,3,1,1), mgp = c(2,1,0))
plot(density(rate, from = 0))
abline(v = mean(rate), lty = 2)

plot(density(rate, from = 0))
lines(density(rate[black == 0], from = 0), col = 2)
lines(density(rate[black == 1], from = 0), col = 3)

# Overall means
sr <- sort(rate)
qsize <- floor(length(sr) / 5)

m1 <- mean(sr[1:qsize])
m1[2] <- mean(sr[(1*qsize):(2*qsize)])
m1[3] <- mean(sr[(2*qsize):(3*qsize)])
m1[4] <- mean(sr[(3*qsize):(4*qsize)])
m1[5] <- mean(sr[(4*qsize):length(sr)])

m1
m1 * 360
1/(m1 * 360)

# White means
sr <- sort(rate[black == 0])
qsize <- floor(length(sr) / 5)

mw <- mean(sr[1:qsize])
mw[2] <- mean(sr[(1*qsize):(2*qsize)])
mw[3] <- mean(sr[(2*qsize):(3*qsize)])
mw[4] <- mean(sr[(3*qsize):(4*qsize)])
mw[5] <- mean(sr[(4*qsize):length(sr)])

mw
mw * 360
1/(mw * 360)

# Black means
sr <- sort(rate[black == 1])
qsize <- floor(length(sr) / 5)

mb <- mean(sr[1:qsize])
mb[2] <- mean(sr[(1*qsize):(2*qsize)])
mb[3] <- mean(sr[(2*qsize):(3*qsize)])
mb[4] <- mean(sr[(3*qsize):(4*qsize)])
mb[5] <- mean(sr[(4*qsize):length(sr)])

mb
mb * 360
1/(mb * 360)

data.frame(mtot = m1, mwhite = mw, mblack = mb) * 360
round(1/(data.frame(mtot = m1, mwhite = mw, mblack = mb)))
