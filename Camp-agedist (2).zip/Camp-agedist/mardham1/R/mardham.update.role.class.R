mardham.update.role.class <- function(mard, role.trans.matrix, curr.time) {
  if (sum(colSums(role.trans.matrix) != 1)>0) stop("Column sums in argument role.trans.matrix must all equal 1.")
  old.role.class <- mard$atts.curr$role.class
  
  new.role.class <- sapply(1:length(old.role.class), function(x) sample( c('I','V','R'), size=1, prob= 
          role.trans.matrix[,1] * (old.role.class[x]=='I') + 
          role.trans.matrix[,2] * (old.role.class[x]=='V') + 
          role.trans.matrix[,3] * (old.role.class[x]=='R')))
  mard$atts.curr$role.class <- new.role.class
  return(mard)
}
