mardham.sim.parallel <- function(mard, param, control) {
  
  if (control$nsims == 1 | control$ncores == 1) {
    sim <- list()
    for (i in 1:control$nsims) sim[[i]] <- mardham.sim(mard, param, control)
  } else {
    cluster.size <- min(control$nsims, control$ncores)
    cl <- doMPI::startMPIcluster(cluster.size)
    doMPI::registerDoMPI(cl)
    sim <- foreach(i = 1:control$nsims) %dopar% {
      require(mardham)
      nsims = 1
      currsim = i
      control$output.file <- paste(control$output.file,i,".csv",sep="")
      mardham.sim(mard, param, control)
    }
    doMPI::closeCluster(cl)
  }
  
  return(sim)
}
