#' Simulate a mardham
#' @param mard An object of class mardham that emerges from XXX.
#' @param control$sim.duration The number of timesteps to be simulated.
#' @param control$init.timestep The timestep in the various structures within mard from which to begin the simulation. Defaults to 1. Higher values are useful when one wishes to continue a previous simulation.
#' @param param$main.model The object of class netest (from EpiModel) that governs the main partnership formation and dissolution processes
#' @param param$pers.model The object of class netest (from EpiModel) that governs the persistent partnership formation and dissolution processes
#' @param param$inst.model The object of class netest (from EpiModel) that governs the instantaneous partnership
#' @param param$births.exp.B The expected number of new arrivals of Black MSM per time step
#' @param param$births.exp.W The expected number of new arrivals of White MSM per time step
#' @param param$birth.age The age (in years) of the new arrivals
#' @param param$asmr.B A vector of age-specific mortality rates (non-AIDS) for Black MSM. These will be looked up by position of actors' age in years, regardless of births.age.  Thus, 27-year-old men will experience param$asmr.B[27]; one should therefore have zeros or NAs in this vector for the ages less than births.age
#' @param param$asmr.W A vector of age-specific mortality rates (non-AIDS) for White MSM. See param$asmr.B
#' @param control$age.unit The number of time steps in a year, i.e. the reciprocal of the increase in age per timestep
#' @param param$betabase.URAI  Transmissibility for a man having unprotected receptive anal intercourse with a positive man at set point viral load
#' @param param$betabase.UIAI  Transmissibility for an uncircumcised man having unprotected insertive anal intercourse with a positive man at set point viral load
#' @param param$betamult.acute The factor by which acute infection is extra-infectious, above and beyond that predicted by elevated viral load
#' @param param$betamult.circ The factor by which to multiply infectivity from insertive anal sex when the negative insertive partner is circumcised
#' @param param$betamult.condom The factor by which to multiply infectivity for anal sex when a condom is used
#' @param param$vl.acute.rise.dur The number of time steps over which viral load rises during the initial phase of acute infection
#' @param param$vl.acute.peak Peak viral load (in log10 units) at the height of acute infection
#' @param param$vl.acute.fall.dur The number of time steps over which viral load falls during the latter phase of acute infection
#' @param param$vl.set.point Set point viral load for all men (in log10 units)
#' @param param$vl.aids.onset The number of time steps of infection after which the AIDS stage will initiate for a man who has never been on treatment
#' @param param$vl.aids.dur The duration of the AIDS stage
#' @param param$vl.fatal The viral load obtained at the end of the AIDS stage, at which death from AIDS occurs.  Note that the code can handle param$vl.fatal being lower than param$vl.acute.peak, as it tests for both a sufficiently high viral load and presence in the AIDS stage to deterine AIDS deaths
#' @param param$num.inst.ai.classes The number of quantiles into which men should be divided in determining their levels of one-odd AI
#' @param param$testing.pattern Whether HIV testing is memoryless (occurs with fixed probabilty, without regard to time since previous test) or occurs in fixed intervals.  Options are "memoryless" or "interval".
#' @param param$test.window.period The length of the HIV test's window period
#' @param param$mean.test.interv.B The mean intertest interval for Black MSM who test
#' @param param$mean.test.interv.W The mean intertest interval for White MSM who test
#' @param param$prob.tx.init.B The probability per time step that a Black MSM who has tested positive will initiate treatment for the very first time
#' @param param$prob.tx.init.W The probability per time step that a White MSM who has tested positive will initiate treatment for the very first time
#' @param param$tt.traj.freq.B The proportion of Black MSM who enter into the four testing/treatment trajectories.  Values represent, in order, the propotions who are "NN" (never test or treat), "YN" (test, but then never initiate treatment), "YP" (test, and then when on treatment achieve partial suppression), "YF" (test, and then when on treatment achieve full suppression)
#' @param param$tt.traj.freq.W The proportion of White MSM who enter into the four testing/treatment trajectories. See param$tt.traj.freq.B
#' @param param$prob.tx.halt.B The probability per time step that a Black MSM who is currently on treatment will halt treatment
#' @param param$prob.tx.halt.W The probability per time step that a White MSM who is currently on treatment will halt treatment
#' @param param$prob.tx.reinit.B The probability per time step that a Black MSM who is not currently on treatment but who has been in the past will re-initiate treatment
#' @param param$prob.tx.reinit.W The probability per time step that a White MSM who is not currently on treatment but who has been in the past will re-initiate treatment
#' @param param$max.time.off.tx.part
#' @param param$max.time.on.tx.part
#' @param param$max.time.off.tx.full The number of time steps off treatment that a man who is a full suppressor while on treatment wil last before the onset of the AIDS stage.  Note that this includes the time before diagnosis
#' @param param$full.supp.down.slope For men who are full suppressors, the number of log10 units that viral load falls per time step from treatment initiation or re-initiation until the new level is hit
#' @param param$full.supp.up.slope  For men who are full suppressors, the number of log10 units that viral load rises per time step from treatment halting until the new level is hit
#' @param param$part.supp.down.slope For men who are partial suppressors, the number of log10 units that viral load falls per time step from treatment initiation or re-initiation until the new level is hit
#' @param param$part.supp.up.slope For men who are partial suppressors, the number of log10 units that viral load rises per time step from treatment halting until the new level is hit
#' @param param$vl.full.supp Log10 viral load when fully suppressed
#' @param param$vl.part.supp Log10 viral load when partially suppressed
#' @param control$save.atts.each.step=F Whether the full set of ndoal attributes should be saved for each active man at each time step.  Default is F.  When T, the resulting object can become large quickly, and slow simulation time considerably. Best used for odel exploration and diagnosis on small populations and numbers of time steps
#' @param control$san.start=F
#' @param param$base.exp.ai.BB.main
#' @param param$base.exp.ai.BW.main
#' @param param$base.exp.ai.WW.main
#' @param param$incr.exp.ai.full.supp.main
#' @param param$incr.exp.ai.part.supp.main
#' @param param$redux.exp.ai.diag.main
#' @param param$redux.exp.ai.discl.main
#' @param param$base.exp.ai.BB.pers
#' @param param$base.exp.ai.BW.pers
#' @param param$base.exp.ai.WW.pers
#' @param param$incr.exp.ai.full.supp.pers
#' @param param$incr.exp.ai.part.supp.pers
#' @param param$redux.exp.ai.diag.pers
#' @param param$redux.exp.ai.discl.pers
#' @param param$base.prob.uaigai.BB.main
#' @param param$base.prob.uaigai.BW.main
#' @param param$base.prob.uaigai.WW.main
#' @param param$beta.uaigai.full.supp.main
#' @param param$beta.uaigai.part.supp.main
#' @param param$beta.uaigai.diag.main
#' @param param$beta.uaigai.discl.main
#' @param param$base.prob.uaigai.BB.pers
#' @param param$base.prob.uaigai.BW.pers
#' @param param$base.prob.uaigai.WW.pers
#' @param param$beta.uaigai.full.supp.pers
#' @param param$beta.uaigai.part.supp.pers
#' @param param$beta.uaigai.diag.pers
#' @param param$beta.uaigai.discl.pers
#' @param param$base.prob.uaigai.BB.inst
#' @param param$base.prob.uaigai.BW.inst
#' @param param$base.prob.uaigai.WW.inst
#' @param param$beta.uaigai.full.supp.inst
#' @param param$beta.uaigai.part.supp.inst
#' @param param$beta.uaigai.diag.inst
#' @param param$beta.uaigai.discl.inst
#' @param param$circ.prev.B
#' @param param$circ.prev.W
#' @param param$role.class.freq.B
#' @param param$role.class.freq.W
#' @param param$inst.trans.matrix
#' @param param$role.trans.matrix
#' @param param$disc.main.outset.B
#' @param param$disc.main.outset.W
#' @param param$disc.main.at.diag.B
#' @param param$disc.main.at.diag.W
#' @param param$disc.main.post.diag.B
#' @param param$disc.main.post.diag.W
#' @param param$disc.pers.outset.B
#' @param param$disc.pers.outset.W
#' @param param$disc.pers.at.diag.B
#' @param param$disc.pers.at.diag.W
#' @param param$disc.pers.post.diag.B
#' @param param$disc.pers.post.diag.W
#' @param param$disc.inst.B
#' @param param$disc.inst.W
#' @param param$vv.prob.iev.BB
#' @param param$vv.prob.iev.BW
#' @param param$vv.prob.iev.WW
#' @param control$san.rm.disallowed.role.combo=T
#' @param control$SAN.burnin
#' @param control$use.nD=T
#' @param control$verbose
#'
#' @return XXX
#'
mardham.sim <- function(mard, param, control, ...){

  if(is.null(control$init.timestep)) control$init.timestep <- 1
  if(is.null(control$save.atts.each.step)) control$save.atts.each.step <- F
  if(is.null(control$san.start)) control$san.start <- F
  if(is.null(control$san.rm.disallowed.role.combo))
      control$san.rm.disallowed.role.combo <- T
  if(is.null(control$use.nD)) control$use.nD <- T

  if (class(mard) != "mardham") stop('First argument to mardham.sim must be of class mardham.')
  if(control$save.atts.each.step==T) mard$atts.list <- list()

  if(sum(mard$atts.curr$active) != param$main.model$nwsize) {
    param$main.model$coef.form[1] <- param$main.model$coef.form[1] + log(param$main.model$nwsize) - log(sum(mard$atts.curr$active))
    param$main.model$fit$coef[1] <- param$main.model$fit$coef[1] + log(param$main.model$nwsize) - log(sum(mard$atts.curr$active))
  }
  if(sum(mard$atts.curr$active) != param$pers.model$nwsize) {
    param$pers.model$coef.form[1] <- param$pers.model$coef.form[1] + log(param$main.model$nwsize) - log(sum(mard$atts.curr$active))
    param$pers.model$fit$coef[1] <- param$pers.model$fit$coef[1] + log(param$pers.model$nwsize) - log(sum(mard$atts.curr$active))
  }
  if(sum(mard$atts.curr$active) != param$inst.model$nwsize) {
    param$inst.model$coef[1] <- param$inst.model$coef[1] + log(param$inst.model$nwsize) - log(sum(mard$atts.curr$active))
  }

  if(control$san.start==T) mard <- mardham.san.start(mard=mard,
    main.model=param$main.model,
    pers.model=param$pers.model,
    san.rm.disallowed.role.combo=control$san.rm.disallowed.role.combo,
    SAN.burnin=control$SAN.burnin)

  if (control$use.nD==F & ("networkDynamic"%in%class(mard$nD.main))) mard$nD.main <- network.collapse(mard$nD.main ,at=0)
  if (control$use.nD==F & ("networkDynamic"%in%class(mard$nD.pers))) mard$nD.pers <- network.collapse(mard$nD.pers ,at=0)
  if (control$use.nD==F & ("networkDynamic"%in%class(mard$nD.inst))) mard$nD.inst <- network.collapse(mard$nD.inst ,at=0)

  for (i in control$init.timestep:(control$init.timestep+control$sim.duration-1)) {

      old.popsize <- sum(mard$atts.curr$active)

    # Age
      mard <- mardham.age(mard, control$age.unit, i)

    # Deaths
      old.pop <- c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B' & mard$atts.curr$inf.status==0),
                   sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W' & mard$atts.curr$inf.status==0),
                   sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B' & mard$atts.curr$inf.status==1),
                   sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W' & mard$atts.curr$inf.status==1)
      )
      mard <- mardham.death.gen(mard, param$asmr.B, param$asmr.W, i, control$use.nD)
      new.pop <- c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B' & mard$atts.curr$inf.status==0),
                   sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W' & mard$atts.curr$inf.status==0),
                   sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B' & mard$atts.curr$inf.status==1),
                   sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W' & mard$atts.curr$inf.status==1)
      )
      deaths.gen <- old.pop-new.pop

      old.pop <- c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'), sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W'))
      mard <- mardham.death.aids(mard, param$vl.fatal, i, control$use.nD)
      new.pop <- c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'), sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W'))
      deaths.aids <- old.pop-new.pop

    # Births with bookkeeping
      old.pop <- c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'), sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W'))
      mard <- mardham.births(mard, param$births.exp.B, param$births.exp.W, param$birth.age, i, param$num.inst.ai.classes,
        param$tt.traj.freq.B, param$tt.traj.freq.W, param$circ.prev.B, param$circ.prev.W, param$role.class.freq.B, param$role.class.freq.W,
        param$ccr5.freq.B, param$ccr5.freq.W, control$use.nD)
      new.pop <- c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'), sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W'))
      births <- new.pop-old.pop

    # Update edges terms for new pop size
      new.popsize <- sum(mard$atts.curr$active)
      # param$main.model$formation.fit$coef[1] <- param$main.model$formation.fit$coef[1] + log(old.popsize) - log(new.popsize)
      # param$pers.model$formation.fit$coef[1] <- param$pers.model$formation.fit$coef[1] + log(old.popsize) - log(new.popsize)
      # param$pers.model$coef.diss$coef.adj[1] <- param$pers.model$coef.diss$coef.adj[1] + log(old.popsize) - log(new.popsize)
      param$main.model$coef.form[1] <- param$main.model$coef.form[1] + log(old.popsize) - log(new.popsize)
      param$pers.model$coef.form[1] <- param$pers.model$coef.form[1] + log(old.popsize) - log(new.popsize)
      param$inst.model$coef[1] <- param$inst.model$coef[1] + log(old.popsize) - log(new.popsize)

    # Testing
      mard <- mardham.test(mard, testing.pattern=param$testing.pattern,
        curr.time=i, test.window.period=param$test.window.period,
        mean.test.interv.B=param$mean.test.interv.B,
        mean.test.interv.W=param$mean.test.interv.W)

    # Treatment
      mard <- mardham.tx(mard, prob.tx.init.B=param$prob.tx.init.B,
        prob.tx.init.W=param$prob.tx.init.W, curr.time=i,
        prob.tx.halt.B=param$prob.tx.halt.B,
        prob.tx.halt.W=param$prob.tx.halt.W,
        prob.tx.reinit.B=param$prob.tx.reinit.B,
        prob.tx.reinit.W=param$prob.tx.reinit.W)

    # Progress
      mard <- mardham.progress(mard, curr.time=i, vl.acute.rise.dur=param$vl.acute.rise.dur,
        vl.acute.peak=param$vl.acute.peak,
        vl.acute.fall.dur=param$vl.acute.fall.dur, vl.set.point=param$vl.set.point,
        vl.aids.onset=param$vl.aids.onset, vl.aids.dur=param$vl.aids.dur,
        vl.fatal=param$vl.fatal,
        max.time.on.tx.part=param$max.time.on.tx.part,
        max.time.off.tx.part=param$max.time.off.tx.part,
        max.time.off.tx.full=param$max.time.off.tx.full
      )

    # Viral load
      mard <- mardham.update.vl(mard, curr.time=i, vl.acute.rise.dur=param$vl.acute.rise.dur,
        vl.acute.peak=param$vl.acute.peak,
        vl.acute.fall.dur=param$vl.acute.fall.dur, vl.set.point=param$vl.set.point,
        vl.aids.onset=param$vl.aids.onset, vl.aids.dur=param$vl.aids.dur,
        vl.fatal=param$vl.fatal, max.time.off.tx.part=param$max.time.off.tx.part,
        max.time.on.tx.part=param$max.time.on.tx.part,
        max.time.off.tx.full=param$max.time.off.tx.full,
        full.supp.down.slope = param$full.supp.down.slope,
        full.supp.up.slope = param$full.supp.up.slope,
        part.supp.down.slope = param$part.supp.down.slope,
        part.supp.up.slope = param$part.supp.up.slope,
        vl.full.supp=param$vl.full.supp, vl.part.supp=param$vl.part.supp
      )

    # Change inst.ai.class
      mard <- mardham.update.inst.ai.class(mard, inst.trans.matrix=param$inst.trans.matrix, curr.time=i)

    # Change role.class
      mard <- mardham.update.role.class(mard, role.trans.matrix=param$role.trans.matrix, curr.time=i)

    # Make updates to network object prior to entering relational dynamics
      mard <- mardham.make.updates.to.network(mard)

    # Relational dynamics:

      if (control$use.nD==T) {
        suppressWarnings(
        mard$nD.main <- simulate(mard$nD.main,
          formation=param$main.model$formation, dissolution=param$main.model$dissolution,
          #coef.form=param$main.model$formation.fit$coef, coef.diss=param$main.model$dissolution.fit$coef,
          coef.form=param$main.model$coef.form, coef.diss=param$main.model$coef.diss$coef.adj,
          constraints=param$main.model$constraints,
          time.start=i, time.slices=1, time.offset=0,
          monitor="all", verbose=F,
          control=control.simulate.network(MCMC.burnin.min=1e5)
        ) # TODO control parameters
        )
      } else {

        old.nD.main <- mard$nD.main
        mard$nD.main <- simulate(mard$nD.main,
          formation=param$main.model$formation, dissolution=param$main.model$dissolution,
          coef.form=param$main.model$coef.form, coef.diss=param$main.model$coef.diss$coef.adj,
          constraints=param$main.model$constraints,
          monitor="all", verbose=F,
          control=control.simulate.network(MCMC.burnin.min=1e5))
        asdf <- as.data.frame(mard$nD.main)
        mard$new.edges <- matrix(as.matrix(asdf[asdf$onset==1,c("tail","head")]),ncol=2)
        mard$nD.main <- network.collapse(mard$nD.main, at=1)
        nD.main.edgelist <-  as.edgelist(mard$nD.main)
      }

      mard$nD.pers <- mardham.update.degree(mard$nD.pers, mard$nD.main, deg.type='main', curr.time=i, use.nD=control$use.nD)
      mard$nD.inst <- mardham.update.degree(mard$nD.inst, mard$nD.main, deg.type='main', curr.time=i, use.nD=control$use.nD)

      if (control$use.nD==T) {
        suppressWarnings(
        mard$nD.pers <- simulate(mard$nD.pers,
          formation=param$pers.model$formation, dissolution=param$pers.model$dissolution,
          #coef.form=param$pers.model$formation.fit$coef, coef.diss=param$pers.model$dissolution.fit$coef,
          coef.form=param$pers.model$coef.form, coef.diss=param$pers.model$coef.diss$coef.adj,
          constraints=param$pers.model$constraints,
          time.start=i, time.slices=1, time.offset=0,
          monitor="all", verbose=F,
          control=control.simulate.network(MCMC.burnin.min=1e5)
        ) # TODO control parameters
        )
      } else {
        old.nD.pers <- mard$nD.pers
        mard$nD.pers <- simulate(mard$nD.pers,
          formation=param$pers.model$formation, dissolution=param$pers.model$dissolution,
          coef.form=param$pers.model$coef.form, coef.diss=param$pers.model$coef.diss$coef.adj,
          constraints=param$pers.model$constraints,
          monitor="all", verbose=F,
          control=control.simulate.network(MCMC.burnin.min=1e5))
        asdf <- as.data.frame(mard$nD.pers)
        mard$new.edges <- rbind(mard$new.edges, matrix(as.matrix(asdf[asdf$onset==1,c("tail","head")]),ncol=2))
        mard$nD.pers <- network.collapse(mard$nD.pers, at=1)
        nD.pers.edgelist <-  as.edgelist(mard$nD.pers)
      }

      mard$nD.main <- mardham.update.degree(mard$nD.main, mard$nD.pers, deg.type='pers', curr.time=i, use.nD=control$use.nD)
      mard$nD.inst <- mardham.update.degree(mard$nD.inst, mard$nD.pers, deg.type='pers', curr.time=i, use.nD=control$use.nD)

    # Relational dynamics / AI: Once
      mard <- mardham.append.inst.simulate(mard, param$inst.model, curr.time=i, use.nD=control$use.nD)
      if (control$use.nD ==T) {mard$nD.inst <- tergm:::.add.net.obs.period.spell(mard$nD.inst, i-1, 1)}

    # Disclosure
      mard <- mardham.disclose.dur(mard, type = 'main',
        disc.outset.B=param$disc.main.outset.B, disc.outset.W=param$disc.main.outset.W,
        disc.at.diag.B=param$disc.main.at.diag.B, disc.at.diag.W=param$disc.main.at.diag.W,
        disc.post.diag.B=param$disc.main.post.diag.B, disc.post.diag.W=param$disc.main.post.diag.W,
        curr.time=i, use.nD=control$use.nD)

      mard <- mardham.disclose.dur(mard, type = 'pers',
        disc.outset.B=param$disc.pers.outset.B, disc.outset.W=param$disc.pers.outset.W,
        disc.at.diag.B=param$disc.pers.at.diag.B, disc.at.diag.W=param$disc.pers.at.diag.W,
        disc.post.diag.B=param$disc.pers.post.diag.B, disc.post.diag.W=param$disc.pers.post.diag.W,
        curr.time=i, use.nD=control$use.nD)

      mard <- mardham.disclose.inst(mard, disc.B=param$disc.inst.B, disc.W=param$disc.inst.W,
        curr.time=i, use.nD=control$use.nD)

    #write.table(t(c(i, new.popsize,
      #  sum(mard$atts.curr$race=='B' & mard$atts.curr$active==T),
      #  sum(mard$atts.curr$race=='W' & mard$atts.curr$active==T),
      #  sum(mard$atts.curr$race=='B' & mard$atts.curr$inf.status==1 & mard$atts.curr$active==T),
      #  sum(mard$atts.curr$race=='W' & mard$atts.curr$inf.status==1 & mard$atts.curr$active==T)
      #)),quote=F,row.names=F, file='a.csv', col.names=F, sep=',', append=T)

    # Discordant AI: Main / Pers
      mard <- mardham.disc.ai(mard, type="main", fixed=F,
        base.exp.ai.BB=param$base.exp.ai.BB.main, base.exp.ai.BW=param$base.exp.ai.BW.main,
        base.exp.ai.WW=param$base.exp.ai.WW.main,
        incr.exp.ai.full.supp=param$incr.exp.ai.full.supp.main,
        incr.exp.ai.part.supp=param$incr.exp.ai.part.supp.main,
        redux.exp.ai.diag=param$redux.exp.ai.diag.main,
        redux.exp.ai.discl=param$redux.exp.ai.discl.main,
        curr.time=i, use.nD=control$use.nD)

      mard <- mardham.disc.ai(mard, type="pers", fixed=F,
        base.exp.ai.BB=param$base.exp.ai.BB.pers, base.exp.ai.BW=param$base.exp.ai.BW.pers,
        base.exp.ai.WW=param$base.exp.ai.WW.pers,
        incr.exp.ai.full.supp=param$incr.exp.ai.full.supp.pers,
        incr.exp.ai.part.supp=param$incr.exp.ai.part.supp.pers,
        redux.exp.ai.diag=param$redux.exp.ai.diag.pers,
        redux.exp.ai.discl=param$redux.exp.ai.discl.pers,
        curr.time=i, use.nD=control$use.nD)

    # Discordant AI: Inst
      mard <- mardham.disc.ai(mard, type="inst", fixed=T, 1,1,1,0,0,0,0, curr.time=i, use.nD=control$use.nD)

    # Condom use: Main / Pers / Once
      mard <- mardham.ai.condom.use(mard, type="main",
         base.prob.uaigai.BB=param$base.prob.uaigai.BB.main,
         base.prob.uaigai.BW=param$base.prob.uaigai.BW.main,
         base.prob.uaigai.WW=param$base.prob.uaigai.WW.main,
         beta.uaigai.full.supp=param$beta.uaigai.full.supp.main,
         beta.uaigai.part.supp=param$beta.uaigai.part.supp.main,
         beta.uaigai.diag=param$beta.uaigai.diag.main,
         beta.uaigai.discl=param$beta.uaigai.discl.main,
         curr.time=i)

      mard <- mardham.ai.condom.use(mard, type="pers",
        base.prob.uaigai.BB=param$base.prob.uaigai.BB.pers,
        base.prob.uaigai.BW=param$base.prob.uaigai.BW.pers,
        base.prob.uaigai.WW=param$base.prob.uaigai.WW.pers,
        beta.uaigai.full.supp=param$beta.uaigai.full.supp.pers,
        beta.uaigai.part.supp=param$beta.uaigai.part.supp.pers,
        beta.uaigai.diag=param$beta.uaigai.diag.pers,
        beta.uaigai.discl=param$beta.uaigai.discl.pers,
        curr.time=i)

      mard <- mardham.ai.condom.use(mard, type="inst",
        base.prob.uaigai.BB=param$base.prob.uaigai.BB.inst,
        base.prob.uaigai.BW=param$base.prob.uaigai.BW.inst,
        base.prob.uaigai.WW=param$base.prob.uaigai.WW.inst,
        beta.uaigai.full.supp=param$beta.uaigai.full.supp.inst,
        beta.uaigai.part.supp=param$beta.uaigai.part.supp.inst,
        beta.uaigai.diag=param$beta.uaigai.diag.inst,
        beta.uaigai.discl=param$beta.uaigai.discl.inst,
        curr.time=i)

    # TODO Position: Main / Pers / Inst
      mard <- mardham.position(mard, curr.time = i,
                               vv.prob.iev.BB = param$vv.prob.iev.BB,
                               vv.prob.iev.BW = param$vv.prob.iev.BW,
                               vv.prob.iev.WW = param$vv.prob.iev.WW
                               )

    # Combine UAI
      #mard <- mardham.combine.uai(mard, curr.time=i)
      #UAI.edgelist <- mard$uai.list[[i]][mard$uai.list[[i]][,3]==1, 1:2]

    # Transmission (plus bookkeeping)
      old.prev <- c(sum(mard$atts.curr$inf.status==1 & mard$atts.curr$race=='B'), sum(mard$atts.curr$inf.status==1 & mard$atts.curr$race=='W'))
      mard <- mardham.trans(mard, betabase.URAI=param$betabase.URAI, betabase.UIAI=param$betabase.UIAI,
        betamult.acute=param$betamult.acute, betamult.circ=param$betamult.circ, betamult.condom=param$betamult.condom,
        vl.acute.fall.dur=param$vl.acute.fall.dur, ccr5.heteroz.rr=param$ccr5.heteroz.rr, curr.time=i)
      new.prev <- c(sum(mard$atts.curr$inf.status==1 & mard$atts.curr$race=='B'), sum(mard$atts.curr$inf.status==1 & mard$atts.curr$race=='W'))
      inc <- new.prev - old.prev

    # Make updates to network object at end of time step
      mard <- mardham.make.updates.to.network(mard)

    # Wrapup

      mard$curr.time <- i

      mard$deg.dists[[i]] <- rbind(
        (mard$nD.pers %v% 'deg.main')[mard$atts.curr$active==T],
        (mard$nD.inst %v% 'deg.main')[mard$atts.curr$active==T],
        (mard$nD.main %v% 'deg.pers')[mard$atts.curr$active==T],
        (mard$nD.inst %v% 'deg.pers')[mard$atts.curr$active==T]
        )

      if(control$save.atts.each.step==T) mard$atts.list[[i]] <- mard$atts.curr

      mard <- mardham.make.summ(mard, inc, births, deaths.gen, deaths.aids,
                                control$use.nD, param$vl.full.supp, param$vl.part.supp, i)

      if (control$verbose==T) {
        cat(as.numeric(mard$summ[nrow(mard$summ),]),'\n')
      } else {
        cat('Finishing time step',i,'of',control$sim.duration,'\n')
      }

      if (!is.na(control$output.file)) write.csv(mard$summ, file=control$output.file)

  }
  return(mard)
}
