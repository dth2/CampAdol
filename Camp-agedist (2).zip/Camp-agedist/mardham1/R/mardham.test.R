mardham.test <- function(mard, testing.pattern='memoryless', curr.time, test.window.period,
                     mean.test.interv.B, mean.test.interv.W, ...) {
  
  if ((testing.pattern != 'memoryless') && (testing.pattern != 'interval')) stop ("argument testing.pattern must equal \"memoryless\" or \"interval\".")
  
  if (testing.pattern=='memoryless') {
    testable.B <- which((mard$atts.curr$diag.status == 0 | is.na(mard$atts.curr$diag.status)) & 
                         mard$atts.curr$race == 'B' & mard$atts.curr$tt.traj != 'NN')
    testing.B <- testable.B[rbinom(length(testable.B),1,1/mean.test.interv.B)==1]
    testable.W <- which((mard$atts.curr$diag.status == 0 | is.na(mard$atts.curr$diag.status)) & 
                         mard$atts.curr$race == 'W' & mard$atts.curr$tt.traj != 'NN')
    testing.W <- testable.W[rbinom(length(testable.W),1,1/mean.test.interv.W)==1]
  }

  if (testing.pattern=='interval') {
    time.since.last.neg.test <- curr.time - mard$atts.curr$last.neg.test
    time.since.last.neg.test[is.na(time.since.last.neg.test)] <-
      curr.time - mard$atts.curr$arrival.time[is.na(time.since.last.neg.test)]
    testing.B <- which((mard$atts.curr$diag.status == 0 | is.na(mard$atts.curr$diag.status)) & 
                         mard$atts.curr$race == 'B' & mard$atts.curr$tt.traj != 'NN' & 
                         time.since.last.neg.test >= mean.test.interv.B )
    testing.W <- which((mard$atts.curr$diag.status == 0 | is.na(mard$atts.curr$diag.status)) & 
                         mard$atts.curr$race == 'W' & mard$atts.curr$tt.traj != 'NN' & 
                         time.since.last.neg.test >= mean.test.interv.W)
  }
  
  testing.pos.B <- testing.B[mard$atts.curr$inf.status[testing.B] == 1 & 
    mard$atts.curr$inf.time[testing.B] <= curr.time - test.window.period]
  testing.neg.B <- setdiff(testing.B, testing.pos.B)
  testing.pos.W <- testing.W[mard$atts.curr$inf.status[testing.W] == 1 & 
    mard$atts.curr$inf.time[testing.W] <= curr.time - test.window.period]
  testing.neg.W <- setdiff(testing.W, testing.pos.W)
  
  testing.pos <- c(testing.pos.B,testing.pos.W)
  testing.neg <- c(testing.neg.B,testing.neg.W)
  
  mard$atts.curr$last.neg.test[testing.neg] <- curr.time
  mard$atts.curr$diag.status[testing.pos] <- 1
  mard$atts.curr$diag.time[testing.pos] <- curr.time

  return(mard)
}
