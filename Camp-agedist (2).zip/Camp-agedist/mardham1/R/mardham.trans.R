mardham.trans <- function(mard, betabase.URAI, betabase.UIAI, betamult.acute, betamult.circ, betamult.condom,
                          vl.acute.fall.dur, ccr5.heteroz.rr, curr.time, reorder=T, ...) {
  
  curr.disc.ai <- mard$disc.ai[[curr.time]]
  if (reorder==T) curr.disc.ai <- curr.disc.ai[sample(1:nrow(curr.disc.ai)),]
  ncols <- dim(curr.disc.ai)[2]
  
  # Reorder them by role - ins on the left, rec on the right - with flippers represented twice
  #disc.inspos <- curr.disc.ai[curr.disc.ai$uai==1 & curr.disc.ai$ins %in% c('P','B'), ]
  #disc.recpos <- curr.disc.ai[curr.disc.ai$uai==1 & curr.disc.ai$ins %in% c('N','B'), c(2:1,3:ncols)]
  disc.inspos <- curr.disc.ai[curr.disc.ai$ins %in% c('P','B'), ]
  disc.recpos <- curr.disc.ai[curr.disc.ai$ins %in% c('N','B'), c(2:1,3:ncols)]
  names(disc.inspos)[1:2] <- c('i','r')
  names(disc.recpos)[1:2] <- c('i','r')
  
  # Identify trans prob
  # TODO LONGTERM: Make this a generalized passable function
  inspos.vl <- mard$atts.curr$vl[disc.inspos[,1]]  	                # P1's viral load	
  inspos.stage <- mard$atts.curr$stage[disc.inspos[,1]]             # P1's stage
  inspos.stage.time <- mard$atts.curr$stage.time[disc.inspos[,1]]   # P1's day w/in stage
  inspos.ccr5 <- mard$atts.curr$ccr5[disc.inspos[,2]]               # P2's CCR5 genotype
  
  transprob.inspos <- betabase.URAI*2.45^(inspos.vl-4.5) * 
    betamult.acute ^ (inspos.stage == 'AR') *
    (1+(betamult.acute-1)*(vl.acute.fall.dur-inspos.stage.time)/vl.acute.fall.dur)^(inspos.stage == 'AF') * 
    betamult.condom ^ (disc.inspos$uai==0) *
    0 ^ (inspos.ccr5 == "DD") *
    ccr5.heteroz.rr ^ (inspos.ccr5 == "DW")
    
  recpos.vl <- mard$atts.curr$vl[disc.recpos[,2]]  	                # P2's viral load	
  recpos.stage <- mard$atts.curr$stage[disc.recpos[,2]]             # P2's stage
  recpos.stage.time <- mard$atts.curr$stage.time[disc.recpos[,2]]   # P2's day w/in stage
  recpos.circ <- mard$atts.curr$circ[disc.recpos[,1]]	              # P1's circ status
  recpos.ccr5 <- mard$atts.curr$ccr5[disc.recpos[,1]]               # P1's CCR5 genotype
  
  transprob.recpos <- betabase.UIAI*2.45^(recpos.vl-4.5) * 
    betamult.acute ^ (recpos.stage == 'AR') *
    (1+(betamult.acute-1)*(vl.acute.fall.dur-recpos.stage.time)/vl.acute.fall.dur)^(recpos.stage == 'AF') *
    betamult.circ ^ (recpos.circ == 1) * 
    betamult.condom ^ (disc.recpos$uai==0) * 
    0 ^ (recpos.ccr5 == "DD") *
    ccr5.heteroz.rr ^ (recpos.ccr5 == "DW")
  
  # Determine trans
  
  trans.inspos <- rbinom(length(transprob.inspos), 1, transprob.inspos)
  trans.recpos <- rbinom(length(transprob.recpos), 1, transprob.recpos)
  
  # Update attributes
  # Note: if a person is seemingly infected by two different people in the same time step, or by the same 
  # person during two different acts in the same time step, then the code below will assign the actual transmission 
  # to the one appearing last in the list. This is OK; with reorder=T so the order of acts in the timestep is random.
  # Even if one were to set reorder=F it's a very rare event for someone to be double-infected in a time step presumably. 
  
  if(sum(trans.inspos,trans.recpos) >0) {
  
    # Remove these once it's clear the don't change anything.
    # inspos.tx <- mard$atts.curr$tx.status[disc.recpos[,1]] # P1's stage
    # recpos.tx <- mard$atts.curr$tx.status[disc.inspos[,2]] # P2's stage
    # inspos.diag <- mard$atts.curr$diag.status[disc.recpos[,1]] # P1's stage
    # recpos.diag <- mard$atts.curr$diag.status[disc.inspos[,2]] # P2's stage
    
    infected <- c(disc.inspos[trans.inspos==1,2],disc.recpos[trans.recpos==1,1])
    infector <- c(disc.inspos[trans.inspos==1,1],disc.recpos[trans.recpos==1,2])
    inf.role <- c(rep(0,sum(trans.inspos)),rep(1,sum(trans.recpos)))
    inf.type <- c(disc.inspos[trans.inspos==1,'type'],disc.recpos[trans.recpos==1,'type'])
    
    inf.stage <- mard$atts.curr$stage[infector]
    inf.diag <- mard$atts.curr$diag.status[infector]
    inf.tx <- mard$atts.curr$tx.status[infector]
        
    mard$atts.curr$inf.status[infected] <- 1
    mard$atts.curr$inf.time[infected] <- curr.time
    mard$atts.curr$vl[infected] <- 0
    mard$atts.curr$stage[infected] <- 'AR'
    mard$atts.curr$stage.time[infected] <- 0
    mard$atts.curr$diag.status[infected] <- 0
    mard$atts.curr$tx.status[infected] <- 0
    
    mard$atts.curr$infector[infected] <- infector
    mard$atts.curr$inf.role[infected] <- inf.role
    mard$atts.curr$inf.type[infected] <- inf.type
    mard$atts.curr$inf.diag[infected] <- inf.diag
    mard$atts.curr$inf.tx[infected] <- inf.tx
    mard$atts.curr$inf.stage[infected] <- inf.stage        

    mard$atts.curr$cum.time.on.tx[infected] <- 0
    mard$atts.curr$cum.time.off.tx[infected] <- 0    
}  

#write.table(t(c( nrow(curr.disc.ai), nrow(disc.inspos), nrow(disc.recpos),
#  mean(transprob.inspos), mean(transprob.recpos), sum(trans.inspos), sum(trans.recpos),
#  sum(mard$atts.curr$inf.status==1 & mard$atts.curr$active==1)
#  )),quote=F,row.names=F, file='a.csv', col.names=F, sep=', ', append=T)

return(mard)

}