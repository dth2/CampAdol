
mardham.make.summ <- function(mard, inc, births, deaths.gen, deaths.aids,
                              use.nD, vl.full.supp, vl.part.supp, curr.time) {

  summ <- data.frame(time=integer(0), 
     n=integer(0), n.B=integer(0), n.W=integer(0),
     i=integer(0), i.B=integer(0), i.W=integer(0),
     p=numeric(0), p.B=numeric(0), p.W=numeric(0),
     b=integer(0), b.B=integer(0), b.W=integer(0),
     dgn=integer(0), dgn.B=integer(0), dgn.W=integer(0),
     dgp=integer(0), dgp.B=integer(0), dgp.W=integer(0),
     da=integer(0), da.B=integer(0), da.W=integer(0),
     e.M=integer(0) ,e.P=integer(0), e.I=integer(0),
     md.MB=numeric(0), md.MW=numeric(0), md.PB=numeric(0),
     md.PW=numeric(0), md.IB=numeric(0), md.IW=numeric(0),
     undiag = numeric(0), undiag.B = numeric(0), undiag.W = numeric(0),
     diag = numeric(0), diag.B = numeric(0), diag.W = numeric(0),
     tx.naive=numeric(0), tx.naive.B=numeric(0), tx.naive.W=numeric(0),
     on.tx.full.supp=numeric(0), on.tx.full.supp.B=numeric(0), on.tx.full.supp.W=numeric(0),
     on.tx.part.supp=numeric(0), on.tx.part.supp.B=numeric(0), on.tx.part.supp.W=numeric(0),
     on.tx.influx.full=numeric(0), on.tx.influx.full.B=numeric(0), on.tx.influx.full.W=numeric(0),
     on.tx.influx.part=numeric(0), on.tx.influx.part.B=numeric(0), on.tx.influx.part.W=numeric(0),
     off.tx=numeric(0), off.tx.B=numeric(0), off.tx.W=numeric(0),
     acute=numeric(0), acute.B=numeric(0), acute.W=numeric(0),
     chronic=numeric(0), chronic.B=numeric(0), chronic.W=numeric(0),
     aids=numeric(0), aids.B=numeric(0), aids.W=numeric(0)
)

  summ[1,1:22] <- c(curr.time, sum(mard$atts.curr$active==1),
      sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'),
      sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W'),
      sum(inc), inc[1:2],
      sum(mard$atts.curr$active==1 & mard$atts.curr$inf.status==1),
      sum(mard$atts.curr$active==1 & mard$atts.curr$inf.status==1 & mard$atts.curr$race=='B'),
      sum(mard$atts.curr$active==1 & mard$atts.curr$inf.status==1 & mard$atts.curr$race=='W'),
      sum(births), births[1:2],
      sum(deaths.gen[1:2]), deaths.gen[1:2],
      sum(deaths.gen[3:4]), deaths.gen[3:4],
      sum(deaths.aids), deaths.aids[1:2])

  if(use.nD==T) {
    summ[1,23:25] <- c(summary(mard$nD.main~edges, at=curr.time),
      summary(mard$nD.pers~edges, at=curr.time), summary(mard$nD.inst~edges, at=curr.time))
    summ[1,26:27] <-round(summary(mard$nD.main~nodefactor('race',base=0), at=curr.time)/
        c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'),
        sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W')),3)
    summ[1,28:29] <- round(summary(mard$nD.pers~nodefactor('race',base=0), at=curr.time)/
        c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'),
        sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W')),3)
    summ[1,30:31] <- round(summary(mard$nD.inst~nodefactor('race',base=0), at=curr.time)/
        c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'),
        sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W')),3)
  } else {
    
    summ[1,23:25] <- c(network.edgecount(mard$nD.main),
                       network.edgecount(mard$nD.pers), network.edgecount(mard$nD.inst))
    summ[1,26:27] <- round(summary(mard$nD.main~nodefactor('race',base=0))/
                             c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'),
                               sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W')),3)
    summ[1,28:29] <- round(summary(mard$nD.pers~nodefactor('race',base=0))/
                             c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'),
                               sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W')),3)
    summ[1,30:31] <- round(summary(mard$nD.inst~nodefactor('race',base=0))/
                             c(sum(mard$atts.curr$active==1 & mard$atts.curr$race=='B'),
                               sum(mard$atts.curr$active==1 & mard$atts.curr$race=='W')),3)
  }
  
  summ[32] <- sum(mard$atts.curr$active==1 & mard$atts.curr$diag.status%in%0)
  summ[33] <- sum(mard$atts.curr$active==1 & mard$atts.curr$diag.status%in%0 & mard$atts.curr$race=="B")
  summ[34] <- sum(mard$atts.curr$active==1 & mard$atts.curr$diag.status%in%0 & mard$atts.curr$race=="W")
  
  summ[35] <- sum(mard$atts.curr$active==1 & mard$atts.curr$diag.status%in%1)
  summ[36] <- sum(mard$atts.curr$active==1 & mard$atts.curr$diag.status%in%1 & mard$atts.curr$race=="B")
  summ[37] <- sum(mard$atts.curr$active==1 & mard$atts.curr$diag.status%in%1 & mard$atts.curr$race=="W")
  
  summ[38] <- sum(mard$atts.curr$active==1 & mard$atts.curr$cum.time.on.tx%in%0)
  summ[39] <- sum(mard$atts.curr$active==1 & mard$atts.curr$cum.time.on.tx%in%0 & mard$atts.curr$race=="B")
  summ[40] <- sum(mard$atts.curr$active==1 & mard$atts.curr$cum.time.on.tx%in%0 & mard$atts.curr$race=="W")
  
  summ[41] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                    mard$atts.curr$vl%in%vl.full.supp)
  summ[42] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                    mard$atts.curr$vl%in%vl.full.supp & mard$atts.curr$race=="B")
  summ[43] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                    mard$atts.curr$vl%in%vl.full.supp & mard$atts.curr$race=="W")
  
  summ[44] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                    mard$atts.curr$vl%in%vl.part.supp)
  summ[45] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                    mard$atts.curr$vl%in%vl.part.supp & mard$atts.curr$race=="B")
  summ[46] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                    mard$atts.curr$vl%in%vl.part.supp & mard$atts.curr$race=="W")
  
  summ[47] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                    !mard$atts.curr$vl%in%c(vl.full.supp,vl.part.supp) & 
                    mard$atts.curr$tt.traj=="YF")
  summ[48] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                    !mard$atts.curr$vl%in%c(vl.full.supp,vl.part.supp) & 
                    mard$atts.curr$tt.traj=="YF" & 
                    mard$atts.curr$race=="B")
  summ[49] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                    !mard$atts.curr$vl%in%c(vl.full.supp,vl.part.supp) & 
                    mard$atts.curr$tt.traj=="YF" & 
                    mard$atts.curr$race=="W")

summ[50] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                  !mard$atts.curr$vl%in%c(vl.full.supp,vl.part.supp) & 
                  mard$atts.curr$tt.traj=="YP")
summ[51] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                  !mard$atts.curr$vl%in%c(vl.full.supp,vl.part.supp) & 
                  mard$atts.curr$tt.traj=="YP" & 
                  mard$atts.curr$race=="B")
summ[52] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%1 &
                  !mard$atts.curr$vl%in%c(vl.full.supp,vl.part.supp) & 
                  mard$atts.curr$tt.traj=="YP" & 
                  mard$atts.curr$race=="W")



  summ[53] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%0 &
                    (mard$atts.curr$cum.time.on.tx>0)%in%T)
  summ[54] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%0 &
                    (mard$atts.curr$cum.time.on.tx>0)%in%T & 
                    mard$atts.curr$race=="B")
  summ[55] <- sum(mard$atts.curr$active==1 & mard$atts.curr$tx.status%in%0 &
                    (mard$atts.curr$cum.time.on.tx>0)%in%T &
                    mard$atts.curr$race=="W")
  
  summ[56] <- sum(mard$atts.curr$active==1 & mard$atts.curr$stage%in%c("AR","AF"))
  summ[57] <- sum(mard$atts.curr$active==1 & mard$atts.curr$stage%in%c("AR","AF") & 
                    mard$atts.curr$race=="B")
  summ[58] <- sum(mard$atts.curr$active==1 & mard$atts.curr$stage%in%c("AR","AF") & 
                    mard$atts.curr$race=="W")
  
  summ[59] <- sum(mard$atts.curr$active==1 & mard$atts.curr$stage%in%"C")
  summ[60] <- sum(mard$atts.curr$active==1 & mard$atts.curr$stage%in%"C" & 
                    mard$atts.curr$race=="B")
  summ[61] <- sum(mard$atts.curr$active==1 & mard$atts.curr$stage%in%"C" & 
                    mard$atts.curr$race=="W")
  
  summ[62] <- sum(mard$atts.curr$active==1 & mard$atts.curr$stage%in%"D")
  summ[63] <- sum(mard$atts.curr$active==1 & mard$atts.curr$stage%in%"D" & 
                    mard$atts.curr$race=="B")
  summ[64] <- sum(mard$atts.curr$active==1 & mard$atts.curr$stage%in%"D" & 
                    mard$atts.curr$race=="W")
  
  if ("summ" %in% names(mard)) {
    mard$summ <- rbind(mard$summ, summ)
    rownames(mard$summ) <- NULL
  } else {mard$summ <- summ}

  return(mard)
}