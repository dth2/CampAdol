mardham.ai.condom.use <- function(mard, type, 
   base.prob.uaigai.BB, base.prob.uaigai.BW, base.prob.uaigai.WW, 
   beta.uaigai.full.supp,  beta.uaigai.part.supp, 
   beta.uaigai.diag, beta.uaigai.discl,
   curr.time
) {

  if( !(type%in%c('main','pers','inst'))) stop("argument \"type\" must equal \"main\", \"pers\", or \"inst\".")

  disc.ai.el <- mard$disc.ai[[curr.time]]
  if(type=='main') disc.ai.el <- disc.ai.el[disc.ai.el$type=='M',]
  if(type=='pers') disc.ai.el <- disc.ai.el[disc.ai.el$type=='P',]
  if(type=='inst') disc.ai.el <- disc.ai.el[disc.ai.el$type=='I',]
  
  #disc.ai.el <- mardham.disc.check(elist, mard$atts.curr)  # Pos on the left, neg on the right
  
  if(nrow(disc.ai.el) > 0) {
    prob.uaigai <- rep(NA, dim(disc.ai.el)[1])
    
    race.1 <- mard$atts.curr$race[disc.ai.el[,1]]
    race.2 <- mard$atts.curr$race[disc.ai.el[,2]]  
    num.B <- (race.1=='B') + (race.2=='B')
    
    prob.uaigai <-  (num.B==2) * base.prob.uaigai.BB + 
                (num.B==1) * base.prob.uaigai.BW + 
                (num.B==0) * base.prob.uaigai.WW
  
    logodds.uaigai <- log(prob.uaigai/(1-prob.uaigai))
    
    pos.diag <- mard$atts.curr$diag.status[disc.ai.el[,1]]
    discl <- sapply(1:nrow(disc.ai.el), function(x)
      sum(mard$discl.list$pos == mard$atts.curr$uid[disc.ai.el[x,1]] & 
            mard$discl.list$neg == mard$atts.curr$uid[disc.ai.el[x,2]])>0
      )
  
    pos.tx 	 <- mard$atts.curr$tx.status[disc.ai.el[,1]]
    pos.tt.traj <- mard$atts.curr$tt.traj[disc.ai.el[,1]]
    
    logodds.uaigai[pos.diag == 1] <- logodds.uaigai[pos.diag == 1] * (1-beta.uaigai.diag)
    logodds.uaigai[discl == 1] <- logodds.uaigai[discl == 1] * (1-beta.uaigai.discl)
    logodds.uaigai[pos.tx == 1 & pos.tt.traj == 'YF'] <- 
          logodds.uaigai[pos.tx == 1 & pos.tt.traj == 'YF'] * (1+beta.uaigai.full.supp)
    logodds.uaigai[pos.tx == 1 & pos.tt.traj == 'YP'] <- 
          logodds.uaigai[pos.tx == 1 & pos.tt.traj == 'YP'] * (1+beta.uaigai.part.supp)
  
    old.prob.uaigai <- prob.uaigai
    prob.uaigai <- exp(logodds.uaigai) / (1+exp(logodds.uaigai)) 

    prob.uaigai[is.na(prob.uaigai) & old.prob.uaigai==0] <- 0
    prob.uaigai[is.na(prob.uaigai) & old.prob.uaigai==1] <- 1    
    
    uai <- rbinom(length(prob.uaigai), 1, prob.uaigai)
    
    if(type=='main') mard$disc.ai[[curr.time]]$uai[mard$disc.ai[[curr.time]]$type=='M'] <- uai
    if(type=='pers') mard$disc.ai[[curr.time]]$uai[mard$disc.ai[[curr.time]]$type=='P'] <- uai
    if(type=='inst') mard$disc.ai[[curr.time]]$uai[mard$disc.ai[[curr.time]]$type=='I'] <- uai
    
    #write.table(t(c(
    #  nrow(disc.ai.el), mean(prob.uaigai), sum(uai), sum(mard$disc.ai[[curr.time]]$uai,na.rm=T)
    #)),quote=F,row.names=F, file='a.csv', col.names=F, sep=', ', append=T)
  }  
  return(mard)
 
}
