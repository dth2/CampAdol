mardham.death.gen <- function(mard,asmr.B,asmr.W,time.step, use.nD) {
  
  age <- floor(mard$atts.curr$age)
  race <- mard$atts.curr$race
  active <- mard$atts.curr$active

  alive.B <- which(active==1 & race == 'B')
  age.B <- age[alive.B]
  death.probs.B <- asmr.B[age.B]
  deaths.B <- alive.B[rbinom(length(death.probs.B), 1, death.probs.B)==1]
  
  alive.W <- which(active==1 & race == 'W')
  age.W <- age[alive.W]
  death.probs.W <- asmr.W[age.W]
  deaths.W <- alive.W[rbinom(length(death.probs.W), 1, death.probs.W)==1]

  deaths <- c(deaths.B,deaths.W)

  if(length(deaths)>0) {
    mard$atts.curr$active[deaths] <- 0
    mard$atts.curr$depart.time[deaths] <- time.step
    
    if(use.nD==T) {
      mard$nD.main <- deactivate.vertices(mard$nD.main,onset=time.step,terminus=Inf, v=deaths, deactivate.edges=T)
      mard$nD.pers <- deactivate.vertices(mard$nD.pers,onset=time.step,terminus=Inf, v=deaths, deactivate.edges=T)
      mard$nD.inst <- deactivate.vertices(mard$nD.inst,onset=time.step,terminus=Inf, v=deaths, deactivate.edges=T)
    }
    if(use.nD==F) {
      #mard$nD.main <- delete.vertices(mard$nD.main, v=deaths)
      #mard$nD.pers <- delete.vertices(mard$nD.pers, v=deaths)
      #mard$nD.inst <- delete.vertices(mard$nD.inst, v=deaths)
      # The method below is faster as of now (09/2014)
      mard$nD.main <- network.collapse(deactivate.vertices(mard$nD.main, v=deaths, onset=time.step, terminus=Inf), at=time.step)
      mard$nD.pers <- network.collapse(deactivate.vertices(mard$nD.pers, v=deaths, onset=time.step, terminus=Inf), at=time.step)
      mard$nD.inst <- network.collapse(deactivate.vertices(mard$nD.inst, v=deaths, onset=time.step, terminus=Inf), at=time.step)
      mard$atts.curr <- mard$atts.curr[-deaths,]
    }
  }
  
  return(mard)
}
