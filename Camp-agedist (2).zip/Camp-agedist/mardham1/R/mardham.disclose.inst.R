mardham.disclose.inst <- function(mard, type, disc.B, disc.W, curr.time, use.nD) {

    net <- mard$nD.inst
    if (use.nD==T) {
      el <- get.dyads.active(net, at=curr.time) 
    } else {
      el <- matrix(as.edgelist(net), ncol=2)
    }    
    discl.type <- 'I'
  
  # Check for discordant rels
    posneg <- el[which(mard$atts.curr$inf.status[el[,1]] - mard$atts.curr$inf.status[el[,2]] == 1),,drop=F]
    negpos <- el[which(mard$atts.curr$inf.status[el[,2]] - mard$atts.curr$inf.status[el[,1]] == 1),,drop=F]  
    disc.el <- rbind(posneg, negpos[,2:1])
    disc.el <- as.data.frame(disc.el)
    names(disc.el) <- c('pos','neg')
  
  # Check for not already disclosed
    disc.notdiscl <- disc.el[sapply(1:nrow(disc.el), function(x) 
          length(intersect(which(mard$atts.curr$uid[disc.el[x,1]]==mard$discl.list$pos), 
                           which(mard$atts.curr$uid[disc.el[x,2]]==mard$discl.list$neg)))==0),,drop=F]
  
  # Check for positive diagnosis
    disc.notdiscl.diag <- disc.notdiscl[mard$atts.curr$diag.status[disc.notdiscl[,1]]==1,,drop=F]

  # If there are any elgible pairs
    if (nrow(disc.notdiscl.diag)>0) {
    
    # Split by race of pos guy
      disc.notdiscl.diag$pos.race <- mard$atts.curr$race[disc.notdiscl.diag[,1]]
  
    # Assign disclosure probs  
      discl.prob <- vector("numeric", length=nrow(disc.notdiscl.diag))
      discl.prob[disc.notdiscl.diag$pos.race=='B'] <- disc.B
      discl.prob[disc.notdiscl.diag$pos.race=='W'] <- disc.W
    
    # Determine disclosers
      discl <- which(rbinom(length(discl.prob),1,discl.prob)==1)
      if (length(discl)>0) {
        discl.df <- data.frame(pos=mard$atts.curr$uid[disc.notdiscl.diag[discl,1]],
                               neg=mard$atts.curr$uid[disc.notdiscl.diag[discl,2]],
                               discl.time=curr.time, discl.type=discl.type)
        mard$discl.list <- rbind(mard$discl.list, discl.df)
      }
    }
  
  return(mard)
}
