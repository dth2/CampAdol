mardham.position <- function(mard, curr.time, vv.prob.iev.BB, vv.prob.iev.BW, 
                             vv.prob.iev.WW) {
  
  # TODO Replace for real!!
    #mard$disc.ai[[curr.time]]$ins <- 
    #  as.character(sample(c('P','N','B'), length(mard$disc.ai[[curr.time]]$ins), replace=T))
  
    pos.role.class <- mard$atts.curr$role.class[mard$disc.ai[[curr.time]]$pos]
    neg.role.class <- mard$atts.curr$role.class[mard$disc.ai[[curr.time]]$neg]

    mard$disc.ai[[curr.time]]$ins <- NA
    mard$disc.ai[[curr.time]]$ins[pos.role.class=='I'] <- 'P'
    mard$disc.ai[[curr.time]]$ins[pos.role.class=='R'] <- 'N'
    mard$disc.ai[[curr.time]]$ins[neg.role.class=='I'] <- 'N'
    mard$disc.ai[[curr.time]]$ins[neg.role.class=='R'] <- 'P'
    
    vv <- which(pos.role.class=='V' & neg.role.class=='V')
    vv.race.combo <- paste(
                        mard$atts.curr$race[mard$disc.ai[[curr.time]]$pos[vv]], 
                        mard$atts.curr$race[mard$disc.ai[[curr.time]]$neg[vv]], sep='')
    vv.race.combo[vv.race.combo =='WB'] <- 'BW'
    vv.prob.iev <- (vv.race.combo=='BB') * vv.prob.iev.BB +
                   (vv.race.combo=='BW') * vv.prob.iev.BW +
                   (vv.race.combo=='WW') * vv.prob.iev.WW
    
    iev <- rbinom(length(vv), 1, vv.prob.iev)
    mard$disc.ai[[curr.time]]$ins[vv[iev==1]] <- 'B'
    vv.remaining <- vv[iev==0]

    prob.inspos <- mard$atts.curr$ins.quot[mard$disc.ai[[curr.time]]$pos[vv.remaining]] / 
                    (mard$atts.curr$ins.quot[mard$disc.ai[[curr.time]]$pos[vv.remaining]] + 
                    mard$atts.curr$ins.quot[mard$disc.ai[[curr.time]]$neg[vv.remaining]]) 
    inspos <- rbinom(length(vv.remaining), 1, prob.inspos)
    mard$disc.ai[[curr.time]]$ins[vv.remaining[inspos==1]] <- 'P'
    mard$disc.ai[[curr.time]]$ins[vv.remaining[inspos==0]] <- 'N'
    
  return(mard)
}