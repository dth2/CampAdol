#############################################################################################################
### Calculate the number of relations of each type at each time point.
### Not optimised for speed.

mardham.calc.rels <- function(mardham.obj) {
  times <- mardham.obj$curr.time
  main <- sapply(1:times, function(x) network.edgecount(network.collapse(mardham.obj$nD.main,at=x)))
  cat("Done main.\n")
  pers <- sapply(1:times, function(x) network.edgecount(network.collapse(mardham.obj$nD.pers,at=x)))
  cat("Done pers.\n")
  inst <- sapply(1:times, function(x) network.edgecount(network.collapse(mardham.obj$nD.inst,at=x)))
  cat("Done inst.\n")
  result <- cbind(main,pers,inst)
  return(result)
}

#############################################################################################################
### Calculate degree distributions
### Not optimised for speed
### Perhaps not the most useful structure

mardham.calc.deg.dists <- function(mard, verbose=T) {
  degs.main <- list()
  degs.pers <- list()
  degs.inst <- list()
  for(i in 1:mard$curr.time) {
    degs.main[[i]] <- table(summary(network.collapse(mard$nD.main, at=i)~sociality(base=0)))
    degs.pers[[i]] <- table(summary(network.collapse(mard$nD.pers, at=i)~sociality(base=0)))
    degs.inst[[i]] <- table(summary(network.collapse(mard$nD.inst, at=i)~sociality(base=0)))
    if(verbose==T) cat('Done timestep ',i,' of ', mard$curr.time,'\n', sep='')
  }
  result <- list(degs.main=degs.main, degs.pers=degs.pers, degs.inst=degs.inst)
  return(result)
}
