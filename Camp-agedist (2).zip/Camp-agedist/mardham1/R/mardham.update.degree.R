mardham.update.degree <- function(network, net.source, deg.type, curr.time, use.nD) {

  if(!("network"%in%class(network))) stop("Argument network must be of class network")
  if(!("network"%in%class(net.source))) stop("Argument net.source must be of class network")
  
  if(deg.type=='main') attr.name <- 'deg.main'
  if(deg.type=='pers') attr.name <- 'deg.pers'
  
  race <- get.vertex.attribute(network, 'race')
  if (use.nD==T) net.source <- network.collapse(net.source, at=curr.time, retain.all.vertices=T)
  deg.dist <- summary(net.source~sociality(base=0))  
  race.deg.dist <- paste(race, deg.dist, sep='')

  #vB <- which(race=='B')
  #vW <- which(race=='W')
  #nB <- length(vB)
  #nW <- length(vW)
  #num.degrees.B <- length(dist.B)
  #num.degrees.W <- length(dist.W)
  #deg.B <- apportion.lr(nB, 0:(num.degrees.B-1), dist.B, shuffled=T)
  #deg.W <- apportion.lr(nW, 0:(num.degrees.W-1), dist.W, shuffled=T)
  #deg.B <- paste('B',deg.B,sep='')
  #deg.W <- paste('W',deg.W,sep='')
  
  result <- network.copy(network)
  result <- set.vertex.attribute(result, attr.name, race.deg.dist)
  return(result)
}
