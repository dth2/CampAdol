mardham.disc.ai <- function(mard, type, fixed=F,
   base.exp.ai.BB, base.exp.ai.BW, base.exp.ai.WW, 
   incr.exp.ai.full.supp,  incr.exp.ai.part.supp, redux.exp.ai.diag, redux.exp.ai.discl,
   curr.time, use.nD
) {
  if( !(type%in%c('main','pers','inst'))) stop("argument \"type\" must equal \"main\", \"pers\", or \"inst\".")

  if(use.nD==T) {
    if(type=='main') elist <- get.dyads.active(mard$nD.main, at=curr.time)
    if(type=='pers') elist <- get.dyads.active(mard$nD.pers, at=curr.time)
    if(type=='inst') elist <- get.dyads.active(mard$nD.inst, at=curr.time)
  } else {
    if(type=='main') elist <- matrix(as.edgelist(mard$nD.main), ncol=2)
    if(type=='pers') elist <- matrix(as.edgelist(mard$nD.pers), ncol=2)
    if(type=='inst') elist <- matrix(as.edgelist(mard$nD.inst), ncol=2)
  }
      
  disc.el <- mardham.disc.check(elist, mard$atts.curr)  # Pos on the left, neg on the right
   
  if (nrow(disc.el)>0) {
  
    exp.ai <- rep(NA, dim(disc.el)[1])
    
    race.1 <- mard$atts.curr$race[disc.el[,1]]
    race.2 <- mard$atts.curr$race[disc.el[,2]]  
    num.B <- (race.1=='B') + (race.2=='B')
    
    exp.ai <-  (num.B==2) * base.exp.ai.BB + 
                (num.B==1) * base.exp.ai.BW + 
                (num.B==0) * base.exp.ai.WW
  
    pos.diag <- mard$atts.curr$diag.status[disc.el[,1]]
    pos.tx 	 <- mard$atts.curr$tx.status[disc.el[,1]]
    pos.tt.traj <- mard$atts.curr$tt.traj[disc.el[,1]]
    
    disclosed <- sapply(1:nrow(disc.el), function(x) 
                      length(intersect(which(disc.el[x,1]==mard$discl.list$pos), 
                       which(disc.el[x,2]==mard$discl.list$neg))) != 0)
    
    exp.ai[pos.diag == 1] <- exp.ai[pos.diag == 1] * (1-redux.exp.ai.diag)
    exp.ai[disclosed==T] <- exp.ai[disclosed==T] * (1-redux.exp.ai.discl)
    exp.ai[pos.tx == 1 & pos.tt.traj == 'YF'] <- exp.ai[pos.tx == 1 & pos.tt.traj == 'YF'] * (1+incr.exp.ai.full.supp)
    exp.ai[pos.tx == 1 & pos.tt.traj == 'YP'] <- exp.ai[pos.tx == 1 & pos.tt.traj == 'YP'] * (1+incr.exp.ai.part.supp)
    
    if (fixed==F) ai <- rpois(length(exp.ai), exp.ai)
    if (fixed==T) ai <- round(exp.ai)
    
    #if(type=='main') result <- cbind(result,"M")
    #if(type=='pers') result <- cbind(result,"P")
    #if(type=='inst') result <- cbind(result,"I")
  
    #result <- data.frame(pos=disc.el[ai==1,1,drop=F], neg=disc.el[ai==1,2,drop=F], 
    #   type=toupper(substr(type,1,1)), uai=NA, ins=NA, stringsAsFactors=F) 
    
    if (sum(ai)>0) {
      result <- data.frame(pos=rep(disc.el[,1],ai), neg=rep(disc.el[,2],ai),
        type=toupper(substr(type,1,1)), uai=NA, ins=NA, stringsAsFactors=F) 
    } else {
      result <- data.frame(pos=NULL, neg=NULL,
        type=NULL, uai=NULL, ins=NULL, stringsAsFactors=F)
    }  

    # TODO THINK ABOUT NEEDS
    if (length(mard$disc.ai)<curr.time) {
      mard$disc.ai[[curr.time]] <- result 
    } else {
      mard$disc.ai[[curr.time]] <- rbind(mard$disc.ai[[curr.time]],result)
    }
  
    #write.table(t(c(
    #  nrow(elist), nrow(disc.el), mean(exp.ai), sum(ai) #, table(mard$disc.ai[[curr.time]]$type)
    #  )),quote=F,row.names=F, file='a.csv', col.names=F, sep=', ', append=T)

  }
  
  return(mard)
}
