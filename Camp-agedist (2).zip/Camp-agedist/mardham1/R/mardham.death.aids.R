mardham.death.aids <- function(mard, vl.fatal, time.step, use.nD) {
  
  deaths <- which(mard$atts.curr$active==1 & 
              mard$atts.curr$stage == "D" & 
              mard$atts.curr$vl >= vl.fatal)
  
  if(length(deaths)>0) {
    mard$atts.curr$active[deaths] <- 0
    mard$atts.curr$depart.time[deaths] <- time.step
    
    if(use.nD==T) {
      mard$nD.main <- deactivate.vertices(mard$nD.main,onset=time.step,terminus=Inf, v=deaths, deactivate.edges=T)
      mard$nD.pers <- deactivate.vertices(mard$nD.pers,onset=time.step,terminus=Inf, v=deaths, deactivate.edges=T)
      mard$nD.inst <- deactivate.vertices(mard$nD.inst,onset=time.step,terminus=Inf, v=deaths, deactivate.edges=T)
    }
    if(use.nD==F) {
      #mard$nD.main <- delete.vertices(mard$nD.main, v=deaths)
      #mard$nD.pers <- delete.vertices(mard$nD.pers, v=deaths)
      #mard$nD.inst <- delete.vertices(mard$nD.inst, v=deaths)
      # The method below is faster as of now (09/2014)
      mard$nD.main <- network.collapse(deactivate.vertices(mard$nD.main, v=deaths, onset=time.step, terminus=Inf), at=time.step)
      mard$nD.pers <- network.collapse(deactivate.vertices(mard$nD.pers, v=deaths, onset=time.step, terminus=Inf), at=time.step)
      mard$nD.inst <- network.collapse(deactivate.vertices(mard$nD.inst, v=deaths, onset=time.step, terminus=Inf), at=time.step)
      mard$atts.curr <- mard$atts.curr[-deaths,]
    }  
  }
  
  return(mard)
}
