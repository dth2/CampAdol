mardham.tx <- function(mard, prob.tx.init.B, prob.tx.init.W, curr.time, 
                       prob.tx.halt.B, prob.tx.halt.W,
                       prob.tx.reinit.B, prob.tx.reinit.W,
                       ...) {

  active <- mard$atts.curr$active==1
  
  # treatment initiation
  #dur.infected <- curr.time - mard$atts.curr$inf.time

  tx.init.elig.B <- which(mard$atts.curr$active==1 &
        mard$atts.curr$race=='B' & mard$atts.curr$inf.status==1 & 
        mard$atts.curr$tx.status==0 & 
        mard$atts.curr$diag.status==1 & mard$atts.curr$tt.traj%in%c('YP','YF') & 
        mard$atts.curr$cum.time.on.tx==0 &
        mard$atts.curr$stage !="D"
  )
  
  tx.init.B <- tx.init.elig.B[rbinom(
          length(tx.init.elig.B), 1, prob.tx.init.B)==1]
  
  tx.init.elig.W <- which(mard$atts.curr$active==1 &
        mard$atts.curr$race=='W' & mard$atts.curr$inf.status==1 & 
        mard$atts.curr$tx.status==0 &
        mard$atts.curr$diag.status==1 & mard$atts.curr$tt.traj%in%c('YP','YF') & 
        mard$atts.curr$cum.time.on.tx==0 &
        mard$atts.curr$stage !="D"
  )

  tx.init.W <- tx.init.elig.W[rbinom(
        length(tx.init.elig.W), 1, prob.tx.init.W)==1]

  tx.init <- c(tx.init.B,tx.init.W)
  
  mard$atts.curr$tx.status[tx.init] <- 1
  mard$atts.curr$tx.init.time[tx.init] <- curr.time
  
  # treatment halting
  tx.halt.elig.B <- which(mard$atts.curr$active==1 & mard$atts.curr$race=='B' & mard$atts.curr$tx.status==1) 
  tx.halt.B <- tx.halt.elig.B[rbinom(length(tx.halt.elig.B),1,prob.tx.halt.B)==1]
  tx.halt.elig.W <- which(mard$atts.curr$active==1 & mard$atts.curr$race=='W' & mard$atts.curr$tx.status==1) 
  tx.halt.W <- tx.halt.elig.W[rbinom(length(tx.halt.elig.W),1,prob.tx.halt.W)==1]
  tx.halt <- c(tx.halt.B,tx.halt.W)
  mard$atts.curr$tx.status[tx.halt] <- 0
  
  # treatment re-initiation
  tx.reinit.elig.B <- which(mard$atts.curr$active==1 & mard$atts.curr$race=='B' & 
            mard$atts.curr$tx.status==0 & mard$atts.curr$cum.time.on.tx>0 & 
            mard$atts.curr$stage!='D') 
  tx.reinit.B <- tx.reinit.elig.B[rbinom(length(tx.reinit.elig.B),1,prob.tx.reinit.B)==1]
  tx.reinit.elig.W <- which(mard$atts.curr$active==1 & mard$atts.curr$race=='W' &
            mard$atts.curr$tx.status==0 & mard$atts.curr$cum.time.on.tx>0 &
            mard$atts.curr$stage!='D') 
  tx.reinit.W <- tx.reinit.elig.W[rbinom(length(tx.reinit.elig.W),1,prob.tx.reinit.W)==1]
  tx.reinit <- c(tx.reinit.B,tx.reinit.W)
  mard$atts.curr$tx.status[tx.reinit] <- 1

  # update cum.time.on.tx and cum.time.off.tx
  mard$atts.curr$cum.time.on.tx[active] <- mard$atts.curr$cum.time.on.tx[active] + ((mard$atts.curr$tx.status[active]==1) %in% T)
  mard$atts.curr$cum.time.off.tx[active] <- mard$atts.curr$cum.time.off.tx[active] + ((mard$atts.curr$tx.status[active]==0) %in% T)
  
  return(mard)
}
