
#######################################################################
### apportion.lr: apportion a vector with the least-remainder method

apportion.lr <- function(vector.length,values,proportions,shuffled=F) {
  # lr = "largest remainder" method
  # COMMENT
  if (vector.length != round(vector.length)) stop ("argument vector.length must be a positive integer")
  if (vector.length <= 0) stop ("argument vector.length must be a positive integer")
  if (is.vector(values) == FALSE) stop ("argument values must be a vector")
  if (!(length(proportions)==length(values) && round(sum(proportions),10)==1)  &&
        (!(length(proportions)==length(values)-1 && round(sum(proportions),10)<=1 && round(sum(proportions),10)>=0)))
    stop ("error in proportions length or proportions sum")
  
  if (length(proportions)==length(values)-1) proportions <- c(proportions, 1-round(sum(proportions),10))
  result <- rep(NA,vector.length)
  exp.nums <- proportions * vector.length
  counts <- floor(exp.nums)
  remainders <- exp.nums - counts
  leftovers <- vector.length - sum(counts)
  if (leftovers > 0) {
    additions <- order(remainders,decreasing=T)[1:leftovers]
    counts[additions]   <- counts[additions]+1
  }
  result <- c(rep(values,counts))
  if (shuffled==T) result <- sample(result,length(result))
  return(result)
}


#######################################################################
### Get active vertex IDs

get.vertices.active <- function(net,time) {
  which(is.active(net,at=time,v=seq_len(network.size(net))))
}

#######################################################################
### Save all objects

save.all.obj <- function () 
{
  for (i in 2:length(ls(".GlobalEnv"))) {
    tempobj <- get(ls(".GlobalEnv")[i])
    filename <- paste(ls(".GlobalEnv")[i], ".RData", sep = "")
    save(tempobj, file = filename)
  }
}

#######################################################################
### Select (I still can't believe there isn't already a way to do this)

select <- function(vector,probs) {
  selected <- rbinom(length(vector),1,probs)==1
  return(vector[selected])
}

#######################################################################
### get nD size through time -- not optimised for efficiency

get.network.size.networkDynamic <- function(nD) {
  endtime <- max(((nD) %n% 'net.obs.period')$observations[[1]])
  result <- sapply(1:endtime, function(x) network.size(network.collapse(nD,at=x)))
  return(result)
}



#######################################################################
### Assorted shortcuts

rm.all <- function() {rm(list=ls())}

ncat <- function(nD,at) {network.collapse(nD,at=at)}

ncat.rav <- function(nD,at) {network.collapse(nD,at=at,retain.all.vertices=T)}

logit <- function(p)log(p/(1-p))

expit <- function(p) exp(p)/(1+exp(p))

#######################################################################
### Extend.vertices (on hold)

if(F) {
  extend.vertices <- function(net, from, to, extenders) {
    net <- activate.vertices(net,onset=from,terminus=to, v=extenders)
    TEAs <- grep(".active", list.vertex.attributes(net), value = TRUE)
    prefixes <- sub(".active","",TEAs)
    #  sapply(1:seq_along(prefixes), function(x) activate.vertex.attribute(
    #              net,get.vertex.attribute(net,prefixes[x],at=from-1,v=extenders)
    #              prefixes[x], onset=from,terminus=to, v=extenders))
  } 
}

#######################################################################

ls.deb  <- function(items = search ()){
  .ls.deb <-  function (i){
    f <- ls (i)
    f <- mget (f, as.environment (i), mode = "function",
               
               ## return a function that is not debugged
               ifnotfound = list (function (x) function () NULL)
    )
    
    if (length (f) == 0)
      return (NULL)
    
    f <- f [sapply (f, isdebugged)]
    f <- names (f)
    
    ## now check whether the debugged function is masked by a not debugged one
    masked <- !sapply (f, function (f) isdebugged (get (f)))
    
    ## generate pretty output format:
    ## "package::function"  and "(package::function)" for masked debugged functions
    if (length (f) > 0) {
      if (grepl ('^package:', i)) {
        i <- gsub ('^package:', '', i)
        f <- paste (i, f, sep = "::")
      }
      
      f [masked] <- paste ("(", f [masked], ")", sep = "")
      
      f
    } else {
      NULL
    }
  }
   
  functions <- lapply (items, .ls.deb)
  unlist (functions)
}

###################################################################################33
# Check which rows of matrix A match a row in matrix B

matrices.rowmatch <- function(m1, m2) {
  return(which(sapply(1:nrow(m1), function(x) sum(apply(m2, 1, all.equal, m1[x,])==T))>0))
}
