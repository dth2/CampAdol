mardham.update.inst.ai.class <- function(mard, inst.trans.matrix, curr.time) {
  if (sum(colSums(inst.trans.matrix) != 1)>0) stop("Column sums in argument inst.trans.matrix must all equal 1.")
  old.inst.ai.class <- mard$atts.curr$inst.ai.class
  
  new.inst.ai.class <- sapply(1:length(old.inst.ai.class), 
    function(x) which(rmultinom(1,1,inst.trans.matrix[,old.inst.ai.class[x]])==1))
  
  mard$atts.curr$inst.ai.class <- new.inst.ai.class
  return(mard)
}
