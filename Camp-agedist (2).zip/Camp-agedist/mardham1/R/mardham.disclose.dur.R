mardham.disclose.dur <- function(mard, type, disc.outset.B, disc.outset.W, 
        disc.at.diag.B, disc.at.diag.W, disc.post.diag.B, disc.post.diag.W, 
        curr.time, use.nD) {

    if( !(type%in%c('main','pers'))) stop("argument \"type\" must equal \"main\" or \"pers\".")
    if(type=='main') net <- mard$nD.main
    if(type=='pers') net <- mard$nD.pers
    if(type=='main') discl.type <- 'M'
    if(type=='pers') discl.type <- 'P'
    
  # active.eids <-get.edge.id(net, get.edge.pid(network.collapse(net, at=curr.time)))
  
  # Check for discordant rels
    if (use.nD==T) {
      el <- get.dyads.active(net, at=curr.time) 
    } else {
      el <- matrix(as.edgelist(net), ncol=2)
    }
  
    posneg <- el[which(mard$atts.curr$inf.status[el[,1]] - mard$atts.curr$inf.status[el[,2]] == 1),,drop=F]
    negpos <- el[which(mard$atts.curr$inf.status[el[,2]] - mard$atts.curr$inf.status[el[,1]] == 1),,drop=F]  
    disc.el <- rbind(posneg, negpos[,2:1])
    disc.el <- as.data.frame(disc.el)
    names(disc.el) <- c('pos','neg')
  
  # Check for not already disclosed
    disc.notdiscl <- disc.el[sapply(1:nrow(disc.el), function(x) 
          length(intersect(which(mard$atts.curr$uid[disc.el[x,1]]==mard$discl.list$pos), 
                           which(mard$atts.curr$uid[disc.el[x,2]]==mard$discl.list$neg)))==0),,drop=F]
    
  # Check for positive diagnosis
    disc.notdiscl.diag <- disc.notdiscl[mard$atts.curr$diag.status[disc.notdiscl[,1]]==1,,drop=F]

  # If there are any eligible pairs
    if (nrow(disc.notdiscl.diag)>0) {
    
    # Split by race of pos guy
      disc.notdiscl.diag$pos.race <- mard$atts.curr$race[disc.notdiscl.diag[,1]]
  
    # Check if rel is new:
      #disc.notdiscl.diag$new.rel <- (1:nrow(disc.notdiscl.diag)) %in% 
      #      c(matrices.rowmatch(matrix(as.matrix(disc.notdiscl.diag[,1:2]),ncol=2), mard$new.edges),
      #        matrices.rowmatch(matrix(as.matrix(disc.notdiscl.diag[,2:1]),ncol=2), mard$new.edges))
    
      disc.notdiscl.diag$new.rel <- ((disc.notdiscl.diag[,1]*1e12 + disc.notdiscl.diag[,2]) %in% 
                      (mard$new.edges[,1]*1e12 + mard$new.edges[,2])) |
                  ((disc.notdiscl.diag[,2]*1e12 + disc.notdiscl.diag[,1]) %in% 
                      (mard$new.edges[,1]*1e12 + mard$new.edges[,2]))
    
    # Check if diag is new: use curr.time here because disloure is after testing with a timestep
      disc.notdiscl.diag$new.diag <- mard$atts.curr$diag.time[disc.notdiscl.diag[,1]] == curr.time
    
    # Assign disclosure probs  
      discl.prob <- vector("numeric", length=nrow(disc.notdiscl.diag))
      discl.prob[disc.notdiscl.diag$pos.race=='B' & disc.notdiscl.diag$new.rel==T] <- disc.outset.B
      discl.prob[disc.notdiscl.diag$pos.race=='B' & disc.notdiscl.diag$new.rel==F & 
                                                    disc.notdiscl.diag$new.diag==T] <- disc.at.diag.B
      discl.prob[disc.notdiscl.diag$pos.race=='B' & disc.notdiscl.diag$new.rel==F & 
                                                    disc.notdiscl.diag$new.diag==F] <- disc.post.diag.B
    
      discl.prob[disc.notdiscl.diag$pos.race=='W' & disc.notdiscl.diag$new.rel==T] <- disc.outset.W
      discl.prob[disc.notdiscl.diag$pos.race=='W' & disc.notdiscl.diag$new.rel==F & 
                                                    disc.notdiscl.diag$new.diag==T] <- disc.at.diag.W
      discl.prob[disc.notdiscl.diag$pos.race=='W' & disc.notdiscl.diag$new.rel==F & 
                                                    disc.notdiscl.diag$new.diag==F] <- disc.post.diag.W
    
    # Determine disclosers
      discl <- which(rbinom(length(discl.prob),1,discl.prob)==1)
      if (length(discl)>0) {
        discl.df <- data.frame(pos=mard$atts.curr$uid[disc.notdiscl.diag[discl,1]],
                               neg=mard$atts.curr$uid[disc.notdiscl.diag[discl,2]], 
                               discl.time=curr.time, discl.type=discl.type)
        mard$discl.list <- rbind(mard$discl.list, discl.df)
      }
    }
  
  return(mard)
}
