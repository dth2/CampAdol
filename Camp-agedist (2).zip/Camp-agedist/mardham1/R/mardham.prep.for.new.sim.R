mardham.prep.for.new.sim <- function(mard) {
  result <- mard
  # do the networks need to be made into nD objects?  
  result$disc.ai <- list()
  result$curr.time <- 0
  result$deg.dists <- list()
  result$deg.discl.list <- list()
  return(result)
}