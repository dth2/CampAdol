
###########################################################
### Basic prevalence and incidence calcs by race

mardham.calc.pi <- function(mard, i.window=1) {
  result <- data.frame(
    p = mard$summ$p / mard$summ$n,
    pB = mard$summ$p.B / mard$summ$n.B,
    pW = mard$summ$p.W / mard$summ$n.W, 
    i = mard$summ$i / (mard$summ$n - mard$summ$i),
    iB = mard$summ$i.B / (mard$summ$n.B - mard$summ$i.B),
    iW = mard$summ$i.W / (mard$summ$n.W - mard$summ$i.W)
  )
  result$ic <- filter(result$i, rep(1,i.window), method="convolution", sides=1)
  result$icB <- filter(result$iB, rep(1,i.window), method="convolution", sides=1)
  result$icW <- filter(result$iW, rep(1,i.window), method="convolution", sides=1)
  return(result)
}

###########################################################
### Plot mea deg by race

mardham.plot.md.by.race <- function(mard) {
  
  windows(12,4)
  par(mfrow=c(1,3))
  plot(mard$summ$md.MB, ylim=c(0,1))
  points(mard$summ$md.MW, col='red')
  #lines(c(0,10000), rep(mardham.meanstats.01$meanstats.m[[1]]*2/
  #                        network.size(mardham.basepop.01$nD.main),2))
  
  plot(mard$summ$md.PB, ylim=c(0,1))
  points(mard$summ$md.PW, col='red')
  #lines(c(0,10000), rep(mardham.meanstats.01$meanstats.p[[1]]*2/
  #                        network.size(mardham.basepop.01$nD.main),2))
  
  plot(mard$summ$md.IB, ylim=c(0,1))
  points(mard$summ$md.IW, col='red')
  #lines(c(0,10000), rep(sum(mardham.meanstats.01$meanstats.i[1:12])/
  #                        network.size(mardham.basepop.01$nD.main),2))
}

###########################################################
### Calculate the number of discordant ai acts by 
###   relationship type at each time point.

mardham.calc.disc.ai <- function(mard, onset=1, terminus=mard$curr.time) {
  result <- t(sapply(onset:terminus, function(x) c(
    sum(mard$disc.ai[[x]]$type=='M'),
    sum(mard$disc.ai[[x]]$type=='P'), 
    sum(mard$disc.ai[[x]]$type=='I'))))
  colnames(result) <- c('M','P','I')
  return(result)
}

#############################################################################################################
### Calculate the number of discordant uai acts by relationship type at each time point.

mardham.calc.disc.uai <- function(mard, onset=1, terminus=mard$curr.time) {
  result <- t(sapply(onset:terminus, function(x) c(
    sum(mard$disc.ai[[x]]$type=='M' & mard$disc.ai[[x]]$uai==1),
    sum(mard$disc.ai[[x]]$type=='P' & mard$disc.ai[[x]]$uai==1), 
    sum(mard$disc.ai[[x]]$type=='I' & mard$disc.ai[[x]]$uai==1))))
  colnames(result) <- c('M','P','I')
  return(result)
}

#######################################################################
### This function has been supplanted by the addition of $summ to a 
###   mardham class object
### This code is also outdated in that it does not account for the fact 
###   that nodes are now deleted when they become inactive
### But the function contains some good code potentially worth recycling at some point.
###
### Calculate prevalence overall and by race, along with 
### pop size overall and by race

#mardham.calc.prev <- function(mard, verbose=T) {
#  df <- mard$atts.curr
#  result <- data.frame(time=1:mard$curr.time, n=NA, nB=NA, nW=NA, 
#                       i=NA, iB = NA, iW=NA, p=NA, pB=NA, pW=NA,
#                       d=NA, dB=NA, dW=NA, t=NA, tB=NA, tW=NA,
#                       pd=NA, pdB=NA, pdW=NA, pt=NA, ptB=NA, ptW=NA)
#  for (i in 1:mard$curr.time) {
#    active <- (df$arrival.time<=i | is.na(df$arrival.time)) & (df$depart.time >i | is.na(df$depart.time))
#    infected <- df$inf.status==1 & df$inf.time<=i
#    diagnosed <- df$inf.status==1 & df$diag.status==1 & df$diag.time<=i
#    tx.exp <- df$inf.status==1 & !is.na(df$tx.init.time) & df$tx.init.time<=i
#    result$n[i] <-   sum(active==T)
#    result$nB[i] <-  sum(active==T & df$race=='B')
#    result$nW[i] <-  sum(active==T & df$race=='W')
#    result$i[i] <-   sum(active==T & infected==T)
#    result$iB[i] <-  sum(active==T & infected==T & df$race=='B')
#    result$iW[i] <-  sum(active==T & infected==T & df$race=='W')
#    result$d[i] <-   sum(active==T & diagnosed==T)
#    result$dB[i] <-  sum(active==T & diagnosed==T & df$race=='B')
#    result$dW[i] <-  sum(active==T & diagnosed==T & df$race=='W')
#    result$t[i] <-  sum(active==T & tx.exp==T)
#    result$tB[i] <- sum(active==T & tx.exp==T & df$race=='B')
#    result$tW[i] <- sum(active==T & tx.exp==T & df$race=='W')
#    if(verbose==T) cat('Finishing time step ',i,' of ',mard$curr.time,'.\n',sep='')
#  }
#  result$p <- result$i/result$n
#  result$pB <- result$iB/result$nB
#  result$pW <- result$iW/result$nW
#  result$pd <- result$d/result$i
#  result$pdB <- result$dB/result$iB
#  result$pdW <- result$dW/result$iW
#  result$pt <- result$t/result$i
#  result$ptB <- result$tB/result$iB
#  result$ptW <- result$tW/result$iW
#  return(result)
#}

