mardham.disc.check <- function(edgelist, mydata) {
  
  if (class(edgelist) != "matrix") stop ("argument edgelist must be a matrix")  
  if (ncol(edgelist) != 2) stop ("argument edgelist must have two columns")
  if (mode(edgelist) != "numeric" ) stop ("argument edgelist must be numeric")
  if (any(edgelist != round(edgelist)) == "TRUE") stop ("argument edgelist must be integer values")
  if ((0 %in% edgelist) == "TRUE" ) stop ("argument edgelist cannot contain 0")
  if (any(edgelist>nrow(mydata)) == "TRUE" ) stop ("argument edgelist cannot contain values greater than number of rows in dataframe")
  
  result <- list()
  result <- edgelist[mydata$inf.status[edgelist[,1]] - mydata$inf.status[edgelist[,2]] == 1,,drop=F]
  result <- rbind(result, edgelist[mydata$inf.status[edgelist[,2]] - mydata$inf.status[edgelist[,1]] == 1, 2:1,drop=F])
  return(result)
}

# discordantcheck <- function(edgelist, mydata) {
#  
#  if (class(edgelist) != "matrix") stop ("argument edgelist must be a matrix")  
#  if (ncol(edgelist) != 2) stop ("argument edgelist must have two columns")
#  if (mode(edgelist) != "numeric" ) stop ("argument edgelist must be numeric")
#  if (any(edgelist != round(edgelist)) == "TRUE") stop ("argument edgelist must be integer values")
#  if ((0 %in% edgelist) == "TRUE" ) stop ("argument edgelist cannot contain 0")
#  if (any(edgelist>nrow(mydata)) == "TRUE" ) stop ("argument edgelist cannot contain values greater than number of rows in dataframe")
#  
#  result <- list()
#  result$disc.ins.pos <- matrix(nrow = 0, ncol = 2)
#  result$disc.rec.pos <- matrix(nrow = 0, ncol = 2)
#  result$disc.ins.pos <- edgelist[mydata$inf.status[edgelist[,1]] - mydata$inf.status[edgelist[,2]] == 1,]
#  return(result) 
#}