mardham.append.inst.simulate <- function(mard, inst.model, curr.time, use.nD=use.nD) {
  
  if ("networkDynamic"%in%class(mard$nD.inst)) {
    empty.net <- network.collapse(mard$nD.inst, at=curr.time)
  } else {
    empty.net <- mard$nD.inst
  }
  inst.formula <- update.formula(inst.model$formula, empty.net~.) 
  environment(inst.formula) <- environment()
  tied.net <- simulate(inst.formula, coef=inst.model$coef,
      constraints=inst.model$constraints,
      control=control.simulate.formula(MCMC.burnin=1e5))
  if(use.nD==T) {
    el <- as.edgelist(tied.net)
    el.pids <- get.vertex.pid(tied.net, el)
    el.ids <- matrix(get.vertex.id(mard$nD.inst, el.pids), ncol=2)
    mard$nD.inst <- add.edges.active(mard$nD.inst, el.ids[,1], el.ids[,2], onset=curr.time, terminus=curr.time+1)
  } else {
    mard$nD.inst <- tied.net
  }
    return(mard)
}