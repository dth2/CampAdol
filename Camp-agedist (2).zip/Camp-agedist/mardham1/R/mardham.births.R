mardham.births <- function(mard, births.exp.B, births.exp.W, birth.age, curr.time,
                           num.inst.ai.classes, tt.traj.freq.B,
                           tt.traj.freq.W, circ.prev.B, circ.prev.W, 
                           role.class.freq.B, role.class.freq.W, 
                           ccr5.freq.B, ccr5.freq.W, use.nD, ...){

  births.B <- rpois(1,births.exp.B)
  births.W <- rpois(1,births.exp.W)
  births <- births.B+births.W
  
  if (births>0) {

    # TODO Being taken from nD.main; relies on the fact that all code ensures that all three nD objects stay
    # the same size as each other through time. If only there were a more straightforward (and less memory-hogging) way!
    birthIDs <- network.size(mard$nD.main) + (1:births)
    uid <- mard$max.uid + (1:births)
    mard$max.uid <- mard$max.uid + births
    
    race <- c(rep('B',births.B),rep('W',births.W))
    age <- rep(birth.age, births)
    sqrt.age <- sqrt(age)
    inf.status <- rep(0,births)
    active <- rep(1,births)
    arrival.time <- rep(curr.time, births)
    inst.ai.class <- sample(1:num.inst.ai.classes,births,replace=T)
    inf.time <- stage <- stage.time <- last.neg.test <- diag.status <- diag.time <- tx.status <- 
      tx.init.time <- cum.time.on.tx <- cum.time.off.tx <- vl <- infector <- inf.role <- inf.type <- 
      inf.diag <- inf.tx <- inf.stage <-  depart.time <- rep(NA,births)

    tt.traj <- c(sample(c('NN','YN','YP','YF'), births.B, replace=T, prob=tt.traj.freq.B),
                 sample(c('NN','YN','YP','YF'), births.W, replace=T, prob=tt.traj.freq.W))
    
    circ <- c(sample(0:1, births.B, replace=T, prob=c(1-circ.prev.B, circ.prev.B)),
              sample(0:1, births.W, replace=T, prob=c(1-circ.prev.W, circ.prev.W)))
    
    role.class <- c(sample(c('I','R','V'), births.B, replace=T, prob=role.class.freq.B),
                    sample(c('I','R','V'), births.W, replace=T, prob=role.class.freq.W))
    
    ins.quot <-rep(NA, length(role.class))
    ins.quot[role.class=='I']  <- 1
    ins.quot[role.class=='R']  <- 0
    ins.quot[role.class=='V']  <- runif(sum(role.class=='V'))
    
    new.order <- sample(1:births,births)      # Reorder births to avoid artifacts of having them always in order by race
    ccr5 <- c(sample(c('WW','DW','DD'), births.B, replace=T, prob=c(1-sum(ccr5.freq.B), ccr5.freq.B[2], ccr5.freq.B[1])),
              sample(c('WW','DW','DD'), births.W, replace=T, prob=c(1-sum(ccr5.freq.W), ccr5.freq.W[2], ccr5.freq.W[1]))
            )
      
    # Add new atts to atts.curr
    atts.curr <- data.frame(active=active, race=race, age=age, sqrt.age=sqrt.age, circ=circ, 
       inst.ai.class=inst.ai.class,inf.status=inf.status, inf.time=inf.time, stage=stage,
       stage.time=stage.time, diag.status=diag.status, diag.time=diag.time,
       last.neg.test=last.neg.test, tx.status=tx.status, tx.init.time=tx.init.time, 
       cum.time.on.tx=cum.time.on.tx, cum.time.off.tx=cum.time.off.tx, vl=vl,
       infector=infector, inf.role=inf.role, inf.type=inf.type,
       inf.diag=inf.diag, inf.tx=inf.tx, inf.stage=inf.stage,           
       arrival.time=arrival.time, depart.time=depart.time, tt.traj=tt.traj, 
       role.class=role.class, ins.quot=ins.quot, ccr5=ccr5,
       stringsAsFactors = F
    )
    
    atts.curr <- atts.curr[new.order,]
    row.names(atts.curr) <- birthIDs
    atts.curr <- cbind(uid, atts.curr)  # Have to do uid *after* the row shuffle
    names(atts.curr)[1] <- 'uid'
    mard$atts.curr <- rbind(mard$atts.curr,atts.curr)
    
    # Add and activate new vertices to nD object
    if(use.nD==T) {
      mard$nD.main <- add.vertices.active(mard$nD.main, births, onset= curr.time, terminus=Inf)
      mard$nD.pers <- add.vertices.active(mard$nD.pers, births, onset= curr.time, terminus=Inf)
      mard$nD.inst <- add.vertices.active(mard$nD.inst, births, onset= curr.time, terminus=Inf)
    } else {
      mard$nD.main <- add.vertices(mard$nD.main, births)
      mard$nD.pers <- add.vertices(mard$nD.pers, births)
      mard$nD.inst <- add.vertices(mard$nD.inst, births)      
    }

    # Add new atts to nD object
    att.names <- c('race','sqrt.age','inst.ai.class','inf.status','stage','diag.status','tx.status','role.class')
    att.values <- list(atts.curr$race, atts.curr$sqrt.age, atts.curr$inst.ai.class, atts.curr$inf.status,
                       atts.curr$stage, atts.curr$diag.status, atts.curr$tx.status, atts.curr$role.class)
    
    mard$nD.main <- set.vertex.attribute(mard$nD.main, att.names, att.values,v=birthIDs)
    mard$nD.pers <- set.vertex.attribute(mard$nD.pers, att.names, att.values,v=birthIDs)
    mard$nD.inst <- set.vertex.attribute(mard$nD.inst, att.names, att.values,v=birthIDs)
  }
  return(mard)
}
