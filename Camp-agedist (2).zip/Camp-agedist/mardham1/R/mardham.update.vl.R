mardham.update.vl <- function(mard, curr.time, vl.acute.rise.dur, vl.acute.peak, 
                         vl.acute.fall.dur, vl.set.point,
                         vl.aids.onset, vl.aids.dur, vl.fatal,
                         vl.full.supp, vl.part.supp,
                         max.time.off.tx.part, max.time.on.tx.part,
                         max.time.off.tx.full,
                         full.supp.down.slope, full.supp.up.slope,
                         part.supp.down.slope, part.supp.up.slope,
                         ...) {
      
  vlard <- vl.acute.rise.dur; vlap <- vl.acute.peak  						
  vlafd <- vl.acute.fall.dur; vlsp <- vl.set.point					
  vldo <- vl.aids.onset; vldd <- vl.aids.dur; vlf  <- vl.fatal

  vlds <- (vlf-vlsp)/vldd  
  inf.time.bp <- curr.time - mard$atts.curr$inf.time
  
  part.tx.score <-  mard$atts.curr$cum.time.off.tx/max.time.off.tx.part + 
    mard$atts.curr$cum.time.on.tx/max.time.on.tx.part
  
  ## A) tx-naive men
    target <- which(mard$atts.curr$active==1 &
      mard$atts.curr$inf.status==1 & (mard$atts.curr$cum.time.on.tx)%in%0)
    inf.time.bp.tn <- inf.time.bp[target]
    new.vl <- (inf.time.bp.tn<=vlard)*(vlap*inf.time.bp.tn/vlard) +
      (inf.time.bp.tn>vlard)*(inf.time.bp.tn<=vlard+vlafd)*((vlsp-vlap)*(inf.time.bp.tn-vlard)/vlafd+vlap) +
      (inf.time.bp.tn>vlard+vlafd)*(inf.time.bp.tn<=vldo)*(vlsp) +
      (inf.time.bp.tn>vldo)*(vlsp+(inf.time.bp.tn-vldo)*vlds)  
    mard$atts.curr$vl[target] <- new.vl

  ### B) men on tx, tt.traj=full, not yet escaped
    target <- which(mard$atts.curr$active==1 &
      mard$atts.curr$tx.status==1 & mard$atts.curr$tt.traj=='YF' &
      mard$atts.curr$stage != "D")
      # mard$atts.curr$cum.time.off.tx<max.time.off.tx.full)
    current.vl <- mard$atts.curr$vl[target]
    new.vl <- pmax(current.vl-full.supp.down.slope, vl.full.supp)
    mard$atts.curr$vl[target] <- new.vl

  ### C) men on tx, tt.traj=part, not yet escaped
    target <- which(mard$atts.curr$active==1 &
      mard$atts.curr$tx.status==1 & mard$atts.curr$tt.traj=='YP' &
      mard$atts.curr$stage != "D")
      # mard$atts.curr$cum.time.off.tx<max.time.off.tx.full)
    current.vl <- mard$atts.curr$vl[target]
    new.vl <- pmax(current.vl-part.supp.down.slope, vl.part.supp)
    mard$atts.curr$vl[target] <- new.vl

  ### D) men off tx, not naive, tt.traj=full, not yet escaped
    target <- which(mard$atts.curr$active==1 &
      mard$atts.curr$tx.status==0 & mard$atts.curr$tt.traj=='YF'  & 
      (mard$atts.curr$cum.time.on.tx>0)%in%T &
      mard$atts.curr$stage != "D")
      # mard$atts.curr$cum.time.off.tx<max.time.off.tx.full)
    current.vl <- mard$atts.curr$vl[target]
    new.vl <- pmin(current.vl+full.supp.up.slope, vlsp)
    mard$atts.curr$vl[target] <- new.vl
  
  ### E) men off tx, not naive, tt.traj=part, not yet escaped
    target <- which(mard$atts.curr$active==1 &
      mard$atts.curr$tx.status==0 & mard$atts.curr$tt.traj=='YP' & 
      (mard$atts.curr$cum.time.on.tx>0)%in%T & 
      mard$atts.curr$stage != "D")
      # part.tx.score<1)
    current.vl <- mard$atts.curr$vl[target]
    new.vl <- pmin(current.vl+part.supp.up.slope, vlsp)
    mard$atts.curr$vl[target] <- new.vl

  ### F) men on tx, tt.traj=full, escaped
      # Doesn't exist.
  
  ### G) men on tx, tt.traj=part, escaped
    target <- which(mard$atts.curr$active==1 &
      mard$atts.curr$tx.status==1 & mard$atts.curr$tt.traj=='YP' & 
      mard$atts.curr$stage == "D")
      # part.tx.score>=1)
      current.vl <- mard$atts.curr$vl[target]
    current.vl <- mard$atts.curr$vl[target]
    new.vl <- current.vl+vlds
    mard$atts.curr$vl[target] <- new.vl
      
  ### H) men off tx, tt.traj=full, and escaped
    target <- which(mard$atts.curr$active==1 &
      mard$atts.curr$tx.status==0 & mard$atts.curr$tt.traj=='YF'  & 
      (mard$atts.curr$cum.time.on.tx>0)%in%T &
      mard$atts.curr$stage == "D")
      # mard$atts.curr$cum.time.off.tx>=max.time.off.tx.full)
    current.vl <- mard$atts.curr$vl[target]
    new.vl <- current.vl+vlds
    mard$atts.curr$vl[target] <- new.vl
  
  ### I) men off tx, tt.traj=part, and escaped
    target <- which(mard$atts.curr$active==1 &
      mard$atts.curr$tx.status==0 & mard$atts.curr$tt.traj=='YP' & 
      (mard$atts.curr$cum.time.on.tx>0)%in%T & 
      mard$atts.curr$stage == "D")
      # part.tx.score>=1)
    current.vl <- mard$atts.curr$vl[target]
    new.vl <- current.vl+vlds
    mard$atts.curr$vl[target] <- new.vl    

  return(mard)
}
