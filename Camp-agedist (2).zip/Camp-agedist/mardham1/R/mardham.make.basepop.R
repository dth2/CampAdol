
mardham.make.basepop <- function(popsize, prop.B = 0.5, ages= 18:39, 
  age.dist.B, age.dist.W, age.unit, 
  prev.B, prev.W, init.prev.age.slope.B, init.prev.age.slope.W,  
  num.inst.ai.classes,
  active.spell=NULL, net.obs.period = NULL,
  last.neg.test.time.range.B, last.neg.test.time.range.W, 
  tt.traj.freq.B, tt.traj.freq.W,
  circ.prev.B, circ.prev.W,
  role.class.freq.B, role.class.freq.W,
  testing.pattern, test.window.period, 
  mean.test.interv.B, mean.test.interv.W,
  prob.tx.init.B, prob.tx.init.W, 
  prob.tx.halt.B, prob.tx.halt.W,
  prob.tx.reinit.B, prob.tx.reinit.W,
  max.time.off.tx.full, max.time.on.tx.part, max.time.off.tx.part,
  vl.acute.rise.dur, vl.acute.peak,
  vl.acute.fall.dur, vl.set.point,				
  vl.aids.onset, vl.aids.dur, vl.fatal,
  vl.full.supp, vl.part.supp,
  ccr5.freq.B, ccr5.freq.W,
  ccr5.heteroz.rr,
  ...) {

    nD <- network.initialize(popsize,directed=F)
  
  # Create vector: active (for atts.curr; not for nD, obvs)
    active <- rep(1,popsize)
    
  # Create vector: race
    num.B <- round(prop.B*popsize)
    num.W <- popsize-num.B
    race <- c(rep('B',num.B),rep('W',num.W))
  
  # Create vectors: age
  # TODO maybe: get apportion.lr to randomly distribute the underrepresented
  
    ages.B <- sample(apportion.lr(num.B, ages, age.dist.B))
    ages.W <- sample(apportion.lr(num.W, ages, age.dist.W))
    age <- c(ages.B,ages.W)
    
    fractions <- (0:(age.unit-1))/age.unit
    age <- age + sample(fractions, length(age), replace=T)
    
    sqrt.age <- sqrt(age)
    arrival.time <- rep(NA,popsize)
    depart.time <- rep(NA,popsize)

  #  Create vector: circumcision status
    circ.B <- sample(apportion.lr(num.B, 0:1, 1-circ.prev.B))
    circ.W <- sample(apportion.lr(num.B, 0:1, 1-circ.prev.W))
    circ <- c(circ.B, circ.W)
  
  # Create vector: treatment traj  
    tt.traj.B = sample(apportion.lr(num.B, c('NN','YN','YP','YF'), tt.traj.freq.B))
    tt.traj.W = sample(apportion.lr(num.W, c('NN','YN','YP','YF'), tt.traj.freq.W))
    tt.traj <- c(tt.traj.B, tt.traj.W)
  
  # Create vector: inst.ai.class
    inst.ai.B <- sample(apportion.lr(num.B, 1:num.inst.ai.classes, rep(1/num.inst.ai.classes, num.inst.ai.classes)))
    inst.ai.W <- sample(apportion.lr(num.W, 1:num.inst.ai.classes, rep(1/num.inst.ai.classes, num.inst.ai.classes)))
    inst.ai.class <- c(inst.ai.B,inst.ai.W)
  
  # Create vector: role class and ins.quot
    role.class.B <- sample(apportion.lr(num.B, c('I','R','V'), role.class.freq.B))
    role.class.W <- sample(apportion.lr(num.B, c('I','R','V') ,role.class.freq.W))
    role.class <- c(role.class.B,role.class.W)
    ins.quot <-rep(NA, length(role.class))
    ins.quot[role.class=='I']  <- 1
    ins.quot[role.class=='R']  <- 0
    ins.quot[role.class=='V']  <- runif(sum(role.class=='V'))

  # Create vector: inf status
  # TODO: allow for more forms of heterogeneity in initial seeding
    #inf.status.B <- sample(apportion.lr(num.B,0:1,c(1-prev.B,prev.B)))
    #inf.status.W <- sample(apportion.lr(num.W,0:1,c(1-prev.W,prev.W)))
    #inf.status <- c(inf.status.B,inf.status.W)
  
    num.inf.B <- round(prev.B*num.B)
    num.inf.W <- round(prev.B*num.W)
  
    prob.inf.unadj.B <- ages.B*init.prev.age.slope.B              # mx
    prob.inf.B <- prob.inf.unadj.B + 
          (num.inf.B-sum(prob.inf.unadj.B))/num.B   # mx + b
    if(sum(prob.inf.B<=0)>0) 
          stop("Slope of initial prevalence by age must be sufficiently low to avoid non-positive probabilities.")

    #inf.B <- sample(1:num.B, num.inf.B, replace=F, prob=prob.inf.B)
    #inf.status.B <- rep(0, num.B)
    #inf.status.B[inf.B] <- 1
  
    inf.status.B <- rep(0,num.B)
    while(sum(inf.status.B) != num.inf.B) {
      inf.status.B <- rbinom(num.B, 1, prob.inf.B)
    }
    
    prob.inf.unadj.W <- ages.W*init.prev.age.slope.W
    prob.inf.W <- prob.inf.unadj.W + 
      (num.inf.W-sum(prob.inf.unadj.W))/num.W   # mx + b
    if(sum(prob.inf.W<=0)>0) 
      stop("Slope of initial prevalence by age must be sufficiently low to avoid non-positive probabilities.")

    #inf.W <- sample(1:num.W, num.inf.W, replace=F, prob=prob.inf.W)  
    #inf.status.W <- rep(0, num.W)
    #inf.status.W[inf.W] <- 1  

    inf.status.W <- rep(0,num.W)
    while(sum(inf.status.W) != num.inf.W) {
      inf.status.W <- rbinom(num.W, 1, prob.inf.W)
    }
    
    inf.status <- c(inf.status.B,inf.status.W)
  
  ###### Create vectors: infection-related attributes
  
    stage <- stage.time <- inf.time <- vl <- diag.status <- diag.time <- 
      last.neg.test <- tx.status <- tx.init.time <- 
      cum.time.on.tx <- cum.time.off.tx <- 
      infector <- inf.role <- inf.type <- inf.diag <- inf.tx <- inf.stage <- 
      rep(NA, popsize)
  
    time.sex.active <- round(age.unit*age-age.unit*min(ages), 0)
    time.sex.active[time.sex.active==0] <- 1  # tiny kluge to avoid problems with vectors; arises when men in init pop are exactly 18.000 and are already infected
  
    vlard <- vl.acute.rise.dur; vlap <- vl.acute.peak    					
    vlafd <- vl.acute.fall.dur; vlsp <- vl.set.point					
    vldo <- vl.aids.onset; vldd <- vl.aids.dur; vlf  <- vl.fatal
    vlds <- (vlf-vlsp)/vldd; vlad <- vlard + vlafd
  
    # non-treater (incl. both tester and non-tester)
  
      selected <- which(inf.status==1 & tt.traj %in% c("NN","YN"))
      max.inf.time <- pmin(time.sex.active[selected], vl.aids.onset + vl.aids.dur)
      time.since.inf <- ceiling(runif(length(selected),max=max.inf.time))
      inf.time[selected] <- -time.since.inf
      tx.status[selected] <- 0
      cum.time.on.tx[selected] <- 0
      cum.time.off.tx[selected] <- time.since.inf
      
      stage[selected[time.since.inf <= vlard]] <- "AR"
      stage[selected[time.since.inf > vlard & 
        time.since.inf <= vlad]] <- "AF"
      stage[selected[time.since.inf > vlad & 
        time.since.inf <= vldo]] <- "C"
      stage[selected[time.since.inf > vldo]] <- "D"

      stage.time[selected][stage[selected]=="AR"] <- time.since.inf[stage[selected]=="AR"]
      stage.time[selected][stage[selected]=="AF"] <- time.since.inf[stage[selected]=="AF"] - vlard
      stage.time[selected][stage[selected]=="C"] <- time.since.inf[stage[selected]=="C"] - vlad
      stage.time[selected][stage[selected]=="D"] <- time.since.inf[stage[selected]=="D"] - vldo

      vl[selected] <- (time.since.inf<=vlard)*(vlap*time.since.inf/vlard) +
          (time.since.inf>vlard)*(time.since.inf<=vlard+vlafd)*((vlsp-vlap)*(time.since.inf-vlard)/vlafd+vlap) +
          (time.since.inf>vlard+vlafd)*(time.since.inf<=vldo)*(vlsp) +
          (time.since.inf>vldo)*(vlsp+(time.since.inf-vldo)*vlds)  

      selected <- which(inf.status==1 & tt.traj=="NN")
      diag.status[selected] <- 0
      
      selected <- which(inf.status==1 & tt.traj=="YN")
      if (testing.pattern=="interval") {
        time.from.inf.to.next.test <- ceiling(runif(length(selected), min=0, 
          max = mean.test.interv.B*(race[selected]=="B") + 
                mean.test.interv.W*(race[selected]=="W")))
      }    
      if (testing.pattern=="memoryless") {
        time.from.inf.to.next.test <- rgeom(length(selected), 
          1/(mean.test.interv.B*(race[selected]=="B") + 
            mean.test.interv.W*(race[selected]=="W")))
      }

      diag.status[selected][time.from.inf.to.next.test > cum.time.off.tx[selected] - test.window.period] <- 0
      last.neg.test[selected][time.from.inf.to.next.test > cum.time.off.tx[selected] - test.window.period] <- 
          - time.from.inf.to.next.test[time.from.inf.to.next.test > cum.time.off.tx[selected] - test.window.period] # reverse direction
    
      diag.status[selected][time.from.inf.to.next.test <= cum.time.off.tx[selected] - test.window.period] <- 1
        
    # Full adherent treater 
  
      # Create set of expected values for (cum.time.off.tx,cum.time.on.tx)
      
      tx.init.time.B <- test.window.period + last.neg.test.time.range.B + 1/prob.tx.init.B
      tx.init.time.W <- test.window.period + last.neg.test.time.range.W + 1/prob.tx.init.W
  
      prop.time.on.tx.B <- prob.tx.reinit.B / (prob.tx.halt.B + prob.tx.reinit.B)
      offon.B <- matrix(c(1:tx.init.time.B, rep(0,tx.init.time.B)), nrow=tx.init.time.B)
      numsteps.B <- (max.time.off.tx.full - tx.init.time.B)/(1-prop.time.on.tx.B)
      offon.B <- rbind(offon.B, cbind(tx.init.time.B + (1-prop.time.on.tx.B) * 1:numsteps.B, prop.time.on.tx.B * 1:numsteps.B))
      offon.B <- round(offon.B,0)
      exp.dur.chronic.B <- nrow(offon.B)-vlad
      exp.onset.aids.B <- nrow(offon.B)
      offon.last.B <- offon.B[nrow(offon.B),]
      offon.B <- rbind(offon.B, matrix( c(offon.last.B[1]+(1:vl.aids.dur),rep(offon.last.B[2],vl.aids.dur)), ncol=2))
      max.possible.inf.time.B <- nrow(offon.B)
      offon.B[,2] <- (1:max.possible.inf.time.B) - offon.B[,1]      # Fix possible rounding errors 
      stage.B <- c(rep("AR",vlard),rep("AF",vlafd),rep("C",exp.dur.chronic.B),rep("D",vldd))
      stage.time.B <- c(1:vlard,1:vlafd,1:exp.dur.chronic.B,1:vldd)
  
      prop.time.on.tx.W <- prob.tx.reinit.W / (prob.tx.halt.W + prob.tx.reinit.W)
      offon.W <- matrix(c(1:tx.init.time.W, rep(0,tx.init.time.W)), nrow=tx.init.time.W)
      numsteps.W <- (max.time.off.tx.full - tx.init.time.W)/(1-prop.time.on.tx.W)
      offon.W <- rbind(offon.W, cbind(tx.init.time.W + (1-prop.time.on.tx.W) * 1:numsteps.W, prop.time.on.tx.W * 1:numsteps.W))
      offon.W <- round(offon.W,0)
      exp.dur.chronic.W <- nrow(offon.W)-vlad
      exp.onset.aids.W <- nrow(offon.W)
      offon.last.W <- offon.W[nrow(offon.W),]
      offon.W <- rbind(offon.W, matrix( c(offon.last.W[1]+(1:vl.aids.dur),rep(offon.last.W[2],vl.aids.dur)), ncol=2))
      max.possible.inf.time.W <- nrow(offon.W)
      offon.W[,2] <- (1:max.possible.inf.time.W) - offon.W[,1]      # Fix possible rounding errors 
      stage.W <- c(rep("AR",vlard),rep("AF",vlafd),rep("C",exp.dur.chronic.W),rep("D",vldd))
      stage.time.W <- c(1:vlard,1:vlafd,1:exp.dur.chronic.W,1:vldd)
  
      # Implement for B
  
      selected <- which(inf.status==1 & tt.traj=="YF" & race=="B")
      max.inf.time <- pmin(time.sex.active[selected], max.possible.inf.time.B)
      time.since.inf <- ceiling(runif(length(selected),max=max.inf.time))
      inf.time[selected] <- -time.since.inf
      cum.time.on.tx[selected] <- offon.B[time.since.inf,2]
      cum.time.off.tx[selected] <- offon.B[time.since.inf,1]
      stage[selected] <- stage.B[time.since.inf]
      stage.time[selected] <- stage.time.B[time.since.inf]
      tx.status[selected] <- 0
      tx.status[selected][stage[selected]=="C" & cum.time.on.tx[selected]>0] <- 
        rbinom(sum(stage[selected]=="C" & cum.time.on.tx[selected]>0),1, prop.time.on.tx.B)
      vl[selected] <- (time.since.inf<=vlard)*(vlap*time.since.inf/vlard) +
        (time.since.inf>vlard)*(time.since.inf<=vlard+vlafd)*((vlsp-vlap)*(time.since.inf-vlard)/vlafd+vlap) +
        (time.since.inf>vlard+vlafd)*(time.since.inf<=exp.onset.aids.B)*(vlsp) +
        (time.since.inf>exp.onset.aids.B)*(vlsp+(time.since.inf-exp.onset.aids.B)*vlds)
      vl[selected][tx.status[selected]==1] <- vl.full.supp   
  
      # Implement for W
  
      selected <- which(inf.status==1 & tt.traj=="YF" & race=="W")
      max.inf.time <- pmin(time.sex.active[selected], max.possible.inf.time.W)
      time.since.inf <- ceiling(runif(length(selected),max=max.inf.time))
      inf.time[selected] <- -time.since.inf
      cum.time.on.tx[selected] <- offon.W[time.since.inf,2]
      cum.time.off.tx[selected] <- offon.W[time.since.inf,1]
      stage[selected] <- stage.W[time.since.inf]
      stage.time[selected] <- stage.time.W[time.since.inf]
      tx.status[selected] <- 0
      tx.status[selected][stage[selected]=="C" & cum.time.on.tx[selected]>0] <- 
        rbinom(sum(stage[selected]=="C" & cum.time.on.tx[selected]>0),1, prop.time.on.tx.W)
      vl[selected] <- (time.since.inf<=vlard)*(vlap*time.since.inf/vlard) +
        (time.since.inf>vlard)*(time.since.inf<=vlard+vlafd)*((vlsp-vlap)*(time.since.inf-vlard)/vlafd+vlap) +
        (time.since.inf>vlard+vlafd)*(time.since.inf<=exp.onset.aids.W)*(vlsp) +
        (time.since.inf>exp.onset.aids.W)*(vlsp+(time.since.inf-exp.onset.aids.W)*vlds)
      vl[selected][tx.status[selected]==1] <- vl.full.supp   
      
      # Implement diagnosis for both
  
      selected <- which(inf.status==1 & tt.traj=="YF")
      if (testing.pattern=="interval") time.from.inf.to.next.test <- 
        ceiling(runif(length(selected), min=0, 
        max = mean.test.interv.B*(race[selected]=="B") + 
        mean.test.interv.W*(race[selected]=="W"))) 
      if (testing.pattern=="memoryless") time.from.inf.to.next.test <- 
        rgeom(length(selected), 1/(mean.test.interv.B*(race[selected]=="B") + 
        mean.test.interv.W*(race[selected]=="W")))
      diag.status[selected][time.from.inf.to.next.test > cum.time.off.tx[selected] - test.window.period] <- 0
      last.neg.test[selected][time.from.inf.to.next.test > cum.time.off.tx[selected] - test.window.period] <- 
        - time.from.inf.to.next.test[time.from.inf.to.next.test > cum.time.off.tx[selected] - test.window.period] # reverse direction
      diag.status[selected][time.from.inf.to.next.test <= cum.time.off.tx[selected] - test.window.period] <- 1
      diag.status[selected][cum.time.on.tx[selected]>0] <- 1       # Can't be on tx if not diagnosed;
      last.neg.test[selected][cum.time.on.tx[selected]>0] <- NA    # undo the last neg test for them as well
  
  # Part adherent treater 
  
      # Create set of expected values for (cum.time.off.tx,cum.time.on.tx)
      
      prop.time.on.tx.B <- prob.tx.reinit.B / (prob.tx.halt.B + prob.tx.reinit.B)
      offon.B <- matrix(c(1:tx.init.time.B, rep(0,tx.init.time.B)), nrow=tx.init.time.B)
      while (offon.B[nrow(offon.B),1]/max.time.off.tx.part + offon.B[nrow(offon.B),2]/max.time.on.tx.part <1) offon.B <- 
        rbind(offon.B, offon.B[nrow(offon.B),] + c(1-prop.time.on.tx.B, prop.time.on.tx.B))
      offon.B <- round(offon.B,0)
      exp.dur.chronic.B <- nrow(offon.B)-vlad
      exp.onset.aids.B <- nrow(offon.B)
      offon.last.B <- offon.B[nrow(offon.B),]
      offon.B <- rbind(offon.B, matrix( c(offon.last.B[1]+(1:vl.aids.dur),rep(offon.last.B[2],vl.aids.dur)), ncol=2))
      max.possible.inf.time.B <- nrow(offon.B)
      offon.B[,2] <- (1:max.possible.inf.time.B) - offon.B[,1]      # Fix possible rounding errors 
      stage.B <- c(rep("AR",vlard),rep("AF",vlafd),rep("C",exp.dur.chronic.B),rep("D",vldd))
      stage.time.B <- c(1:vlard,1:vlafd,1:exp.dur.chronic.B,1:vldd)
      
      prop.time.on.tx.W <- prob.tx.reinit.W / (prob.tx.halt.W + prob.tx.reinit.W)
      offon.W <- matrix(c(1:tx.init.time.W, rep(0,tx.init.time.W)), nrow=tx.init.time.W)
      while (offon.W[nrow(offon.W),1]/max.time.off.tx.part + offon.W[nrow(offon.W),2]/max.time.on.tx.part <1) offon.W <- 
        rbind(offon.W, offon.W[nrow(offon.W),] + c(1-prop.time.on.tx.W, prop.time.on.tx.W))
      offon.W <- round(offon.W,0)
      exp.dur.chronic.W <- nrow(offon.W)-vlad
      exp.onset.aids.W <- nrow(offon.W)
      offon.last.W <- offon.W[nrow(offon.W),]
      offon.W <- rbind(offon.W, matrix( c(offon.last.W[1]+(1:vl.aids.dur),rep(offon.last.W[2],vl.aids.dur)), ncol=2))
      max.possible.inf.time.W <- nrow(offon.W)
      offon.W[,2] <- (1:max.possible.inf.time.W) - offon.W[,1]      # Fix possible rounding errors 
      stage.W <- c(rep("AR",vlard),rep("AF",vlafd),rep("C",exp.dur.chronic.W),rep("D",vldd))
      stage.time.W <- c(1:vlard,1:vlafd,1:exp.dur.chronic.W,1:vldd)
  
  
      # Implement for B
      
      selected <- which(inf.status==1 & tt.traj=="YP" & race=="B")
      max.inf.time <- pmin(time.sex.active[selected], max.possible.inf.time.B)
      time.since.inf <- ceiling(runif(length(selected),max=max.inf.time))
      inf.time[selected] <- -time.since.inf
      cum.time.on.tx[selected] <- offon.B[time.since.inf,2]
      cum.time.off.tx[selected] <- offon.B[time.since.inf,1]
      stage[selected] <- stage.B[time.since.inf]
      stage.time[selected] <- stage.time.B[time.since.inf]
      tx.status[selected] <- 0
      tx.status[selected][stage[selected]=="C" & cum.time.on.tx[selected]>0] <- 
        rbinom(sum(stage[selected]=="C" & cum.time.on.tx[selected]>0),1, prop.time.on.tx.B)
      vl[selected] <- (time.since.inf<=vlard)*(vlap*time.since.inf/vlard) +
        (time.since.inf>vlard)*(time.since.inf<=vlard+vlafd)*((vlsp-vlap)*(time.since.inf-vlard)/vlafd+vlap) +
        (time.since.inf>vlard+vlafd)*(time.since.inf<=exp.onset.aids.B)*(vlsp) +
        (time.since.inf>exp.onset.aids.B)*(vlsp+(time.since.inf-exp.onset.aids.B)*vlds)
      vl[selected][tx.status[selected]==1] <- vl.part.supp   
      
      # Implement for W
      
      selected <- which(inf.status==1 & tt.traj=="YP" & race=="W")
      max.inf.time <- pmin(time.sex.active[selected], max.possible.inf.time.W)
      time.since.inf <- ceiling(runif(length(selected),max=max.inf.time))
      inf.time[selected] <- -time.since.inf
      cum.time.on.tx[selected] <- offon.W[time.since.inf,2]
      cum.time.off.tx[selected] <- offon.W[time.since.inf,1]
      stage[selected] <- stage.W[time.since.inf]
      stage.time[selected] <- stage.time.W[time.since.inf]
      tx.status[selected] <- 0
      tx.status[selected][stage[selected]=="C" & cum.time.on.tx[selected]>0] <- 
        rbinom(sum(stage[selected]=="C" & cum.time.on.tx[selected]>0),1, prop.time.on.tx.W)
      vl[selected] <- (time.since.inf<=vlard)*(vlap*time.since.inf/vlard) +
        (time.since.inf>vlard)*(time.since.inf<=vlard+vlafd)*((vlsp-vlap)*(time.since.inf-vlard)/vlafd+vlap) +
        (time.since.inf>vlard+vlafd)*(time.since.inf<=exp.onset.aids.W)*(vlsp) +
        (time.since.inf>exp.onset.aids.W)*(vlsp+(time.since.inf-exp.onset.aids.W)*vlds)
      vl[selected][tx.status[selected]==1] <- vl.part.supp   
      
      # Implement diagnosis for both
      
      selected <- which(inf.status==1 & tt.traj=="YP")
      if (testing.pattern=="interval") time.from.inf.to.next.test <- 
        ceiling(runif(length(selected), min=0, 
        max = mean.test.interv.B*(race[selected]=="B") + 
        mean.test.interv.W*(race[selected]=="W"))) 
      if (testing.pattern=="memoryless") time.from.inf.to.next.test <- 
        rgeom(length(selected), 1/(mean.test.interv.B*(race[selected]=="B") + 
        mean.test.interv.W*(race[selected]=="W")))
      diag.status[selected][time.from.inf.to.next.test > cum.time.off.tx[selected] - test.window.period] <- 0
      last.neg.test[selected][time.from.inf.to.next.test > cum.time.off.tx[selected] - test.window.period] <- 
        - time.from.inf.to.next.test[time.from.inf.to.next.test > cum.time.off.tx[selected] - test.window.period] # reverse direction
      diag.status[selected][time.from.inf.to.next.test <= cum.time.off.tx[selected] - test.window.period] <- 1
      diag.status[selected][cum.time.on.tx[selected]>0] <- 1       # Can't be on tx if not diagnosed;
      last.neg.test[selected][cum.time.on.tx[selected]>0] <- NA    # undo the last neg test for them as well
      
  # Last neg test before present for negatives
  
      selected <- which(inf.status==0 & 
                          tt.traj%in% c("YN","YP","YF"))
  
      if (testing.pattern=="interval") {
        time.since.last.test <- 
          ceiling(runif(length(selected), min=0, 
          max = mean.test.interv.B*(race[selected]=="B") + 
          mean.test.interv.W*(race[selected]=="W")))
      }    
      if (testing.pattern=="memoryless") {
        time.since.last.test <- 
          rgeom(length(selected), 
          1/(mean.test.interv.B*(race[selected]=="B") + 
          mean.test.interv.W*(race[selected]=="W")))
      }
        
      last.neg.test[selected] <- -time.since.last.test
  
  # Assign CCR5 genotype
  
  ccr5 <- rep('WW', num.B+num.W)

  num.ccr5.DD.B <- ccr5.freq.B[1] * num.B                                   # homozygotes for deletion
  num.ccr5.DW.B <- ccr5.freq.B[2] * num.B                                   # heterozygotes
  num.ccr5.WW.B <- num.B - num.ccr5.DD.B - num.ccr5.DW.B                    # homozygotes for deletion
  num.uninf.ccr5.DD.B <- round(num.ccr5.DD.B)                               # DD's can't be infected
  num.inf.ccr5.DW.B <- round(num.ccr5.DW.B * num.inf.B * ccr5.heteroz.rr /  # Unique solution to get 
        (num.ccr5.WW.B + num.ccr5.DW.B * ccr5.heteroz.rr))                  #   relative risk right in init pop
  num.uninf.ccr5.DW.B <- round(num.ccr5.DW.B - num.inf.ccr5.DW.B)
  inf.B <- which(inf.status == 1 & race == 'B')
  inf.ccr5.DW.B <- sample(inf.B, num.inf.ccr5.DW.B, replace=F)
  ccr5[inf.ccr5.DW.B] <- "DW"
  uninf.B <- which(inf.status == 0 & race == 'B')
  uninf.ccr5.DWDD.B <- sample(uninf.B, num.uninf.ccr5.DW.B + num.uninf.ccr5.DD.B, replace=F)
  uninf.ccr5.DW.B <- sample(uninf.ccr5.DWDD.B, num.uninf.ccr5.DW.B, replace=F)
  uninf.ccr5.DD.B <- setdiff(uninf.ccr5.DWDD.B, uninf.ccr5.DW.B)
  ccr5[uninf.ccr5.DW.B] <- "DW"
  ccr5[uninf.ccr5.DD.B] <- "DD"
  
  num.ccr5.DD.W <- ccr5.freq.W[1] * num.W                                   # homozygotes for deletion
  num.ccr5.DW.W <- ccr5.freq.W[2] * num.W                                   # heterozygotes
  num.ccr5.WW.W <- num.W - num.ccr5.DD.W - num.ccr5.DW.W                    # homozygotes for deletion
  num.uninf.ccr5.DD.W <- round(num.ccr5.DD.W)                               # DD's can't be infected
  num.inf.ccr5.DW.W <- round(num.ccr5.DW.W * num.inf.W * ccr5.heteroz.rr /  # Unique solution to get 
        (num.ccr5.WW.W + num.ccr5.DW.W * ccr5.heteroz.rr))                  #   relative risk right in init pop
  num.uninf.ccr5.DW.W <- round(num.ccr5.DW.W - num.inf.ccr5.DW.W)
  inf.W <- which(inf.status == 1 & race == 'W')
  inf.ccr5.DW.W <- sample(inf.W, num.inf.ccr5.DW.W, replace=F)
  ccr5[inf.ccr5.DW.W] <- "DW"
  uninf.W <- which(inf.status == 0 & race == 'W')
  uninf.ccr5.DWDD.W <- sample(uninf.W, num.uninf.ccr5.DW.W + num.uninf.ccr5.DD.W, replace=F)
  uninf.ccr5.DW.W <- sample(uninf.ccr5.DWDD.W, num.uninf.ccr5.DW.W, replace=F)
  uninf.ccr5.DD.W <- setdiff(uninf.ccr5.DWDD.W, uninf.ccr5.DW.W)
  ccr5[uninf.ccr5.DW.W] <- "DW"
  ccr5[uninf.ccr5.DD.W] <- "DD"

  ###### End of infection-related attributes (finally!)
  ###### Final book-keeping

  # Create vertex order
    vertex.order <- sample(1:popsize)
    
    atts.curr <- data.frame(active=active, race=race, age=age, sqrt.age=sqrt.age, circ=circ,
      inst.ai.class = inst.ai.class,
      inf.status=inf.status, inf.time=inf.time, stage=stage, stage.time=stage.time, 
      diag.status=diag.status, diag.time=diag.time, last.neg.test=last.neg.test,
      tx.status=tx.status, tx.init.time=tx.init.time, cum.time.on.tx=cum.time.on.tx,
      cum.time.off.tx=cum.time.off.tx, vl=vl,                          
      infector=infector, inf.role=inf.role, inf.type= inf.type, 
      inf.diag=inf.diag, inf.tx=inf.tx, inf.stage=inf.stage,
      arrival.time=arrival.time, 
      depart.time=depart.time, tt.traj=tt.traj,
      role.class=role.class, ins.quot=ins.quot,
      ccr5=ccr5,
      stringsAsFactors = F)
  
    atts.curr <- atts.curr[vertex.order,]  
    atts.curr <- cbind(1:popsize,atts.curr)
    names(atts.curr)[1] <- 'uid'
    rownames(atts.curr) <- 1:popsize
  
  # Add all needed atts into nD object
    att.names <- c('race','sqrt.age','inst.ai.class','inf.status','stage','diag.status','tx.status','role.class')
    att.values <- list(atts.curr$race, atts.curr$sqrt.age, atts.curr$inst.ai.class, atts.curr$inf.status,
        atts.curr$stage, atts.curr$diag.status, atts.curr$tx.status, atts.curr$role.class)
    nD <- set.vertex.attribute(nD,att.names,att.values)
  
  
  # Set activity spells and net.obs.period
    set.network.attribute(nD,'net.obs.period',list(observations=list(net.obs.period),
        mode="discrete", time.increment=1,time.unit="step"))
    activate.vertices(nD,onset=active.spell[1],terminus=active.spell[2])
    # NB: no need to activate edges, since there are no edges yet
        
  # Assorted book-keeping
    
    initialize.pids(nD)
    curr.time <- 0

    nD.main <- nD
    nD.pers <- nD
    nD.inst <- nD
    disc.ai <- list()
    deg.dists <- list()
    discl.list <- as.data.frame(matrix(NA,0,4))
    names(discl.list) <- c('pos','neg','discl.time','discl.type')
  
    nD.main <- set.vertex.attribute(nD.main, "deg.pers", 0)
    nD.pers <- set.vertex.attribute(nD.pers, "deg.main", 0)
    nD.inst <- set.vertex.attribute(nD.inst, "deg.main", 0)
    nD.inst <- set.vertex.attribute(nD.inst, "deg.pers", 0)

    max.uid <- popsize
    new.edges <- matrix(NA, nrow=0, ncol=2)
  
    result <- list(nD.main, nD.pers, nD.inst, disc.ai, curr.time, atts.curr, deg.dists, discl.list, max.uid, new.edges)
    names(result) <- c('nD.main', 'nD.pers', 'nD.inst', 'disc.ai','curr.time','atts.curr', 'deg.dists', 'discl.list', 'max.uid', 'new.edges')
    class(result) <- "mardham"
    return(result)
}
