mardham.san.start <- function(mard, main.model, pers.model, san.rm.disallowed.role.combo,
                              SAN.burnin) {
  
  #temp <- as.edgelist(san(main.model$fit, control=control.san(SAN.burnin=SAN.burnin)))
  temp <-  as.edgelist(simulate(main.model$fit, control=control.simulate.ergm(MCMC.burnin=SAN.burnin)))
  #temp.formula <- update.formula(main.model$fit$formula, network.collapse(mard$nD.main, at=0)~.)
  #environment(temp.formula) <- environment()
  #temp <-  as.edgelist(simulate(temp.formula, coef=main.model$fit$coef, 
  #            control=control.simulate.formula(MCMC.burnin=SAN.burnin)))
  
  #main.model$fit$network <- network.collapse(mard$nD.main, at=0)
  #main.model$fit$newnetwork <- network.collapse(mard$nD.main, at=0)
  #main.model$nwsize <- network.size(network.collapse(mard$nD.main, at=0))
  #temp <-  as.edgelist(simulate(main.model$fit, 
  #  control=control.simulate.ergm(MCMC.burnin=SAN.burnin)))  
  
  if(san.rm.disallowed.role.combo==T) {
    disallowed <- c(which(mard$atts.curr$role.class[temp[,1]]=='I' & 
                            mard$atts.curr$role.class[temp[,2]]=='I'),
                    which(mard$atts.curr$role.class[temp[,1]]=='R' & 
                            mard$atts.curr$role.class[temp[,2]]=='R'))
    if (length(disallowed)>0) temp <- temp[-disallowed,]
  }
  mard$nD.main <- add.edges.active(mard$nD.main, temp[,1], temp[,2], onset=0, terminus=Inf)
  mard$nD.pers <- mardham.update.degree(mard$nD.pers, mard$nD.main, deg.type='main', curr.time=0, use.nD=T)
  
  temp.formula <- update.formula(pers.model$fit, network.collapse(mard$nD.pers, at=0)~.) 
  environment(temp.formula) <- environment()
  
#  temp <-  as.edgelist(san(pers.model$fit, formula=temp.form, control=control.san(SAN.burnin=SAN.burnin)))
#  temp <-  as.edgelist(simulate(pers.model$fit, formula=temp.form, control=control.simulate.ergm(MCMC.burnin=SAN.burnin)))
  temp <-  as.edgelist(simulate(pers.model$fit, control=control.simulate.ergm(MCMC.burnin=SAN.burnin)))
  # temp <-  as.edgelist(simulate(temp.formula, coef=pers.model$fit.coef, 
  #              control=control.simulate.formula(MCMC.burnin=SAN.burnin)))

  if(san.rm.disallowed.role.combo==T) {
    disallowed <- c(which(mard$atts.curr$role.class[temp[,1]]=='I' & 
                            mard$atts.curr$role.class[temp[,2]]=='I'),
                    which(mard$atts.curr$role.class[temp[,1]]=='R' & 
                            mard$atts.curr$role.class[temp[,2]]=='R'))
    if (length(disallowed)>0) temp <- temp[-disallowed,]
  }
  
  mard$nD.pers <- add.edges.active(mard$nD.pers, temp[,1], temp[,2], onset=0, terminus=Inf)
  mard$nD.main <- mardham.update.degree(mard$nD.main, mard$nD.pers, deg.type='pers', curr.time=0, use.nD=T)
  mard$nD.inst <- mardham.update.degree(mard$nD.inst, mard$nD.main, deg.type='main', curr.time=0, use.nD=T)
  mard$nD.inst <- mardham.update.degree(mard$nD.inst, mard$nD.pers, deg.type='pers', curr.time=0, use.nD=T)

  return(mard)  
}
