print.mardham <- function(x,...) {    # TODO MAKE THESE BETTER
  print(x$nD.main)
  print(x$nD.pers)
  print(x$nD.inst)
  print(x$curr.time)
  print(x$atts.curr)
}

summary.mardham <- function(x,...) {
  result <- x$atts.curr[1,]
  return(result)
}

plot.mardham <- function(x, ...) {
  plot(x$summ$p)
}
