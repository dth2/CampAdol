mardham.progress <- function(mard, curr.time, vl.acute.rise.dur, vl.acute.peak, 
                         vl.acute.fall.dur, vl.set.point,
                         vl.aids.onset, vl.aids.dur,
                         vl.fatal, max.time.on.tx.part, max.time.off.tx.part,
                         max.time.off.tx.full) {

  active <- (mard$atts.curr$active==1)
  time.since.inf <- curr.time - mard$atts.curr$inf.time
  
  # Increment day
    mard$atts.curr$stage.time[active] <- mard$atts.curr$stage.time[active] + 1

  # Change stage to Acute Falling
    mard$atts.curr$stage[active & (time.since.inf==(vl.acute.rise.dur+1))%in%1] <- "AF"
    mard$atts.curr$stage.time[active & (time.since.inf==(vl.acute.rise.dur+1))%in%1] <- 1
  
  # Change stage to Chronic
    mard$atts.curr$stage[active & (time.since.inf==(vl.acute.rise.dur+vl.acute.fall.dur+1))%in%1] <- "C"
    mard$atts.curr$stage.time[active & (time.since.inf==(vl.acute.rise.dur+vl.acute.fall.dur+1))%in%1] <- 1
    
  # Change stage to AIDS
    aids.tx.naive <- which(mard$atts.curr$active==1 &
      mard$atts.curr$inf.status==1 & (mard$atts.curr$cum.time.on.tx)%in%0 &
      (curr.time-mard$atts.curr$inf.time >= vl.aids.onset) & 
      mard$atts.curr$stage!='D')    

    part.tx.score <-  mard$atts.curr$cum.time.off.tx/max.time.off.tx.part + 
      mard$atts.curr$cum.time.on.tx/max.time.on.tx.part

    aids.part.escape <- which(mard$atts.curr$active==1 &
      (mard$atts.curr$cum.time.on.tx>0)%in%T & 
      mard$atts.curr$tt.traj=='YP' & 
      mard$atts.curr$stage=="C" & part.tx.score>=1 &
      mard$atts.curr$stage!='D'
      )

    aids.off.tx.full.escape <- which(mard$atts.curr$active==1 &
      mard$atts.curr$tx.status==0 & mard$atts.curr$tt.traj=='YF'  & 
      (mard$atts.curr$cum.time.on.tx>0)%in%T &
      mard$atts.curr$cum.time.off.tx>=max.time.off.tx.full &
      mard$atts.curr$stage!='D'
      )

    initiating.aids <- c(aids.tx.naive, aids.part.escape, aids.off.tx.full.escape)
    mard$atts.curr$stage[initiating.aids] <- "D"
    mard$atts.curr$stage.time[initiating.aids] <- 1

return(mard)
}
