
#######################################################################

mardham.get.id.from.uid <- function(mard, uid) {
  if(is.null(mard$atts.list)) stop("First argument to mardham.get.id.from.uid must be of class mardham and must containt element atts.list. To obtain such an object, run mardham.sim with argument save.atts.each.step=T.")
  result <- rep(NA, length(mard$atts.list))
  for (i in 1:length(mard$atts.list)) {
    matches <- which(mard$atts.list[[i]]$uid==uid)
    if (length(matches)>1) stop("Problem! Unique ID is not so unique after all!")
    if (length(matches)==1) result[i] <- matches
  }
  return(result)
}

mardham.get.ids <- function(mard, verbose=F) {
  if(is.null(mard$atts.list)) stop("First argument to mardham.get.ids must be of class mardham and must containt element atts.list. To obtain such an object, run mardham.sim with argument save.atts.each.step=T.")
  result <- matrix(NA, mard$max.uid, length(mard$atts.list))
  for (i in 1:mard$max.uid) {
    result[i,] <- mardham.get.id.from.uid (mard, i)
    if (verbose==T) cat("Finishing node", i, "of", mard$max.uid, "\n")
  }
  return(result)
}

mardham.get.att.from.uid <- function(mard, att.name, uid, v=NULL, verbose=T) {

  if(class(uid)=="matrix" & is.null(v)) {
    result <- matrix(NA, nrow(uid), ncol(uid))
    for(i in 1:nrow(uid)) {
      result[i,] <- sapply(1:ncol(uid), function(x) mard$atts.list[[x]][uid[i,x],att.name])
      if(verbose==T) cat("Finishing node ", i, " of ", nrow(uid),".\n", sep="" )
    }
  }

  if(class(uid)=="matrix" & !is.null(v)) {
    result <- matrix(NA, length(v), ncol(uid))
    for(i in 1:length(v)) {
      result[i,] <- sapply(1:ncol(uid), function(x) mard$atts.list[[x]][uid[v[i],x],att.name])
      if(verbose==T) cat("Finishing node ", i, " of ", nrow(uid),".\n", sep="" )
    }
  }
  
  if(is.vector(uid)) {
    result <- sapply(1:length(uid), function(x) mard$atts.list[[x]][uid[x],att.name])
  }

  return(result)
}

########################################################################
### Made redundant by summ

#mardham.prop.on.tx.atts.list <- function(mard, verbose=T) {
#  result <- data.frame(time=1:mard$curr.time, n=NA, nB=NA, nW=NA, i=NA, iB=NA, iW=NA, t=NA, tB=NA, tW=NA,
#                       pt=NA, ptB=NA, ptW=NA)
#  for (i in 1:mard$curr.time) {
#    result$n[i] <- sum(mard$atts.list[[i]]$active==1)
#    result$nB[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$race=='B')
#    result$nW[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$race=='W')
#    result$i[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1)
#    result$iB[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1 & mard$atts.list[[i]]$race=='B')
#    result$iW[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1 & mard$atts.list[[i]]$race=='W')
#    result$t[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1 & mard$atts.list[[i]]$tx.status==1)
#    result$tB[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1 & mard$atts.list[[i]]$tx.status==1 & mard$atts.list[[i]]$race=='B')
#    result$tW[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1 & mard$atts.list[[i]]$tx.status==1 & mard$atts.list[[i]]$race=='W')
#    if(verbose==T) cat('Finishing time step ',i,' of ',mard$curr.time,'.\n',sep='')
#  }
#  result$pt <- result$t/result$i
#  result$ptB <- result$tB/result$iB
#  result$ptW <- result$tW/result$iW
#  return(result)
#}

##############################################################################
### Code below works, but has been supplanted now by the addition of $summ
###   to the mardham object during simulation

#mardham.calc.prev <- function(mard) {
#  times <- 1:length(mard$atts.list)
#  result <- sapply(times, function(x) c(
#    sum(mard$atts.list[[x]]$active==1), 
#    sum(mard$atts.list[[x]]$active==1 & mard$atts.list[[x]]$race=='B'),
#    sum(mard$atts.list[[x]]$active==1 & mard$atts.list[[x]]$race=='W'),
#    sum(mard$atts.list[[x]]$active==1 & mard$atts.list[[x]]$inf.status==1),
#    sum(mard$atts.list[[x]]$active==1 & mard$atts.list[[x]]$race=='B' & mard$atts.list[[x]]$inf.status==1),
#    sum(mard$atts.list[[x]]$active==1 & mard$atts.list[[x]]$race=='W' & mard$atts.list[[x]]$inf.status==1)
#  ))
#  result <- t(result)
#  result <- as.data.frame(result)
#  names(result) <- c('n','nB','nW','i','iB','iW')
#  result$p <- result$i/result$n
#  result$pB <- result$iB/result$nB
#  result$pW <- result$iW/result$nW  
#  return(result)
#}

#######################################################################
### This will be made rendudant by the addition of tx info to $summ

#mardham.prop.on.tx.atts.list <- function(mard, verbose=T) {
#  result <- data.frame(time=1:mard$curr.time, n=NA, nB=NA, nW=NA, i=NA, iB=NA, iW=NA, t=NA, tB=NA, tW=NA,
#                       pt=NA, ptB=NA, ptW=NA)
#  for (i in 1:mard$curr.time) {
#    result$n[i] <- sum(mard$atts.list[[i]]$active==1)
#    result$nB[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$race=='B')
#    result$nW[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$race=='W')
#    result$i[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1)
#    result$iB[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1 & mard$atts.list[[i]]$race=='B')
#    result$iW[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1 & mard$atts.list[[i]]$race=='W')
#    result$t[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1 & mard$atts.list[[i]]$tx.status==1)
#    result$tB[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1 & mard$atts.list[[i]]$tx.status==1 & mard$atts.list[[i]]$race=='B')
#    result$tW[i] <- sum(mard$atts.list[[i]]$active==1 & mard$atts.list[[i]]$inf.status==1 & mard$atts.list[[i]]$tx.status==1 & mard$atts.list[[i]]$race=='W')
#    if(verbose==T) cat('Finishing time step ',i,' of ',mard$curr.time,'.\n',sep='')
#  }
#  result$pt <- result$t/result$i
#  result$ptB <- result$tB/result$iB
#  result$ptW <- result$tW/result$iW
#  return(result)
#}

#############################################################################################################
### No longer works since the switch to deleting inactive verticies
### Take the atts.list element of a mardham object and collate it from 
### timestep to actor.
### May be resurrectable in combination with uids.
### Not optimised for speed.

#mardham.collate.atts <- function(mard) {
#  if (is.null(mard$atts.list)) 
#    stop("Object passed to mardham.collate.atts must contain an element named atts.list.")  
#  steps <- length(mard$atts.list)
#  max.pop <- dim(mard$atts.list[[steps]])[1]  
#  new.atts <- list()
#  for (i in 1:max.pop) {
#    new.atts[[i]] <- mard$atts.list[[1]][i,]
#    #new.atts[[i]] <- sapply(2:steps, function(x) 
#    for (x in 2:steps) new.atts[[i]] <- rbind(new.atts[[i]], mard$atts.list[[x]][i,])
#    rownames(new.atts[[i]]) <- 1:steps
#    cat("Done node ",i," out of ",max.pop,".\n",sep='')
#  }
#  return(new.atts)
#}
