mardham.make.updates.to.network <- function(mard) {
  att.names <- c('race','sqrt.age','inst.ai.class','inf.status','stage','diag.status','tx.status','role.class')
  
  attach(mard$atts.curr)
  att.values <- lapply(1:length(att.names), function(x) get(att.names[x]))
  detach(mard$atts.curr)
  
  mard$nD.main <- set.vertex.attribute(mard$nD.main, att.names, att.values)
  mard$nD.pers <- set.vertex.attribute(mard$nD.pers, att.names, att.values)
  mard$nD.inst <- set.vertex.attribute(mard$nD.inst, att.names, att.values)
  return(mard)
}