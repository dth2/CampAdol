mardham.meanstats <- function(num.B, num.W, 
                              deg.mp.B, deg.mp.W,
                              mean.per.timestep.i.B, 
                              mean.per.timestep.i.W,
                              prop.hom.mpi.B, prop.hom.mpi.W,
                              balance,
                              mean.sq.age.diff.BB,
                              mean.sq.age.diff.WW,
                              mean.sq.age.diff.BW,
                              age.method="homogeneous",
                              ...
  ) {
  if (sum(deg.mp.B)!=1) stop("Argument deg.mp.B to mardham.meanstats must sum to 1.")
  if (sum(deg.mp.W)!=1) stop("Argument deg.mp.W to mardham.meanstats must sum to 1.")

  # deg.pers nodal attribute
  deg.pers.B <- apportion.lr(num.B, c('B0','B1','B2'), colSums(deg.mp.B))
  deg.pers.W <- apportion.lr(num.W, c('W0','W1','W2'), colSums(deg.mp.W))
                       
  # deg main nodal attribute
  deg.main.B <- apportion.lr(num.B, c('B0','B1'), rowSums(deg.mp.B))
  deg.main.W <- apportion.lr(num.W, c('W0','W1'), rowSums(deg.mp.W))

  # main partnerships
  totdeg.m.by.dp <-c(num.B * deg.mp.B[2,], num.W * deg.mp.W[2,])
  totdeg.m.by.race <- c(sum(totdeg.m.by.dp[1:3]), sum(totdeg.m.by.dp[4:6]))
  edges.m <- (sum(totdeg.m.by.dp)) / 2
  edges.m.B2W <- totdeg.m.by.race[1] * (1-prop.hom.mpi.B[1])
  edges.m.W2B <- totdeg.m.by.race[2] * (1-prop.hom.mpi.W[1])  
  edges.het.m <- switch(balance,
                        black = edges.m.B2W,
                        white = edges.m.W2B,
                        mean = (edges.m.B2W + edges.m.W2B)/2                      # BW
                        )
  edges.hom.m <- (totdeg.m.by.race - edges.het.m)/2                     # BB, WW
  edges.nodemix.m <- c(edges.hom.m[1], edges.het.m, edges.hom.m[2])     # BB, BW, WW
  if (age.method=='heterogeneous') sq.age.diff.m <- edges.nodemix.m*c(mean.sq.age.diff.BB[1], 
          mean.sq.age.diff.BW[1], mean.sq.age.diff.WW[1])
  if (age.method=='homogeneous') {
          weighted.avg <- sum(edges.nodemix.m*c(mean.sq.age.diff.BB[1], 
              mean.sq.age.diff.BW[1], mean.sq.age.diff.WW[1]))/sum(edges.nodemix.m)
          sq.age.diff.m <- edges.nodemix.m * weighted.avg
  }
  meanstats.m <- c(edges.m, edges.nodemix.m[2:3], 
                        totdeg.m.by.dp[c(2:3,5:6)], sq.age.diff.m)

  # pers partnerships
  totdeg.p.by.dm <- c(num.B*deg.mp.B[,2] + num.B*deg.mp.B[,3]*2,
                        num.W*deg.mp.W[,2] + num.W*deg.mp.W[,3]*2)
  totdeg.p.by.race <- c(sum(totdeg.p.by.dm[1:2]), sum(totdeg.p.by.dm[3:4]))
  concurrent.p.by.race <- c(sum(deg.mp.B[,3])*num.B, sum(deg.mp.W[,3])*num.W)
  edges.p <- (sum(totdeg.p.by.dm)) / 2
  edges.p.B2W <- totdeg.p.by.race[1] * (1-prop.hom.mpi.B[2])
  edges.p.W2B <- totdeg.p.by.race[2] * (1-prop.hom.mpi.W[2])  
  edges.het.p <- switch(balance,
                        black = edges.p.B2W,
                        white = edges.p.W2B,
                        mean = (edges.p.B2W + edges.p.W2B)/2
  )
  edges.hom.p <- (totdeg.p.by.race - edges.het.p)/2                     # BB, WW
  edges.nodemix.p <- c(edges.hom.p[1], edges.het.p, edges.hom.p[2])     # BB, BW, WW
  sq.age.diff.p <- edges.nodemix.p*c(mean.sq.age.diff.BB[2], 
                        mean.sq.age.diff.BW[2], mean.sq.age.diff.WW[2])
  if (age.method=='heterogeneous') sq.age.diff.p <- edges.nodemix.p*c(mean.sq.age.diff.BB[2], 
                        mean.sq.age.diff.BW[2], mean.sq.age.diff.WW[2])
  if (age.method=='homogeneous') {
    weighted.avg <- sum(edges.nodemix.p*c(mean.sq.age.diff.BB[2], 
                        mean.sq.age.diff.BW[2], mean.sq.age.diff.WW[2]))/sum(edges.nodemix.p)
    sq.age.diff.p <- edges.nodemix.p * weighted.avg
  }
  meanstats.p <- c(edges.p, edges.nodemix.p[2:3], 
                        totdeg.p.by.dm[c(2,4)], concurrent.p.by.race, sq.age.diff.p)

  ## one-off contacts
  
  num.per.timestep.i.B <- num.B * deg.mp.B * mean.per.timestep.i.B
  num.per.timestep.i.W <- num.W * deg.mp.W * mean.per.timestep.i.W
  
  totdeg.i.by.race <- c(sum(num.per.timestep.i.B), sum(num.per.timestep.i.W))
  
  edges.i <- sum(totdeg.i.by.race)/2
  edges.i.B2W <- totdeg.i.by.race[1] * (1-prop.hom.mpi.B[3])
  edges.i.W2B <- totdeg.i.by.race[2] * (1-prop.hom.mpi.W[3])  
  edges.het.i <- switch(balance,
                        black = edges.i.B2W,
                        white = edges.i.W2B,
                        mean = (edges.i.B2W + edges.i.W2B)/2
  )
  edges.hom.i <- edges.i - edges.het.i
  edges.nodemix.i <- c((totdeg.i.by.race[1] - edges.het.i)/2, 
                       edges.het.i, (totdeg.i.by.race[1] - edges.het.i)/2) 
  sq.age.diff.i <- edges.nodemix.i*c(mean.sq.age.diff.BB[3], 
              mean.sq.age.diff.WW[3], mean.sq.age.diff.BW[3])
  if (age.method=='heterogeneous') sq.age.diff.i <- edges.nodemix.i*c(mean.sq.age.diff.BB[3], 
              mean.sq.age.diff.BW[3], mean.sq.age.diff.WW[3])
  if (age.method=='homogeneous') {
    weighted.avg <- sum(edges.nodemix.i*c(mean.sq.age.diff.BB[3], 
              mean.sq.age.diff.BW[3], mean.sq.age.diff.WW[3]))/sum(edges.nodemix.i)
    sq.age.diff.i <- edges.nodemix.i * weighted.avg
  }
  
  #meanstats.i <- c(edges.i, totdeg.i.by.race[2], num.per.timestep.i.B[2:6], num.per.timestep.i.W[2:6])
  meanstats.i <- c(edges.i, num.per.timestep.i.B[-1], num.per.timestep.i.W, edges.hom.i, sq.age.diff.i)

  ## Compile results
  
  meanstats <- list()
  meanstats$deg.pers <- c(deg.pers.B, deg.pers.W)
  meanstats$deg.main <- c(deg.main.B, deg.main.W)  
  meanstats$meanstats.m <- meanstats.m
  meanstats$meanstats.p <- meanstats.p
  meanstats$meanstats.i <- meanstats.i
  return(meanstats)
}
