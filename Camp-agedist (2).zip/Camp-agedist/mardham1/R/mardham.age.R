mardham.age <- function(mard, age.unit, time.step, ...) {
  
  #  if (time.step %% age.unit == 0) {
  # age[mard$atts.curr$active==1] <- age[mard$atts.curr$active==1]+1

  age <- mard$atts.curr$age
  # age[mard$atts.curr$active==1] <- age[mard$atts.curr$active==1] + 1/age.unit   # Yields rounding errors
  age[mard$atts.curr$active==1] <- (round((age[mard$atts.curr$active==1])*age.unit)+1)/age.unit
  sqrt.age <- sqrt(age)
  mard$atts.curr$age <- age
  mard$atts.curr$sqrt.age <- sqrt.age
  
  #}  

  return(mard)
}
  
