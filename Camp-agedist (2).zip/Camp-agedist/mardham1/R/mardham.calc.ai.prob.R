mardham.calc.ai.prob <- function(disc.edgelists, 
   mydata, base.exp.ai.BB, base.exp.ai.BW, base.exp.ai.WB, base.exp.ai.WW, 
   redux.inspos, incr.full.supp,  incr.part.supp, redux.diag ) {
  
  # Argument checking
  if (class(disc.edgelists) != "list") stop ("argument disc.edgelists must be a list")
  if (("disc.ins.pos" %in% names(disc.edgelists)) != TRUE) stop ("argument disc.edgelists must contain disc.ins.pos")
  if (("disc.rec.pos" %in% names(disc.edgelists)) != TRUE) stop ("argument disc.edgelists must contain disc.rec.pos")
  if (class(disc.edgelists$disc.ins.pos) != "matrix") stop ("argument disc.ins.pos must be a matrix")
  if (ncol(disc.edgelists$disc.ins.pos) != 2) stop ("argument disc.ins.pos must have two columns")
  if (mode(disc.edgelists$disc.ins.pos) != "numeric" ) stop ("argument disc.ins.pos must be numeric")
  if (any(disc.edgelists$disc.ins.pos != round(disc.ins.pos)) == TRUE) stop ("argument disc.ins.pos must be integer values")
  if ((0 %in% disc.edgelists$disc.ins.pos) == TRUE ) stop ("argument disc.ins.pos cannot contain 0")
  if (any(disc.edgelists$disc.ins.pos>nrow(mydata)) == TRUE ) stop ("argument disc.ins.pos cannot contain values greater than number of rows in dataframe")
  if (class(disc.edgelists$disc.rec.pos) != "matrix") stop ("argument disc.rec.pos must be a matrix")
  if (ncol(disc.edgelists$disc.rec.pos) != 2) stop ("argument disc.rec.pos must have two columns")
  if (mode(disc.edgelists$disc.rec.pos) != "numeric" ) stop ("argument disc.rec.pos must be numeric")
  if (any(disc.edgelists$disc.rec.pos != round(disc.rec.pos)) == TRUE) stop ("argument disc.rec.pos must be integer values")
  if ((0 %in% disc.edgelists$disc.rec.pos) == TRUE ) stop ("argument disc.rec.pos cannot contain 0")
  if (any(disc.edgelists$disc.rec.pos>nrow(mydata)) == TRUE ) stop ("argument disc.rec.pos cannot contain values greater than number of rows in dataframe")
  
  result <- list()
  result$prob.disc.ins.pos <- c()
  result$prob.disc.rec.pos <- c()
  
  ##rec pos
  ins.race.rec <- mydata$race[disc.edgelists$disc.rec.pos[,1]]
  rec.race.rec <- mydata$race[disc.edgelists$disc.rec.pos[,2]]
  pos.diag.rec <- mydata$diag.status[disc.edgelists$disc.rec.pos[,2]]
  pos.tx.rec 	 <- mydata$tx.status[disc.edgelists$disc.rec.pos[,2]]
  pos.tt.traj.rec <- mydata$tt.traj[disc.edgelists$disc.rec.pos[,2]]
  
  prob.rec <- (ins.race=='B' & rec.race=='B')* base.exp.ai.BB + 
    (ins.race=='B' & rec.race=='W')* base.exp.ai.BW + 
    (ins.race=='W' & rec.race=='B')* base.exp.ai.WB + 
    (ins.race=='W' & rec.race=='W')* base.exp.ai.WW
  
  prob.rec[pos.diag.rec == 1] <- prob.rec[pos.diag.rec == 1] * (1-redux.diag)
  prob.rec[pos.tx.rec == 1 & pos.tt.traj.rec == 'YF'] <- prob.rec[pos.tx.rec == 1 & pos.tt.traj.rec == 'YF'] * (1+incr.full.supp)
  prob.rec[pos.tx.rec == 1 & pos.tt.traj.rec == 'YP'] <- prob.rec[pos.tx.rec == 1 & pos.tt.traj.rec == 'YP'] * (1+incr.part.supp)
  
  ##ins pos
  ins.race.ins <- mydata$race[disc.edgelists$disc.ins.pos[,1]]
  rec.race.ins <- mydata$race[disc.edgelists$disc.ins.pos[,2]]
  pos.diag.ins <- mydata$diag.status[disc.edgelists$disc.ins.pos[,2]]
  pos.tx.ins 	 <- mydata$tx.status[disc.edgelists$disc.ins.pos[,2]]
  pos.tt.traj.ins <- mydata$tt.traj[disc.edgelists$disc.ins.pos[,2]]
  
  prob.ins <- (ins.race=='B' & rec.race=='B')* base.exp.ai.BB + 
    (ins.race=='B' & rec.race=='W')* base.exp.ai.BW + 
    (ins.race=='W' & rec.race=='B')* base.exp.ai.WB + 
    (ins.race=='W' & rec.race=='W')* base.exp.ai.WW
  
  prob.ins[pos.diag.ins == 1] <- prob.ins[pos.diag.ins == 1] * (1-redux.diag) * (1-redux.inspos)
  prob.ins[pos.tx.ins == 1 & pos.tt.traj.ins == 'YF'] <- prob.ins[pos.tx.ins == 1 & pos.tt.traj.ins == 'YF'] * (1+incr.full.supp)
  prob.ins[pos.tx.ins == 1 & pos.tt.traj.ins == 'YP'] <- prob.ins[pos.tx.ins == 1 & pos.tt.traj.ins == 'YP'] * (1+incr.part.supp)
  
  # compile results
  result$prob.disc.rec.pos <- c(prob.rec,)
  result$prob.disc.ins.pos <- c(prob.ins,)
  return(result)
 
}