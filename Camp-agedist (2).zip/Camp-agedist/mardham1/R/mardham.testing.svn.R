mardham.testing.svn <- function(x){
  result <- x^2
  return(result)
} 